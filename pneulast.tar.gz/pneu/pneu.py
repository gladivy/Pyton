#!/usr/bin/python
# coding: utf-8
import codecs
import os
import sqlite3
import sys
import time


def inicio():
    con = sqlite3.connect('data/database/database.db')
    con.execute('CREATE TABLE IF NOT EXISTS pneusados'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Data_Entrada INTEGER, '
                'Marca TEXT, '
                'Modelo TEXT, '
                'Medida INTEGER, '
                'Codigo TEXT, '
                'DO BLOB, '
                'T BLOB, '
                'Valor INTEGER, '
                'Armazen TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS vendidos'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Oldid INTEGER, '
                'Data_Entrada INTEGER, '
                'Data_Venda INTEGER, '
                'Marca TEXT, '
                'Modelo TEXT, '
                'Medida INTEGER, '
                'Codigo TEXT, '
                'DO BLOB, '
                'T BLOB, '
                'Valor INTEGER, '
                'Armazen TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS apagados'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Oldid INTEGER, '
                'Data_Entrada INTEGER, '
                'Dat_apagado INTEGER, '
                'Marca TEXT, '
                'Modelo TEXT, '
                'Medida INTEGER, '
                'Codigo TEXT, '
                'DO BLOB, '
                'T BLOB, '
                'Valor INTEGER, '
                'Armazen TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS precoalt'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Oldid INTEGER, '
                'Dat_alter INTEGER, '
                'Marca TEXT, '
                'Modelo TEXT, '
                'Medida TEXT, '
                'Codigo TEXT, '
                'DO BLOB, '
                'T BLOB, '
                'Valor_Era INTEGER, '
                'Valor_Agora INTEGER, '
                'Armazen TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS armazenalt'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Oldid INTEGER, '
                'Dat_alter INTEGER, '
                'Marca TEXT, '
                'Modelo TEXT, '
                'Medida TEXT, '
                'Codigo TEXT, '
                'DO BLOB, '
                'T BLOB, '
                'Valor INTEGER, '
                'Do_Armazen TEXT, '
                'Para_Armazen TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS dados'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Dia BLOB, '
                'Nome BLOB, '
                'Detalhes TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS marcas'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Marca TEXT, '
                'Modelo TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS medidas'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Medida BLOB, '
                'Codigo BLOB)')
    con.execute('CREATE TABLE IF NOT EXISTS armazens'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Armazen TEXT, '
                'Detalhes TEXT)')
    con.close()
    cssfilcheck()


def cssfilcheck():
    if not os.path.exists('data/html/tabela.CSS'):
        with codecs.open('data/html/tabela.CSS', 'w', 'utf_8') as fil:
            fil.write('h1 {\n'
                      '    font-style: italic;\n'
                      '    font-variant: small-caps;\n'
                      '    text-align: center;\n'
                      '    font-size: 100%;\n'
                      '}\n'
                      'th {\n'
                      '    border: 1px solid black;\n'
                      '    border-collapse: collapse;\n'
                      '    text-align: center;\n'
                      '    font-size: 90%;\n'
                      '}\n'
                      'th, td {\n'
                      '        padding: 3px;\n'
                      '}\n'
                      'td {\n'
                      '    border: 1px solid black;\n'
                      '    border-collapse: collapse;\n'
                      '    text-align: right;\n'
                      '    font-size: 87%;\n'
                      '}\n'
                      'table {\n'
                      '       margin: auto;\n'
                      '}\n'
                      'p {\n'
                      '   font-style: italic;\n'
                      '   margin-left: 80px;\n'
                      '}')
        fil.close()
        inciosair()
    else:
        inciosair()


def inciosair():
    import data.menu
    sys.stderr.write('\x1b[2J\x1b[H')
    sys.stderr.write('\x1b[s COMPILADO EM PYTHON 2.7.11 '
                     'PARA SQLITE 3.8.7.1...')
    time.sleep(1.5)
    sys.stderr.write('\x1b[u NO KERNEL 3.16.0-4-amd64 #1 SMP Debian '
                     '3.16.7-ckt25-2+deb8u3 (2016-07-02) x86_64 GNU/Linux...')
    time.sleep(2.5)
    sys.stderr.write('\x1b[u\x1b[J CARREGAR MENU...')
    time.sleep(1)
    data.menu.mainmenu()


def iniciomain():
    inicio()
    cssfilcheck()
    inciosair()


if __name__ == '__main__':
    iniciomain()
