#!/usr/bin/python
# coding: utf-8
import sys
import time


def utilmenu():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:27}\033[1m{2}\033[0m{3:33}'
                     '|\n'.format('', '', 'UTILIDADES', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:28}'
                     '|\n'.format('', '', '1 - TABELAS AUXILIARES', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:28}'
                     '|\n'.format('', '', '2 - RESTAURO E LIMPEZA', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:34}'
                     '|\n'.format('', '', '3 - BACKUP DADOS', ''))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'MENU --------- m', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'TABELAS ------ t', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'SAIR --------- s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:4}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU m, t, s.'.format(''))
        time.sleep(1)
        utilmain()
    if esc == '1':
        axiliarutil()
    elif esc == '2':
        retlimp()
    elif esc == '3':
        backuputil()
    elif esc == 'm':
        utiltomenu()
    elif esc == 't':
        utiltotabelas()
    elif esc == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU m, t, s.'.format(''))
    time.sleep(1)
    utilmain()


def axiliarutil():
    import data.tablauxiliares
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR TABELAS '
                     'AUXILIARES.'.format(''))
    time.sleep(1)
    data.tablauxiliares.auxiliarmain()


def retlimp():
    import data.limparesto
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR RESTAURO E '
                     'LIMPEZA.'.format(''))
    time.sleep(1)
    data.limparesto.limrestmain()


def backuputil():
    import data.backup
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU BECKUP.'.format(''))
    time.sleep(1)
    data.backup.bacupmain()


def utiltomenu():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU.'.format(''))
    time.sleep(1)
    data.menu.menumain()


def utiltotabelas():
    import data.tabelas
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU TABELAS.'.format(''))
    time.sleep(1)
    data.tabelas.tabmenumain()


def utilmain():
    utilmenu()
    axiliarutil()
    backuputil()
    utiltomenu()
    utiltotabelas()


if __name__ == '__main__':
    utilmain()
