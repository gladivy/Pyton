#!/usr/bin/python
# coding: utf-8
import codecs
import sys
import sqlite3
import time
import webbrowser


def htmlvehead():
    with codecs.open('data/html/vendas_total.html', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Oldid, Data_Venda, Marca, Modelo, Medida, '
                    'Codigo, DO, T, Valor, Armazen FROM vendidos')
        head = [i[0] for i in cur.description]
        old, dat, mar, mod, med, cod, dox, ttx, pre, arm = head
        fil.write(str(
            '<!DOCTYPE html>\n'
            '<html lang="pt-PT">\n'
            '<head>\n'
            '  <link rel="stylesheet" type="text/css" '
            'href="tabela.CSS">\n'
            '  <meta charset="UTF-8">\n'
            '  <title> Tabela Vendas</title>\n'
            '</head>\n'
            '<body>\n'
            '<h1>Tabela Vendas</h1>\n'
            '<table style="width:90%">\n'
            '  <tr>\n'
            '    <th>{0}</th>\n'
            '    <th>{1}</th>\n'
            '    <th>{2}</th>\n'
            '    <th>{3}</th>\n'
            '    <th>{4}</th>\n'
            '    <th>{5}</th>\n'
            '    <th>{6}{7}</th>\n'
            '    <th>{8}</th>\n'
            '    <th>{9}</th>\n'
            '  </tr>\n'.format(old, dat, mar, mod, med, cod,
                               dox, ttx, pre, arm)))
        con.close()
    fil.close()
    htlmvehead()


def htlmvehead():
    with codecs.open('data/html/vendas_total.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT Oldid, Data_Venda, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen FROM vendidos'):
            old, dat, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(
                '  <tr>\n'
                '    <td>{0}</td>\n'
                '    <td>{1}</td>\n'
                '    <td>{2}</td>\n'
                '    <td>{3}</td>\n'
                '    <td>{4}</td>\n'
                '    <td>{5}</td>\n'
                '    <td>{6}{7}</td>\n'
                '    <td>{8}</td>\n'
                '    <td>{9}</td>\n'
                '  </tr>\n'.format(old, dat, mar, mod, med, cod,
                                   dox, ttx, pre, arm)))
        con.close()
    fil.close()
    htmlvecount()


def htmlvecount():
    with codecs.open('data/html/vendas_total.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM vendidos')
        fil.write(str(
            '</table>\n'
            '  <p>NOTA:</p>\n'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{0} Entradas\n'
            '</body>\n'
            '</html>\n'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sairvendhtml()


def sairvendhtml():
    import data.htmlcomp
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE VENDAS EXPORTADA '
                     'EM HTML.'.format(''))
    time.sleep(1)
    webbrowser.open('data/html/vendas_total.html')
    data.htmlcomp.compmain()


def exphtmlvemain():
    htmlvehead()
    htlmvehead()
    htmlvecount()
    sairvendhtml()


if __name__ == '__main__':
    exphtmlvemain()
