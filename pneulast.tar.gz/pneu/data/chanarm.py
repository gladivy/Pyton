#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def xarne():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM armazens')
    head = [i[0] for i in cur.description]
    idx, armx, descx = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2} \033[1m{1:^4}\033[0m '
                     '| \033[1m{2:^15}\033[0m '
                     '| \033[1m{3:30}\033[0m\n'.format('', idx, armx, descx))
    sys.stdout.write('{0:2} {1}\n'.format('', 35 * '-'))
    for row in cur.fetchall():
        ide, arm, desc = row
        sys.stdout.write('{0:2} {1:^4} | {2:^15} | '
                         '{3:30}\n'.format('', ide, arm, desc))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}|{1:2}\033[1m{2}\033[0m{3:24}'
        '|\n'.format('', '', 'ESCREVA O ID RELATIVO AO ARMAZEN', ''))
    sys.stdout.write(
        '{0:2}|{1:2}\033[1m{2}\033[0m{3:21}'
        '|\n'.format('', '', '"\033[92mnovo\033[0m" '
                             'PARA INSERIR UM NOVO ARMAZEN', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:41}'
                     '|\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    equ = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not equ:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID, '
                         'novo OU a.'.format(''))
        time.sleep(1.5)
        xarne()
    if equ == 'a':
        con.close()
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saircha()
    elif equ == 'novo':
        con.close()
        sys.stderr.write('\x1b[u\x1b[J{0:2}PARA CRIAR UM ARMAZEN '
                         'NOVO.'.format(''))
        time.sleep(1.5)
        chnovo()
    else:
        cur.execute('SELECT Armazen FROM armazens WHERE ID=?', (equ,))
        if not cur.fetchall():
            sys.stderr.write('\x1b[u\x1b[J{0:2}ID INEXISTENTE.'.format(''))
            time.sleep(1)
            xarne()
        else:
            con.close()
    xarnend(equ)


def xarnend(eqx):
    with codecs.open('data/temp/modar.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for line in con.execute('SELECT Armazen '
                                'FROM armazens WHERE ID=?', (eqx,)):
            arms = line[0]
            fil.write(',')
            fil.write(str(arms))
        con.close()
    fil.close()
    xaredfil()


def xaredfil():
    with codecs.open('data/temp/modar.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            vik, arm = lin
            novoinarmtbl(vik, arm)
    fil.close()


def chnovo():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}|{1:2}\033[1m{2}\033[0m{3:24}'
        '|\n'.format('', '', 'ESCREVA O NOME PARA NOVO ARMAZEN', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:42}'
                     '|\n'.format('', '', 'PARA ANULAR -a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    arm = raw_input('\x1b[s{0:2}ARMAZEN > '.format(''))
    while not arm:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O NOVO '
                         'NOME OU a.'.format(''))
        time.sleep(1.5)
        chnovo()
    if arm == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saircha()
    else:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM armazens WHERE Armazen=?', (arm,))
        if cur.fetchall():
            sys.stderr.write('\x1b[u\x1b[J{0:2}ARMAZEN EXISTENTE.'.format(''))
            con.close()
            time.sleep(1)
            chnovo()
        else:
            con.close()
    with codecs.open('data/temp/modar.csv', 'a', 'utf_8') as fil:
        fil.write(',')
        fil.write(str(arm))
    fil.close()
    readnovis()


def readnovis():
    with codecs.open('data/temp/modar.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            arm = lin[1]
            chnovodis(arm)
    fil.close()


def chnovodis(arm):
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}|{1:2}\033[1m{2} \033[92m{3:^14}\033[0m '
        '{4}\033[0m{5:2}|\n'.format('', '', 'DISCRIMINE O ARMAZEN', arm,
                                    'EM CURTAS PALAVRAS', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:41}'
                     '|\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    det = raw_input('\x1b[s{0:2}DETALHE > '.format(''))
    while not det:
        sys.stderr.write('\x1b[u\x1b[J{0:2}DESCRIMINE O '
                         'ARMAZAN OU a.'.format(''))
        time.sleep(1.5)
        readnovis()
    if det == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saircha()
    else:
        with codecs.open('data/temp/modar.csv', 'a', 'utf_8') as fil:
            fil.write(',')
            fil.write(str(det))
        fil.close()
    innovofilred()


def innovofilred():
    with codecs.open('data/temp/modar.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            arm = lin[1]
            det = lin[2]
            inchnovo(arm, det)
    fil.close()


def inchnovo(arm, det):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute('INSERT INTO armazens VALUES(NULL,?,?)', (arm, det,))
    tar = cur.lastrowid
    if not tar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO EM ACRESCENTAR O NOVO '
                         'ARMAZEN.'.format(''))
        con.close()
        time.sleep(2)
        saircha()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}NOVO ID {1} PARA O ARMAZEN '
                         '{2}.'.format('', tar, arm))
    con.close()
    time.sleep(1)
    lastmodared()


def lastmodared():
    with codecs.open('data/temp/modar.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            vik = lin[0]
            arm = lin[1]
            novoinarmtbl(vik, arm)
    fil.close()


def novoinarmtbl(vik, arm):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute('INSERT INTO armazenalt SELECT NULL, ID, NULL, Marca, '
                    'Modelo, Medida, Codigo, DO, T, Valor, Armazen, NULL '
                    'FROM pneusados WHERE ID = ?', (vik,))
    tar = cur.lastrowid
    if not tar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A CRIAR O ID {1} NA '
                         'TABELA ALTERADOS.'.format('', vik))
        con.close()
        time.sleep(3)
        saircha()
    else:
        with con:
            con.execute(
                'UPDATE armazenalt SET Dat_alter = ?, '
                'Para_Armazen = ? '
                'WHERE ID = ?', (time.strftime('%d-%m-%y'), arm, tar,))
    for row in con.execute('SELECT Dat_alter FROM armazenalt '
                           'WHERE ID = ?', (tar,)):
        dat = row[0]
        if dat == (time.strftime('%d-%m-%y')):
            sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} ALTERADO EM '
                             '{2}'.format('', tar, time.strftime('%d-%m-%y')))
            con.close()
            time.sleep(1.5)
            novoupdarm(arm, vik)
        else:
            con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO ALTERAR A DATA DO ID {1} '
                     'NA TABELA ALTERADOS.'.format('', tar))
    time.sleep(3)
    saircha()


def novoupdarm(arm, vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('UPDATE pneusados SET Armazen = ? '
                    'WHERE ID = ?', (arm, vik,))
    for row in con.execute('SELECT Armazen FROM pneusados '
                           'WHERE ID=?', (vik,)):
        arx = row[0]
        if arx == arm:
            sys.stderr.write(' PARA {0}.'.format(arm))
            con.close()
            time.sleep(1.5)
            lastxarsair()
        else:
            sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO AO ALTERAR O ID {1} '
                             'NA TABELA DE PNEUS.'.format('', vik))
    con.close()
    time.sleep(3)
    saircha()


def lastxarsair():
    import data.modarma
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA    ALTERAR - a  VOLTAR - v '
                     ' SAIR - s{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
        time.sleep(1.5)
        lastxarsair()
    if sair == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ALTERAR OUTRO.'.format(''))
        time.sleep(1)
        data.modarma.armmain()
    elif sair == 'v':
        saircha()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
    time.sleep(1.5)
    lastxarsair()


def saircha():
    import data.modificar
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.modificar.modficarmain()


def chanmain():
    xarne()
    xarnend(eqx=None)
    xaredfil()
    chnovo()
    readnovis()
    chnovodis(arm=None)
    innovofilred()
    inchnovo(arm=None, det=None)
    lastmodared()
    novoinarmtbl(vik=None, arm=None)
    novoupdarm(arm=None, vik=None)
    lastxarsair()
    saircha()


if __name__ == '__main__':
    chanmain()
