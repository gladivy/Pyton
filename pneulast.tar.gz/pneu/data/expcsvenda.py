#!/usr/bin/python
# coding: utf-8
import codecs
import sys
import sqlite3
import time
import webbrowser


def vendhead():
    with codecs.open('data/csv/vendas_total.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Oldid, Data_Venda, Marca, Modelo, Medida, '
                    'Codigo, DO, T, Valor, Armazen FROM vendidos')
        fil.write(str('VENDAS'))
        fil.write('\n')
        fil.write('')
        fil.write('\n')
        head = [i[0] for i in cur.description]
        olx, dtx, mrx, mdx, mex, cdx, dox, ttx, prx, arx = head
        fil.write(str(olx))
        fil.write(',')
        fil.write(str(dtx))
        fil.write(',')
        fil.write(str(mrx))
        fil.write(',')
        fil.write(str(mdx))
        fil.write(',')
        fil.write(str(mex))
        fil.write(',')
        fil.write(str(cdx))
        fil.write(',')
        fil.write(str('{0}{1}'.format(dox, ttx)))
        fil.write(',')
        fil.write(str(prx))
        fil.write(',')
        fil.write(str(arx))
        fil.write('\n')
        con.close()
    fil.close()
    vendcsvbody()


def vendcsvbody():
    with codecs.open('data/csv/vendas_total.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT Oldid, Data_Venda, Marca, Modelo, '
                'Medida, Codigo, DO, T, Valor, Armazen FROM vendidos'):
            old, dtx, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(old))
            fil.write(',')
            fil.write(str(dtx))
            fil.write(',')
            fil.write(str(mar))
            fil.write(',')
            fil.write(str(mod))
            fil.write(',')
            fil.write(str(med))
            fil.write(',')
            fil.write(str(cod))
            fil.write(',')
            fil.write(str('{0}{1}'.format(dox, ttx)))
            fil.write(',')
            fil.write(str(pre))
            fil.write(',')
            fil.write(str(arm))
            fil.write('\n')
        con.close()
    fil.close()
    vendcsvcount()


def vendcsvcount():
    with codecs.open('data/csv/vendas_total.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM vendidos')
        fil.write('\n')
        fil.write(str('{0} VENDAS'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    saircsvend()


def saircsvend():
    import data.csvcomp
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE VENDAS '
                     'EXPORTADA EM CSV.'.format(''))
    time.sleep(1)
    webbrowser.open('data/csv/vendas_total.csv')
    data.csvcomp.compmenu()


def csvvendcomp():
    vendhead()
    vendcsvbody()
    vendcsvcount()
    saircsvend()


if __name__ == '__name__':
    csvvendcomp()
