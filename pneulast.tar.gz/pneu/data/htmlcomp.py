#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def htmcomp():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write(
        '{0:2}|{1:21}{2}{3:24}'
        '|\n'.format('', '', '\033[1mEXPORTAR EM HTML COMPLETA\033[0m', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '1 - STOKE', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:40}'
                     '|\n'.format('', '', '2 - VENDAS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:38}'
                     '|\n'.format('', '', '3 - APAGADOS', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:49}'
                     '|\n'.format('', '', 'VOLTAR - v SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
        time.sleep(1.5)
        compmain()
    if esc == '1':
        stkcomp()
    elif esc == '2':
        vendcomp()
    elif esc == '3':
        apagacomp()
    elif esc == 'v':
        voltmen()
    elif esc == 's':
        saircomp()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
    time.sleep(1.5)
    compmain()


def stkcomp():
    import data.exphtmlstk
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        compmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA STOCK POR COMPLETO '
                     'EM HTML.'.format(''))
    time.sleep(1)
    data.exphtmlstk.exphtmlstkmain()


def vendcomp():
    import data.exphtmlvend
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        compmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VENDAS POR COMPLETO '
                     'EM HTML.'.format(''))
    time.sleep(1)
    data.exphtmlvend.exphtmlvemain()


def apagacomp():
    import data.exphtmlsapg
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        compmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA APAGADOS POR COMPLETO '
                     'EM HTML.'.format(''))
    time.sleep(1)
    data.exphtmlsapg.exphymlapamain()


def voltmen():
    import data.menuexphtml
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menuexphtml.htmlmain()


def saircomp():
    sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
    time.sleep(1)
    sys.stderr.write('\x1b[2J\x1b[H')
    sys.exit(10)


def compmain():
    htmcomp()
    vendcomp()
    apagacomp()
    voltmen()


if __name__ == '__main__':
    compmain()
