#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def martblchk():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        sairapagar()
    else:
        con.close()
    apmodst()


def apmodst():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}||{1:6}\033[1m{2}\033[0m{3:15}'
                     '||\n'.format('', '', 'ESCREVA O MARCA QUE '
                                           'PRETENDE APAGAR', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    mar = raw_input('\x1b[s{0:2}MARCA > '.format(''))
    while not mar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MARCA OU a.'.format(''))
        time.sleep(1.5)
        apmodst()
    if mar == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairapagar()
    else:
        with codecs.open('data/temp/apmodst.csv', 'w', 'utf_8') as fil:
            fil.write(str(mar))
        fil.close()
    apmodstredfil()


def apmodstredfil():
    with codecs.open('data/temp/apmodst.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            apamodbody(vik)
    fil.close()


def apamodbody(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas '
                'WHERE Marca LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MARCA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        apmodst()
    else:
        con.close()
    apamodhead(vik)


def apamodhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca FROM marcas '
                'WHERE Marca LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, mar = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3}\033[0m'
                     '.\n'.format('', 'Tablela', '', 'Marcas'))
    sys.stdout.write('\n{0:4} \033[1m{1:4}\033[0m | '
                     '\033[1m{2:15}\033[0m \n'.format('', ide, mar))
    sys.stdout.write('{0:2}{1}\n'.format('', 43 * '-'))
    con.close()
    apamodbot(vik)


def apamodbot(vik):
    with codecs.open('data/temp/apamodbot.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Marca FROM marcas WHERE Marca LIKE ? '
                'GROUP BY Marca ORDER BY Marca ASC', ('%' + vik + '%',)):
            ide, mar = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:4} {1:4} | {2:15} \n'.format('', ide, mar))
        con.close()
    fil.close()
    apamox()


def apamox():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 58 * '='))
    sys.stdout.write('{0:2}||{1:2}\033[1mESCOLHA O ID DA MARCA DO MODELO '
                     'QUE PRETENDE APAGAR\033[0m{2:1}||\n'.format('', '', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:35}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 58 * '='))
    ide = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        apmodstredfil()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairapagar()
    else:
        apamoxchekin(ide)


def apamoxchekin(vik):
    with codecs.open('data/temp/apamodbot.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                idchek(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    apmodstredfil()


def idchek(vik):
    with codecs.open('data/temp/idchek.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT Marca FROM marcas WHERE ID=?', (vik,)):
            mar = row[0]
            fil.write(str(mar))
        con.close()
    fil.close()
    idchekredfil()


def idchekredfil():
    with codecs.open('data/temp/idchek.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            apmoid(vik)
    fil.close()


def apmoid(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Modelo FROM marcas WHERE Marca=?', (vik,))
    head = [i[0] for i in cur.description]
    ide, mod = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write(
        '\n{0:2}{1}{2:1}\033[1;92m{3}{4}\033[0m'
        '.\n'.format('', 'Tablela', '', 'Modelos da Marca ', vik))
    sys.stdout.write('\n{0:4} \033[1m{1:4}\033[0m | '
                     '\033[1m{2:20}\033[0m \n'.format('', ide, mod))
    sys.stdout.write('{0:2}{1}\n'.format('', 43 * '-'))
    con.close()
    apmoidbody(vik)


def apmoidbody(vik):
    with codecs.open('data/temp/apmoidbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Modelo FROM marcas WHERE Marca=? '
                'ORDER BY Modelo ASC', (vik,)):
            ide, mod = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:4} {1:4} | {2:20} \n'.format('', ide, mod))
        con.close()
    fil.close()
    apgmdfin()


def apgmdfin():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 58 * '='))
    sys.stdout.write('{0:2}||{1:2}\033[1mESCOLHA O ID DO MODELO QUE PRETENDE '
                     'APAGAR\033[0m{2:10}||\n'.format('', '', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:35}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 58 * '='))
    ide = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        idchekredfil()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairapagar()
    else:
        apgmdfinchek(ide)


def apgmdfinchek(vik):
    with codecs.open('data/temp/apmoidbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                maridel(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    idchekredfil()


def maridel(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('DELETE FROM marcas WHERE ID=?', (vik,))
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas WHERE ID=?', (vik,))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} APAGADO.'.format('', vik))
        con.close()
        time.sleep(2)
        apgmodsair()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO APAGAR O ID {1}.'.format('', vik))
    time.sleep(3)
    apgmodsair()


def apgmodsair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 52 * '='))
    sys.stdout.write('{0:2}|     ESCOLHA  APAGAR - a  VOLTAR - v '
                     ' SAIR - s    |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 52 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    if not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
        time.sleep(1.5)
        apgmodsair()
    if sair == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR APAGAR OUTRA '
                         'MARCA.'.format(''))
        time.sleep(1)
        modellmain()
    elif sair == 'v':
        sairapagar()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
    time.sleep(1.5)
    apgmodsair()


def sairapagar():
    import data.menumodelo
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menumodelo.modeauxmain()


def modellmain():
    martblchk()
    apmodst()
    apmodstredfil()
    apamodbody(vik=None)
    apamodhead(vik=None)
    apamodbot(vik=None)
    apamox()
    apamoxchekin(vik=None)
    idchek(vik=None)
    idchekredfil()
    apmoid(vik=None)
    apmoidbody(vik=None)
    apgmdfin()
    apgmdfinchek(vik=None)
    maridel(vik=None)
    apgmodsair()


if __name__ == '__main__':
    modellmain()
