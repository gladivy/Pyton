#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time
import webbrowser


def htmlapaquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{1:8}\033[1mEXPORTAR APAGADO EM FORMATO '
                     'HTML\033[0m{2:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA A MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}'
                     '|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        htmlapaquest()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        apagmedsair()
    else:
        with codecs.open('data/temp/htmlapaquest.csv', 'w', 'utf_8') as fil:
            fil.write(str(esc))
        fil.close()
    htmlapagred()


def htmlapagred():
    with codecs.open('data/temp/htmlapaquest.csv', 'r', 'utf_8') as fil:
        for line in csv.reader(fil):
            vik = line[0]
            htmltblapachk(vik)
    fil.close()


def htmltblapachk(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM apagados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        htmlapaquest()
    else:
        con.close()
    htmltblapghead(vik)


def htmltblapghead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM apagados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} \n'.format('', '', ide, med))
    sys.stdout.write('{0:2}{1}\n'.format('', 35 * '-'))
    con.close()
    htmlapgbody(vik)


def htmlapgbody(vik):
    with codecs.open('data/temp/htmlapgbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT ID, Medida FROM apagados '
                               'WHERE Medida LIKE ? GROUP BY Medida '
                               'ORDER BY Medida', ('%' + vik + '%',)):
            ide, med = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:2}{1:6}{2:5} '
                             '| {3:8} \n'.format('', '', ide, med))
        con.close()
    fil.close()
    htmlapgckid()


def htmlapgckid():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ID DA MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    medid = raw_input('\x1b[s{0:2} ID > '.format(''))
    while not medid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        htmlapagred()
    if medid == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        apagmedsair()
    else:
        usechoidapg(medid)


def usechoidapg(vik):
    with codecs.open('data/temp/htmlapgbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                tblidtohtml(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    htmlapagred()


def tblidtohtml(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Medida FROM apagados WHERE ID=? ', (vik,)):
        med = row[0]
        htmlapahead(med)
    con.close()


def htmlapahead(vik):
    with codecs.open('data/html/apagados_medida.html', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Dat_apagado, Marca, Modelo, Medida, '
                    'Codigo, DO, T, Valor, Armazen FROM apagados '
                    'WHERE Medida = ? ', (vik,))
        head = [i[0] for i in cur.description]
        dat, mar, mod, med, cod, dox, ttx, pre, arm = head
        fil.write(str(
            '<!DOCTYPE html>\n'
            '<html lang="pt-PT">\n'
            '<head>\n'
            '  <link rel="stylesheet" type="text/css" '
            'href="tabela.CSS">\n'
            '  <meta charset="UTF-8">\n'
            '  <title> Tabela Apagados</title>\n'
            '</head>\n'
            '<body>\n'
            '<h1>Tabela Apagados por medida {0}</h1>\n'
            '<table style="width:90%">\n'
            '  <tr>\n'
            '    <th>{1}</th>\n'
            '    <th>{2}</th>\n'
            '    <th>{3}</th>\n'
            '    <th>{4}</th>\n'
            '    <th>{5}</th>\n'
            '    <th>{6}{7}</th>\n'
            '    <th>{8}</th>\n'
            '    <th>{9}</th>\n'
            '  </tr>\n'.format(vik, dat, mar, mod, med, cod,
                               dox, ttx, pre, arm)))
        con.close()
    fil.close()
    htmlapabody(vik)


def htmlapabody(vik):
    with codecs.open('data/html/apagados_medida.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT Dat_apagado, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen FROM apagados '
                'WHERE Medida = ? '
                'ORDER BY Dat_apagado ASC', (vik,)):
            dat, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(
                '  <tr>\n'
                '    <td>{0}</td>\n'
                '    <td>{1}</td>\n'
                '    <td>{2}</td>\n'
                '    <td>{3}</td>\n'
                '    <td>{4}</td>\n'
                '    <td>{5}{6}</td>\n'
                '    <td>{7}</td>\n'
                '    <td>{8}</td>\n'
                '  </tr>\n'.format(dat, mar, mod, med, cod,
                                   dox, ttx, pre, arm)))
        con.close()
    fil.close()
    htmlapacount(vik)


def htmlapacount(vik):
    with codecs.open('data/html/apagados_medida.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM apagados '
                    'WHERE Medida = ?', (vik,))
        fil.write(str(
            '</table>\n'
            '  <p>NOTA:</p>\n'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{0} Entradas\n'
            '</body>\n'
            '</html>\n'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sys.stderr.write('\x1b[u{0:2}TABELA DE APAGADOS EXPORTADA '
                     'EM HTML.'.format(''))
    time.sleep(1)
    webbrowser.open('data/html/apagados_medida.html')
    apagmedsair()


def apagmedsair():
    import data.htmlmedi
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.htmlmedi.htmlmedmain()


def htmlapamedmain():
    htmlapaquest()
    htmlapagred()
    htmltblapachk(vik=None)
    htmltblapghead(vik=None)
    htmlapgckid()
    usechoidapg(vik=None)
    tblidtohtml(vik=None)
    htmlapahead(vik=None)
    htmlapabody(vik=None)
    htmlapacount(vik=None)


if __name__ == '__main__':
    htmlapamedmain()
