#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def inmed():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        inmedquest()
    else:
        con.close()
    inmedquest()


def inmedquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:10}\033[1m{2}\033[0m{3:17}'
        '||\n'.format('', '', 'ESCREVA A MEDIDA POR COMPLETO', ''))
    sys.stdout.write(
        '{0:2}||{1:10}{2}{3:30}'
        '||\n'.format('', '', '\033[1mEXEMPLO:\033[0m 2055516', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        inmedquest()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        inmedsair()
    else:
        with codecs.open('data/temp/inmedchk.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    readinmedfil()


def readinmedfil():
    with codecs.open('data/temp/inmedchk.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            inmedchk(vik)
    fil.close()


def inmedchk(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas WHERE Medida=?', (vik,))
    if not cur.fetchall():
        sys.stdout.write('\x1b[u\x1b[J{0:2}MEDIDA {1} '
                         'INEXISTENTE.'.format('', vik))
        sys.stdout.write('\x1b[1J\x1b[H')
        sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
        sys.stdout.write(
            '{0:2}||{1:2}\033[1m{2}\033[0m\033[1;92m{3:>8}\033[0m{4:11}'
            '||\n'.format('', '', 'ESCREVA O CODIGO NOVO PARA A '
                                  'MEDIDA', vik, ''))
        sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                         '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
        sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
        cod = raw_input('\x1b[s{0:2}CODIGO > '.format(''))
        while not cod:
            sys.stderr.write(
                '\x1b[u\x1b[J{0:2}ESCREVA O CODIGO OU a.'.format(''))
            time.sleep(1.5)
            readinmedfil()
        if cod == 'a':
            sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
            con.close()
            time.sleep(1)
            inmedsair()
        else:
            con.close()
        lastmedin(vik, cod)
    else:
        con.close()
    inmedend(vik)


def inmedend(vik):
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:5}{2}\033[1;92m{3:>10}\033[0m'
        '{4:7}\033[1mEXISTE COM OS CODIGOS\033[0m{5:4}'
        '||\n'.format('', '', '\033[1mA MEDIDA\033[0m ', vik, '', ''))
    sys.stdout.write('{0:2}{1}\n\n'.format('', 60 * '='))
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT Codigo FROM medidas WHERE Medida=?', (vik,))
    hea = [i[0] for i in cur.description]
    cox = hea[0]
    sys.stdout.write('{0:18} \033[1m{1:^4}s\033[0m \n'.format('', cox))
    sys.stdout.write('{0:18}{1}\n'.format('', 10 * '-'))
    for row in cur.fetchall():
        codx = row[0]
        sys.stdout.write('{0:18} {1:>5} \n'.format('', codx))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}||{1:15}\033[1m{2}\033[0m{3:19}'
                     '||\n'.format('', '', 'ESCREVA O CODIGO NOVO ', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    cod = raw_input('\x1b[s{0:2}CODIGO > '.format(''))
    while not cod:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O CODIGO OU a.'.format(''))
        time.sleep(1.5)
        readinmedfil()
    if cod == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        con.close()
        time.sleep(1)
        inmedsair()
    else:
        con.close()
    lastmedin(vik, cod)


def lastmedin(vik, cod):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas '
                'WHERE Medida=? AND Codigo=?', (vik, cod,))
    if not cur.fetchall():
        with con:
            cur.execute('INSERT INTO medidas VALUES(NULL,?,?)', (vik, cod,))
        sys.stderr.write(
            '\x1b[u\x1b[J{0:2}NOVO ID {1} FOI IMPLATADO PARA MEDIDA {2} '
            'COM O CODIGO {3}.'.format('', cur.lastrowid, vik, cod))
        con.close()
        time.sleep(3)
        inmedsair()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}A MEDIDA {1} EXISTE COM O '
                     'CODIGO {2}.'.format('', vik, cod))
    time.sleep(3)
    readinmedfil()


def inmedsair():
    import data.menumedida
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sys.stdout.write('{0:2}| ESCOLHA     INSERIR - i  VOLTAR - v '
                     ' SAIR - s   |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA i, v ou s.'.format(''))
        time.sleep(1.5)
        inmedsair()
    if sair == 'i':
        sys.stderr.write('\x1b[u\x1b[J{0:2}INSERIR DE NOVA '
                         'MEDIDA.'.format(''))
        time.sleep(1)
        inmed()
    elif sair == 'v':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU '
                         'ANTERIOR.'.format(''))
        time.sleep(1)
        data.menumedida.mediauximain()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA i, v ou s.'.format(''))
    time.sleep(1.5)
    inmedsair()


def inmedmain():
    inmed()
    inmedquest()
    readinmedfil()
    inmedchk(vik=None)
    inmedend(vik=None)
    lastmedin(vik=None, cod=None)
    inmedsair()


if __name__ == '__main__':
    inmedmain()
