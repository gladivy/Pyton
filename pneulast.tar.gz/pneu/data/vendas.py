#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def checkpneutbl():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        sairvend()
    else:
        con.close()
    vendquest()


def vendquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:20}VENDA{1:23}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}ESCREVA A MEDIDA DO '
                     'PNEU{1:22}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:31}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        vendquest()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairvend()
    else:
        with codecs.open('data/temp/vendquest.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    vendredfil()


def vendredfil():
    with codecs.open('data/temp/vendquest.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            vendbody(vik)
    fil.close()


def vendbody(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        vendquest()
    else:
        con.close()
    vedtblhead(vik)


def vedtblhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca, Modelo, Medida, Codigo, DO, T, '
                'Valor, Armazen FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, nom, mod, med, cod, dom, doa, pre, arm = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'STOCK'))
    sys.stdout.write(
        '\n{0:2}| {1:5} | {2:^15} | {3:^20} | {4:>7} | {5:6} '
        '| {6:2}{7:<2} | {8:^5} | {9:^15} '
        '|\n'.format('', ide, nom, mod, med, cod, dom, doa, pre, arm))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 100 * '-'))
    con.close()
    vendtblbom(vik)


def vendtblbom(vik):
    with codecs.open('data/temp/vendtblbom.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Marca, Modelo, Medida, Codigo, DO, T, '
                'Valor, Armazen FROM pneusados WHERE Medida LIKE ? '
                'ORDER BY Modelo, ID ASC', ('%' + vik + '%',)):
            ide, nom, mod, med, cod, dom, doa, per, amr = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write(
                '{0:2}| {1:5} | {2:15} | {3:20} | {4:7} | {5:^6} '
                '| {6:2}{7:<2} | {8:^5} | {9:^15} '
                '|\n'.format('', ide, nom, mod, med, cod, dom, doa,
                             per, amr))
        con.close()
    fil.close()
    vndcount(vik)


def vndcount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| FORAM ENCONTRADOS {1:5} RESULTADOS.'
                     '{2:12}|\n'.format('', len(cur.fetchall()), ''))
    con.close()
    vend()


def vend():
    sys.stdout.write('{0:2}|{2} ESCREVA O ID DO PNEU QUE '
                     'VENDEU{1:16}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2} PARA ANULAR - a{1:32}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    apa = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not apa:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        vendredfil()
    if apa == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairvend()
    else:
        with codecs.open('data/temp/vendtblbom.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if apa in ide:
                    fil.close()
                    vendend(apa)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', apa))
        fil.close()
    time.sleep(1)
    vendredfil()


def vendend(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute('INSERT INTO vendidos SELECT NULL, ID, Data_Entrada, '
                    'NULL, Marca, Modelo, Medida, Codigo, Do, T, Valor, '
                    'Armazen FROM pneusados WHERE ID = ?', (vik,))
    tra = cur.lastrowid
    if not tra:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A INSERIR VENDA NA '
                         'TABELA DE VENDAS.'.format(''))
        con.close()
        time.sleep(1)
        sys.stderr.write('\x1b[u\x1b[J{0:2}VENDA ANULADA.'.format(''))
        time.sleep(1)
        sairvend()
    else:
        with con:
            con.execute(
                'UPDATE vendidos SET Data_Venda = ? '
                'WHERE ID = ?', (time.strftime('%d/%m/%y'), tra))
    for row in con.execute('SELECT Data_Venda FROM vendidos '
                           'WHERE ID = ?', (tra,)):
        dat = row[0]
        if dat == (time.strftime('%d/%m/%y')):
            sys.stderr.write(
                '\x1b[u\x1b[J{0:2}DATA DA VENDA {1} DO ID '
                '{2}'.format('', (time.strftime('%d/%m/%y')), vik))
            con.close()
            time.sleep(2)
            vendepneu(vik)
        else:
            con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A INSERIR DATA DA '
                     'VENDA.'.format(''))
    time.sleep(1)
    sys.stderr.write('\x1b[u\x1b[J{0:2}VENDA ANULADA.'.format(''))
    time.sleep(1)
    sairvend()


def vendepneu(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('DELETE FROM pneusados WHERE ID = ?', (vik,))
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados WHERE ID = ?', (vik,))
    if not cur.fetchall():
        sys.stderr.write(' VENDA CONCLUIDA.')
        time.sleep(1.5)
        con.close()
        vendsair()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A TERMINAR VENDA.'.format(''))
    time.sleep(2)
    sys.stderr.write('\x1b[u\x1b[J{0:2}O ID {1} FICOU REGISTADO NA '
                     'TABELA DE STOCK.'.format('', vik))
    time.sleep(3)
    vendsair()


def vendsair():

    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| ESCOLHA      VENDA - v  MENU - m '
                     ' SAIR - s     |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA v, m OU s.'.format(''))
        time.sleep(1.5)
        vendsair()
    if sai == 'v':
        sys.stderr.write('\x1b[u\x1b[J{0:2}OUTRA VENDA.'.format(''))
        time.sleep(1)
        vendmain()
    elif sai == 'm':
        sairvend()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA v, m OU s.'.format(''))
    time.sleep(1.5)
    vendsair()


def sairvend():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU.'.format(''))
    time.sleep(1)
    data.menu.mainmenu()


def vendmain():
    checkpneutbl()
    vendquest()
    vendredfil()
    vendbody(vik=None)
    vedtblhead(vik=None)
    vendtblbom(vik=None)
    vndcount(vik=None)
    vend()
    vendend(vik=None)
    vendepneu(vik=None)
    vendsair()
    sairvend()


if __name__ == '__main__':
    vendmain()
