#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def datain():
    with codecs.open('data/temp/insertemp.csv', 'w', 'utf_8') as fil:
        fil.write(str(time.strftime('%d/%m/%y')))
        fil.write(',')
    fil.close()
    onmark()


def onmark():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas')
    if not cur.fetchall():
        con.close()
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE MARCA VAZIA.'.format(''))
        time.sleep(1)
        choicenovo()
    else:
        con.close()
    marquest()


def marquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}||{1:3}\033[1m{2}\033[0m{3:32}'
                     '||\n'.format('', '', 'ESCREVA MARCA DO PNEU', ''))
    sys.stdout.write(
        '{0:2}||{1:3}\033[1m{2}\033[0m{3:6}'
        '||\n'.format('', '', 'PARA PESQUIZAR PODE USAR UM '
                              'DECREMENTO DA MARCA', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    mar = raw_input('\x1b[s{0:2}MARCA > '.format(''))
    while not mar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MARCA O SEU '
                         'DECREMENTO OU a.'.format(''))
        time.sleep(2)
        marquest()
    if mar == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        insdatasair()
    else:
        with codecs.open('data/temp/onmark.csv', 'w', 'utf_8') as fil:
            fil.write(str(mar))
        fil.close()
    redfilonmark()


def redfilonmark():
    with codecs.open('data/temp/onmark.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            gomark(vik)
    fil.close()


def gomark(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas '
                'WHERE Marca LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        con.close()
        sys.stderr.write('\x1b[u\x1b[J{0:2}MARCA INEXISTENTE.'.format(''))
        time.sleep(1)
        choicenovo()
    else:
        con.close()
    markchoice(vik)


def markchoice(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca FROM marcas '
                'WHERE Marca LIKE ? GROUP BY Marca '
                'ORDER BY Marca ASC', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, mar = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:6} \033[1m{1:^4}\033[0m '
                     '| \033[1m{2:^15}\033[0m \n'.format('', ide, mar))
    sys.stdout.write('{0:6} {1}\n'.format('', 20 * '-'))
    with codecs.open('data/temp/markchoice.csv', 'w', 'utf_8') as fil:
        for row in cur.fetchall():
            idx, mark = row
            fil.write(str(idx))
            fil.write(',')
            sys.stdout.write('{0:6} {1:^4} | '
                             '{2:<15} \n'.format('', idx, mark))
    fil.close()
    con.close()
    choice()


def choice():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:16}'
        '||\n'.format('', '', 'ESCREVA O ID RELATIVO A MARCA DO PNEU ', ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:20}'
        '||\n'.format('', '', '"\033[1;92mnovo\033[0m" \033[1mPARA '
                              'INSERIR UMA NOVA MARCA\033[0m', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID, '
                         'novo OU a.'.format(''))
        time.sleep(1.5)
        redfilonmark()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        insdatasair()
    elif esc == 'novo':
        choicenovo()
    else:
        with codecs.open('data/temp/markchoice.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                vik = lin
                if esc in vik:
                    fil.close()
                    wrtchoice(esc)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', esc))
        fil.close()
    time.sleep(1)
    redfilonmark()


def wrtchoice(esc):
    with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for line in con.execute('SELECT Marca FROM marcas '
                                'WHERE ID=?', (esc,)):
            mar = line[0]
            fil.write(str(mar))
            fil.write(',')
        con.close()
    fil.close()
    redinsertoin()


def choicenovo():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}||{1:2}\033[1m{2}\033[0m{3:31}'
                     '||\n'.format('', '', 'ESCREVA UMA NOVA MARCA ', ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:29}'
        '||\n'.format('', '', '\033[1mCOMO EXEMPLO:\033[0m Brigestone ', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    mar = raw_input('\x1b[s{0:2}MARCA > '.format(''))
    while not mar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA UMA NOVA '
                         'MARCA OU a.'.format(''))
        time.sleep(1.5)
        choicenovo()
    if mar == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        insdatasair()
    else:
        with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
            fil.write(str(mar))
            fil.write(',')
        fil.close()
    redinsertoin()


def redinsertoin():
    with codecs.open('data/temp/insertemp.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            vik = lin[1]
            modeloin(vik)
    fil.close()


def modeloin(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Modelo FROM marcas '
                'WHERE Marca=?', (vik,))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MODELO INEXISTENTE.'.format(''))
        con.close()
        modchonovo(vik)
    else:
        con.close()
    modelchoice(vik)


def modelchoice(vki):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Modelo FROM marcas '
                'WHERE Marca=?', (vki,))
    head = [i[0] for i in cur.description]
    ide, mod = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:6} \033[1m{1:^4}\033[0m '
                     '| \033[1m{2:^15}\033[0m \n'.format('', ide, mod))
    sys.stdout.write('{0:6} {1}\n'.format('', 30 * '-'))
    with codecs.open('data/temp/modelchoice.csv', 'w', 'utf_8') as fil:
        for row in cur.fetchall():
            idx, mox = row
            fil.write(str(idx))
            fil.write(',')
            sys.stdout.write('{0:6} {1:^4} | {2:<15} \n'.format('', idx, mox))
    fil.close()
    con.close()
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:15}'
        '||\n'.format('', '', 'ESCREVA O ID RELATIVO A MODELO DO PNEU ', ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:20}'
        '||\n'.format('', '', '"\033[1;92mnovo\033[0m" \033[1mPARA '
                              'INSERIR UM NOVO MODELO\033[0m', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    modcho()


def modcho():
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID, '
                         'novo OU a.'.format(''))
        time.sleep(1.5)
        redinsertoin()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        insdatasair()
    elif esc == 'novo':
        readfornewmod()
    else:
        with codecs.open('data/temp/modelchoice.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if esc in ide:
                    fil.close()
                    insermod(esc)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', esc))
        fil.close()
    time.sleep(1)
    redinsertoin()


def insermod(vik):
    with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for line in con.execute('SELECT Modelo FROM marcas '
                                'WHERE ID=?', (vik,)):
            mod = line[0]
            fil.write(str(mod))
            fil.write(',')
        con.close()
    fil.close()
    redtochkinsrt()


def readfornewmod():
    with codecs.open('data/temp/insertemp.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            vik = lin[1]
            modchonovo(vik)
    fil.close()


def modchonovo(vik):
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m\033[1;92m{3:15}\033[0m{4:8}'
        '||\n'.format('', '', 'ESCREVA UM MODELO PARA A MARCA ', vik, ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:27}'
        '||\n'.format('', '', '\033[1mCOMO EXEMPLO:\033[0m '
                              'Turanza T001 ', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    mod = raw_input('\x1b[s{0:2}MODELO > '.format(''))
    while not mod:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O MODELO OU a.'.format(''))
        time.sleep(1.5)
        readfornewmod()
    if mod == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        insdatasair()
    else:
        with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
            fil.write(str(mod))
            fil.write(',')
        fil.close()
    redtochkinsrt()


def redtochkinsrt():
    with codecs.open('data/temp/insertemp.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            mar = lin[1]
            mod = lin[2]
            insrt(mar, mod)
    fil.close()


def insrt(mar, mod):
    import data.insdacont
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT Marca, Modelo FROM marcas '
                'WHERE Marca=? AND Modelo=? ', (mar, mod,))
    if not cur.fetchall():
        with con:
            cur.execute('INSERT INTO marcas '
                        'VALUES(NULL,?,?)', (mar, mod,))
        sys.stderr.write('\x1b[u\x1b[J{0:2}NOVO ID {1} IMPLATADO PARA A '
                         'MARCA {2}.'.format('', cur.lastrowid, mar))
        con.close()
        time.sleep(1.5)
        sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
        time.sleep(1)
        data.insdacont.mainincont()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
    time.sleep(1)
    data.insdacont.mainincont()


def insdatasair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| ESCOLHA  NOVO REGISTO - r  MENU - m '
                     ' SAIR - s  |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, m ou s.'.format(''))
        time.sleep(1.5)
        insdatasair()
    if sai == 'r':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A REINICIAR REGISTO.'.format(''))
        time.sleep(1)
        maininser()
    elif sai == 'm':
        vltmenu()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        insdatasair()


def vltmenu():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU.'.format(''))
    time.sleep(1)
    data.menu.mainmenu()


def maininser():
    datain()
    onmark()
    marquest()
    redfilonmark()
    gomark(vik=None)
    markchoice(vik=None)
    choice()
    wrtchoice(esc=None)
    choicenovo()
    redinsertoin()
    modeloin(vik=None)
    modelchoice(vki=None)
    modcho()
    insermod(vik=None)
    modchonovo(vik=None)
    redtochkinsrt()
    insrt(mar=None, mod=None)
    insdatasair()
    vltmenu()


if __name__ == '__main__':
    maininser()
