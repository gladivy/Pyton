#!/usr/bin/python
# coding: utf-8
import codecs
import sys
import sqlite3
import time
import webbrowser


def stkhtmlhead():
    with codecs.open('data/html/stock_total.html', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT * FROM pneusados')
        head = [i[0] for i in cur.description]
        ide, dat, mar, mod, med, cod, dox, ttx, pre, arm = head
        fil.write(str(
            '<!DOCTYPE html>\n'
            '<html lang="pt-PT">\n'
            '<head>\n'
            '  <link rel="stylesheet" type="text/css" '
            'href="tabela.CSS">\n'
            '  <meta charset="UTF-8">\n'
            '  <title> Tabela Stock</title>\n'
            '</head>\n'
            '<body>\n'
            '<h1>Tabela Stock</h1>\n'
            '<table style="width:90%">\n'
            '  <tr>\n'
            '    <th>{0}</th>\n'
            '    <th>{1}</th>\n'
            '    <th>{2}</th>\n'
            '    <th>{3}</th>\n'
            '    <th>{4}</th>\n'
            '    <th>{5}</th>\n'
            '    <th>{6}{7}</th>\n'
            '    <th>{8}</th>\n'
            '    <th>{9}</th>\n'
            '  </tr>\n'.format(ide, dat, mar, mod, med, cod, dox,
                               ttx, pre, arm)))
        con.close()
    fil.close()
    stkhtmlbody()


def stkhtmlbody():
    with codecs.open('data/html/stock_total.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT * FROM pneusados'):
            ide, dat, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(
                '  <tr>\n'
                '    <td>{0}</td>\n'
                '    <td>{1}</td>\n'
                '    <td>{2}</td>\n'
                '    <td>{3}</td>\n'
                '    <td>{4}</td>\n'
                '    <td>{5}</td>\n'
                '    <td>{6}{7}</td>\n'
                '    <td>{8}</td>\n'
                '    <td>{9}</td>\n'
                '  </tr>\n'.format(ide, dat, mar, mod, med, cod, dox,
                                   ttx, pre, arm)))
        con.close()
    fil.close()
    stkhtmlcount()


def stkhtmlcount():
    with codecs.open('data/html/stock_total.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados')
        fil.write(str(
            '</table>\n'
            '  <p>NOTA:</p>\n'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{0} Entradas\n'
            '</body>\n'
            '</html>\n'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sairstkhtml()


def sairstkhtml():
    import data.htmlcomp
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE STOCK EXPORTADA '
                     'EM HTML.'.format(''))
    time.sleep(1)
    webbrowser.open('data/html/stock_total.html')
    data.htmlcomp.compmain()


def exphtmlstkmain():
    stkhtmlhead()
    stkhtmlbody()
    stkhtmlcount()
    sairstkhtml()


if __name__ == '__main__':
    exphtmlstkmain()
