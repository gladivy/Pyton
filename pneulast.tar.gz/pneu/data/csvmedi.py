#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def prmedida():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write(
        '{0:2}|{1:21}{2}{3:23}'
        '|\n'.format('', '', '\033[1mEXPORTAR EM CSV POR MEDIDA\033[0m', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '1 - STOKE', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:40}'
                     '|\n'.format('', '', '2 - VENDAS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:38}'
                     '|\n'.format('', '', '3 - APAGADOS', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:49}'
                     '|\n'.format('', '', 'VOLTAR - v SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
        time.sleep(1.5)
        medidamenu()
    if esc == '1':
        stockporcsv()
    elif esc == '2':
        vendacsv()
    elif esc == '3':
        apagacsv()
    elif esc == 'v':
        menuvoltar()
    elif esc == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
    time.sleep(1.5)
    medidamenu()


def stockporcsv():
    import data.expcsvstok
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        medidamenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}EXPORTAR STOCK EM CSV '
                     'POR MEDIDA.'.format(''))
    time.sleep(1)
    data.expcsvstok.csvstokmain()


def vendacsv():
    import data.csvendmed
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        medidamenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}EXPORTAR VENDA EM CSV '
                     'POR MEDIDA.'.format(''))
    time.sleep(1)
    data.csvendmed.csvendmedmain()


def apagacsv():
    import data.expcsvapamedi
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        medidamenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}EXPORTAR APAGADOS EM CSV '
                     'POR MEDIDA.'.format(''))
    time.sleep(1)
    data.expcsvapamedi.csvmedmain()


def menuvoltar():
    import data.menuexpcsv
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menuexpcsv.csvmain()


def medidamenu():
    prmedida()
    stockporcsv()
    vendacsv()
    apagacsv()
    menuvoltar()


if __name__ == '__main__':
    prmedida()
