#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def medtblchk():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        sairapagmod()
    else:
        con.close()
    apamedquest()


def apamedquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:6}\033[1m{2}\033[0m{3:14}'
        '||\n'.format('', '', 'ESCREVA A MEDIDA QUE PRETENDE APAGAR', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        apamedquest()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        apgmodsair()
    else:
        with codecs.open('data/temp/apamedquest.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    apamedquestredfil()


def apamedquestredfil():
    with codecs.open('data/temp/apamedquest.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            apamedbody(vik)
    fil.close()


def apamedbody(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        apamedquest()
    else:
        con.close()
    apamedhead(vik)


def apamedhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM medidas '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'MEDIDA'))
    sys.stdout.write('\n{0:4} \033[1m{1:4}\033[0m | '
                     '\033[1m{2:15}\033[0m \n'.format('', ide, med))
    sys.stdout.write('{0:2}{1}\n'.format('', 43 * '-'))
    con.close()
    apamedbot(vik)


def apamedbot(vik):
    with codecs.open('data/temp/apamedbot.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Medida FROM medidas WHERE Medida LIKE ? '
                'GROUP BY Medida ORDER BY Medida ASC', ('%' + vik + '%',)):
            ide, med = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:4} {1:4} | {2:15} \n'.format('', ide, med))
        con.close()
    fil.close()
    apagescol()


def apagescol():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 58 * '='))
    sys.stdout.write('{0:2}||{1:2}\033[1mESCOLHA O ID DA MEDIDA QUE PRETENDE '
                     'APAGAR\033[0m{2:10}||\n'.format('', '', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:35}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 58 * '='))
    ide = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        apamedquestredfil()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        apgmodsair()
    else:
        apagescolredchk(ide)


def apagescolredchk(vik):
    with codecs.open('data/temp/apamedbot.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                idtack(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    apamedquestredfil()


def idtack(vik):
    with codecs.open('data/temp/idtack.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT Medida FROM medidas '
                               'WHERE ID=?', (vik,)):
            med = row[0]
            fil.write(str(med))
        con.close()
    fil.close()
    idtackredfil()


def idtackredfil():
    with codecs.open('data/temp/idtack.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            apacodbody(vik)
    fil.close()


def apacodbody(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Codigo FROM medidas WHERE Medida=?', (vik,))
    head = [i[0] for i in cur.description]
    ide, cod = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3} '
                     '{4}\033[0m.\n'.format('', 'TABELA', '',
                                            'CODIGOS DA MEDIDA ', vik))
    sys.stdout.write('\n{0:4} \033[1m{1:4}\033[0m | '
                     '\033[1m{2:20}\033[0m \n'.format('', ide, cod))
    sys.stdout.write('{0:2}{1}\n'.format('', 20 * '-'))
    con.close()
    apabodycont(vik)


def apabodycont(vik):
    with codecs.open('data/temp/apabodycont.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Codigo FROM medidas WHERE Medida=? '
                'ORDER BY Codigo ASC', (vik,)):
            ide, cod = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:4} {1:4} | {2:5} \n'.format('', ide, cod))
        con.close()
    fil.close()
    apgmdfin()


def apgmdfin():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 58 * '='))
    sys.stdout.write('{0:2}||{1:2}\033[1mESCOLHA O ID DO CODIGO QUE PRETENDE '
                     'APAGAR\033[0m{2:10}||\n'.format('', '', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:34}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 58 * '='))
    codid = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not codid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        idtackredfil()
    if codid == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        apgmodsair()
    else:
        apgmdfinredchk(codid)


def apgmdfinredchk(vik):
    with codecs.open('data/temp/apabodycont.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                apamodid(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    idtackredfil()


def apamodid(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('DELETE FROM medidas WHERE ID=?', (vik,))
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas WHERE ID=?', (vik,))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} APAGADO.'.format('', vik))
        con.close()
        time.sleep(1.5)
        apgmodsair()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO APAGAR O '
                         'ID {1}.'.format('', vik))
    con.close()
    time.sleep(1)
    apgmodsair()


def apgmodsair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 52 * '='))
    sys.stdout.write('{0:2}|     ESCOLHA  APAGAR - a  VOLTAR - v '
                     ' SAIR - s    |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 52 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
        time.sleep(1.5)
        apgmodsair()
    if sair == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR APAGAR OUTRA '
                         'MEDIDA.'.format(''))
        time.sleep(1)
        medilmain()
    elif sair == 'v':
        sairapagmod()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
    time.sleep(1.5)
    apgmodsair()


def sairapagmod():
    import data.menumedida
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menumedida.mediauximain()


def medilmain():
    medtblchk()
    apamedquest()
    apamedquestredfil()
    apamedbody(vik=None)
    apamedhead(vik=None)
    apamedbot(vik=None)
    apagescol()
    apagescolredchk(vik=None)
    idtack(vik=None)
    idtackredfil()
    apacodbody(vik=None)
    apabodycont(vik=None)
    apgmdfin()
    apgmdfinredchk(vik=None)
    apamodid(vik=None)
    apgmodsair()
    sairapagmod()


if __name__ == '__main__':
    medilmain()
