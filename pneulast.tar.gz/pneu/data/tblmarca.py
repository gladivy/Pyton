#!/usr/bin/python
# coding: utf-8
import collections
import sys
import sqlite3
import time


def tblmodhead():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca, Modelo FROM marcas')
    head = [i[0] for i in cur.description]
    idx, marx, modlx = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'MARCA E MODELOS'))
    sys.stdout.write('\n{0:4} \033[1m{1:^5}\033[0m | \033[1m{2:^15}\033[0m | '
                     '\033[1m{3:^20}\033[0m \n'.format('', idx, marx, modlx))
    sys.stdout.write('{0:2}{1}\n'.format('', 43 * '-'))
    con.close()
    tblmodcount()


def tblmodcount():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    lom = []
    cur.execute('SELECT ID, Marca, Modelo FROM marcas '
                'ORDER BY Marca ASC')
    qua = cur.fetchall()
    for row in qua:
        idx, marm, modm = row
        lom.append(marm)
        sys.stdout.write('{0:4} {1:5} | {2:15} '
                         '| {3:20} \n'.format('', idx, marm, modm))
    sys.stdout.write('\n\n{0:2} \033[1m{1:10}   '
                     '{2:20}\033[0m\n'.format('', 'QUANTIDADE', 'MARCA'))
    for ink, kit in collections.Counter(lom).most_common():
        sys.stdout.write('{0:2} {1:>10}   {2:<20}\n'.format('', kit, ink))
    sys.stdout.write('{0:2}\033[1m{1:5}\033[0m'
                     '{2:>5}\n\n'.format('', ' TOTAL', len(qua)))
    con.close()
    tblmodlsair()


def tblmodlsair():
    import data.menumodelo
    sys.stdout.write('\n{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA        VOLTAR - v '
                     '  SAIR - s {1:9}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA v OU s.'.format(''))
        time.sleep(1.5)
        tblmodmain()
    if sair == 'v':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU '
                         'ANTERIOR.'.format(''))
        time.sleep(1)
        data.menumodelo.modeauxmain()
    if sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA v OU s.'.format(''))
    time.sleep(1.5)
    tblmodmain()


def tblmodmain():
    tblmodhead()
    tblmodcount()
    tblmodlsair()


if __name__ == '__main__':
    tblmodmain()
