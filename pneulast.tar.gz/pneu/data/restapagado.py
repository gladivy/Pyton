#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def restapatbl():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        sairestapag()
    else:
        con.close()
    restamppesq()


def restamppesq():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCREVA A MEDIDA DO PNEU PARA '
                     'RESTAURAR{1:7}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:31}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    rts = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not rts:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        restamppesq()
    if rts == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairestapag()
    else:
        with codecs.open('data/temp/restamppesq.csv', 'w', 'utf_8') as fil:
            fil.write(str(rts))
        fil.close()
    resapagredfil()


def resapagredfil():
    with codecs.open('data/temp/restamppesq.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            restampin(vik)
    fil.close()


def restampin(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA {1} '
                         'INEXISTENTE.'.format('', vik))
        con.close()
        time.sleep(1)
        restamppesq()
    else:
        con.close()
    restapaghead(vik)


def restapaghead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Oldid, Dat_apagado, Marca, '
                'Modelo, Medida, Codigo, DO, T, Armazen '
                'FROM apagados WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, old, daa, mar, mod, med, cod, dox, ttx, arm = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n\n'.format('', 'TABELA', ' ', 'APAGADOS'))
    sys.stdout.write(
        '{0:2}| \033[92m{1:^5}\033[0m | {2:5} | {3:^16} | {4:^15} |'
        ' {5:^20} | {6:>7} | {7:6} | {8:2}{9:<2} | {10:^15} '
        '|\n'.format('', ide, old, daa, mar, mod, med, cod, dox, ttx, arm))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 119 * '-'))
    con.close()
    restampbody(vik)


def restampbody(vik):
    with codecs.open('data/temp/restampbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Oldid, Dat_apagado, Marca, '
                'Modelo, Medida, Codigo, DO, T, Armazen '
                'FROM apagados WHERE Medida LIKE ? '
                'ORDER BY Oldid', ('%' + vik + '%',)):
            ide, old, daa, mar, mod, med, cod, dox, ttx, arm = row
            sys.stdout.write(
                '{0:2}| \033[92m{1:5}\033[0m | {2:5} | {3:^16} | {4:15} '
                '| {5:20} | {6:>7} | {7:6} | {8:2}{9:<2} | {10:>15} '
                '|\n'.format('', ide, old, daa, mar, mod, med, cod,
                             dox, ttx, arm))
            fil.write(str(ide))
            fil.write(',')
        con.close()
    fil.close()
    restcount(vik)


def restcount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT Modelo FROM apagados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    sys.stdout.write(
        '\n{0:2}{1}{2:>6}\n\n'.format('', 'TOTAL', len(cur.fetchall())))
    con.close()
    reapaqes()


def reapaqes():
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA O ID A \033[92mVERDE\033[0m'
                     ' DO PNEU PARA RESTAURAR{1:3}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:31}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        resapagredfil()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairestapag()
    else:
        with codecs.open('data/temp/restampbody.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if esc in ide:
                    fil.close()
                    reastcheck(esc)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', esc))
        fil.close()
    time.sleep(1)
    resapagredfil()


def reastcheck(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT ID, Oldid FROM apagados '
                           'WHERE ID LIKE ?', (vik,)):
        ide, oldid = row
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados WHERE ID LIKE ?', (oldid,))
        if not cur.fetchall():
            con.close()
            reastend(vik)
        else:
            sys.stderr.write(
                '\x1b[u{0:2}O \033[92mID {1}\033[0m EXISTE COM O ID {2} '
                'NA TABELA DE STOCK.'.format('', ide, oldid))
    con.close()
    time.sleep(1.5)
    resapagredfil()


def reastend(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('INSERT INTO pneusados SELECT Oldid, Data_Entrada, '
                    'Marca, Modelo, Medida, Codigo, DO, T, Valor, '
                    'Armazen FROM apagados WHERE ID LIKE ?', (vik,))
    for row in con.execute('SELECT ID, Oldid FROM apagados '
                           'WHERE ID LIKE ?', (vik,)):
        ide, oldid = row
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados WHERE ID LIKE ?', (oldid,))
        if not cur.fetchall():
            sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO AO RECUPERAR O '
                             'ID {1}.'.format('', vik))
        else:
            sys.stderr.write('\x1b[u\x1b[J{0:2}O ID {1} RECUPEROU O ID {2} '
                             'NA TABELA DE STOCK.'.format('', ide, oldid))
    con.close()
    time.sleep(1)
    con.close()
    reapasair()


def reapasair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 56 * '='))
    sys.stdout.write('{0:2}|  ESCOLHA     RESTAURAR - r   VOLTAR - v '
                     '  SAIR - s{1:3}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 56 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, v OU s.'.format(''))
        time.sleep(1.5)
        reapasair()
    if sai == 'r':
        sys.stderr.write('\x1b[u\x1b[J{0:2}RESTAURAR NOVAMENTE.'.format(''))
        time.sleep(1)
        reapamain()
    elif sai == 'v':
        sairestapag()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, v OU s.'.format(''))
    time.sleep(1.5)
    reapasair()


def sairestapag():
    import data.restaurar
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.restaurar.restmain()


def reapamain():
    restapatbl()
    restamppesq()
    resapagredfil()
    restampin(vik=None)
    restampbody(vik=None)
    restcount(vik=None)
    reapaqes()
    reastcheck(vik=None)
    reastend(vik=None)
    reapasair()
    sairestapag()


if __name__ == '__main__':
    reapamain()
