#!/usr/bin/env python
# coding: utf-8
import sys
import sqlite3
import time


def bacup():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:27}\033[1m{2}\033[0m{3:32}'
                     '|\n'.format('', '', 'BACKUP MENU', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:29}'
                     '|\n'.format('', '', 't - TABELA DE BACKUPS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:31}'
                     '|\n'.format('', '', 'f - FAZER UM BACKUP', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:30}'
                     '|\n'.format('', '', 'r - RESTAURAR BACKUP', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:30}'
                     '|\n'.format('', '', 'a - APAGAR UM BACKUP', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:45}'
                     '|\n'.format('', '', 'UTILIDADES - u SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    bak = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not bak:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         'f, r, a OU u, s.'.format(''))
        time.sleep(1.5)
        bacupmain()
    if bak == 'f':
        beckupfazer()
    elif bak == 't':
        backtblvew()
    elif bak == 'r':
        beckuprest()
    elif bak == 'a':
        backuapagar()
    elif bak == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(14)
    elif bak == 'u':
        backuptoutil()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         'f, r, a OU u, s.'.format(''))
    time.sleep(1.5)
    bacupmain()


def beckupfazer():
    import data.fazback
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA STOCK VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        sys.stderr.write('\x1b[u\x1b[J{0:2}FAZER BACKUP.'.format(''))
        time.sleep(1)
        data.fazback.backupmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}FAZER BACKUP.'.format(''))
    time.sleep(1)
    data.fazback.backupmain()


def backtblvew():
    import data.backuptbl
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}SEM BACKUPS.'.format(''))
        con.close()
        time.sleep(1)
        bacupmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA BACKUPS.'.format(''))
    time.sleep(1)
    data.backuptbl.baktablmain()


def beckuprest():
    import data.rebackup
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}SEM BACKUPS.'.format(''))
        con.close()
        time.sleep(1)
        bacupmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}RESTAURAR BACKUP.'.format(''))
    time.sleep(1)
    data.rebackup.restbackmain()


def backuapagar():
    import data.apagback
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}SEM BACKUPS.'.format(''))
        con.close()
        time.sleep(1)
        bacupmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}APAGAR BACKUP.'.format(''))
    time.sleep(1)
    data.apagback.elemain()


def backuptoutil():
    import data.utilidades
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU UTILIDADES.'.format(''))
    time.sleep(1)
    data.utilidades.utilmain()


def bacupmain():
    bacup()
    beckupfazer()
    beckuprest()
    backuapagar()


if __name__ == '__main__':
    bacupmain()
