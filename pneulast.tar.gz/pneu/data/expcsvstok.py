#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import collections
import sys
import sqlite3
import time
import webbrowser


def expfim():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{1:10}\033[1mEXPORTAR STOCK EM FORMATO '
                     'CSV\033[0m{2:13}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA A MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    med = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        expfim()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saircsvstk()
    else:
        with codecs.open('data/temp/expfim.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    expfimrefil()


def expfimrefil():
    with codecs.open('data/temp/expfim.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            expstktbl(vik)
    fil.close()


def expstktbl(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        expfim()
    else:
        con.close()
    expstkmedhead(vik)


def expstkmedhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM pneusados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} \n'.format('', '', ide, med))
    sys.stdout.write('{0:2}{1}\n'.format('', 35 * '-'))
    con.close()
    expstkmedbody(vik)


def expstkmedbody(vik):
    with codecs.open('data/temp/expstkmedbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT ID, Medida FROM pneusados '
                               'WHERE Medida LIKE ? GROUP BY Medida '
                               'ORDER BY Medida', ('%' + vik + '%',)):
            ide, med = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:2}{1:6}{2:5} '
                             '| {3:8} \n'.format('', '', ide, med))
        con.close()
    fil.close()
    expstkmedquest()


def expstkmedquest():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ID DA MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    medid = raw_input('\x1b[s{0:2} ID > '.format(''))
    while not medid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        expfimrefil()
    if medid == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saircsvstk()
    else:
        expstkcheker(medid)


def expstkcheker(vik):
    with codecs.open('data/temp/expstkmedbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                csvstkexport(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    expfimrefil()


def csvstkexport(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Medida '
                           'FROM pneusados WHERE ID=? ', (vik,)):
        med = row[0]
        csvstktblhead(med)


def csvstktblhead(vik):
    with codecs.open('data/csv/stock_medida.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID, Data_Entrada, Marca, Modelo, Medida '
                    'FROM pneusados WHERE Medida=? ', (vik,))
        fil.write(str('STOCK POR MEDIDA'))
        fil.write(',')
        fil.write(str(vik))
        fil.write('\n')
        fil.write('')
        fil.write('\n')
        head = [i[0] for i in cur.description]
        idx, dtx, mrx, mdx, mex = head
        fil.write(str(idx))
        fil.write(',')
        fil.write(str(dtx))
        fil.write(',')
        fil.write(str(mrx))
        fil.write(',')
        fil.write(str(mdx))
        fil.write(',')
        fil.write(str(mex))
        fil.write(',')
        con.close()
    fil.close()
    csvstkheadend(vik)


def csvstkheadend(vik):
    with codecs.open('data/csv/stock_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Codigo, DO, T, Valor, Armazen '
                    'FROM pneusados WHERE Medida=?', (vik,))
        head = [i[0] for i in cur.description]
        cdx, dox, ttx, pex, amx = head
        fil.write(str(cdx))
        fil.write(',')
        fil.write(str('{0}{1}'.format(dox, ttx)))
        fil.write(',')
        fil.write(str(pex))
        fil.write(',')
        fil.write(str(amx))
        fil.write('\n')
        con.close()
    fil.close()
    csvstktblbody(vik)


def csvstktblbody(vik):
    with codecs.open('data/csv/stock_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Data_Entrada, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen '
                'FROM pneusados WHERE Medida=? '
                'ORDER BY Medida ASC', (vik,)):
            ide, dat, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(ide))
            fil.write(',')
            fil.write(str(dat))
            fil.write(',')
            fil.write(str(mar))
            fil.write(',')
            fil.write(str(mod))
            fil.write(',')
            fil.write(str(med))
            fil.write(',')
            fil.write(str(cod))
            fil.write(',')
            fil.write(str('{0}{1}'.format(dox, ttx)))
            fil.write(',')
            fil.write(str(pre))
            fil.write(',')
            fil.write(str(arm))
            fil.write('\n')
        con.close()
    fil.close()
    expcsvstkcount(vik)


def expcsvstkcount(vik):
    with codecs.open('data/csv/stock_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados WHERE Medida=?', (vik,))
        fil.write('\n')
        fil.write(str('{0} Entradas'.format(len(cur.fetchall()))))
        fil.write('\n')
        con.close()
    fil.close()
    csvstkmedcount(vik)


def csvstkmedcount(vik):
    with codecs.open('data/csv/stock_medida.csv', 'a', 'utf_8') as fil:
        lod = []
        hod = []
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT Modelo, Codigo FROM pneusados '
                               'WHERE Medida=?', (vik,)):
            mod, cod = row
            lod.append(str(mod))
            hod.append(str(cod))
        num = []
        let = []
        for mdi, k in collections.Counter(zip(lod, hod)).most_common():
            if k >= 2:
                num.append(k)
                let.append(' '.join(mdi))
        for nix, lox in zip(num, let):
            fil.write(str('{0} - {1}'.format(nix, lox)))
        con.close()
    fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE STOCKS '
                     'EXPORTADA EM CSV.'.format(''))
    time.sleep(1)
    webbrowser.open('data/csv/stock_medida.csv')
    saircsvstk()


def saircsvstk():
    import data.csvmedi
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.csvmedi.prmedida()


def csvstokmain():
    expfim()
    expfimrefil()
    expstktbl(vik=None)
    expstkmedhead(vik=None)
    expstkmedbody(vik=None)
    expstkmedquest()
    expstkcheker(vik=None)
    csvstkexport(vik=None)
    csvstktblhead(vik=None)
    csvstkheadend(vik=None)
    csvstktblbody(vik=None)
    expcsvstkcount(vik=None)
    csvstkmedcount(vik=None)
    saircsvstk()


if __name__ == '__name__':
    csvstokmain()
