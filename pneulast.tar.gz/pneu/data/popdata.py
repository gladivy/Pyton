#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import os
import sys
import sqlite3
import time


def csvtoqlite():
    if not os.path.exists('data/temp/insertemp.csv'):
        sys.stderr.write('\x1b[u{0:2}ERRO FALTA O FICHEIRO > '
                         'insertemp.csv.'.format(''))
        time.sleep(2)
        voltmenu()
    else:
        csvin()


def csvin():
    with codecs.open('data/temp/insertemp.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            dat, nom, mod, med, cod, dom, doa, pre, arm = lin
            con = sqlite3.connect('data/database/database.db')
            with con:
                cur = con.cursor()
                cur.execute(
                    'INSERT INTO pneusados '
                    'VALUES(NULL,?,?,?,?,?,?,?,?,?)',
                    (dat, nom, mod, med, cod, dom, doa, pre, arm))
            sys.stderr.write('\x1b[u\x1b[J{0:2}NOVO ID {1} INSERIDO '
                             'NO STOCK.'.format('', cur.lastrowid))
            con.close()
    fil.close()
    time.sleep(1)
    voltmenu()


def voltmenu():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU.'.format(''))
    time.sleep(1)
    data.menu.mainmenu()


def incsvmain():
    csvtoqlite()
    csvin()
    voltmenu()


if __name__ == '__main__':
    incsvmain()
