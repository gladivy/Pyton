#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def modos():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write(
        '{0:2}|{1:17}\033[1m{2}\033[0m{3:24}'
        '|\n'.format('', '', 'PARA ANALIZAR DADOS ALTERADOS', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:39}'
                     '|\n'.format('', '', '1 - ARMAZEN', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '2 - VALOR', ''))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:2}{4}{5:47}'
                     '|\n'.format('', '', 'TABELAS - t', '', 'SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU t, s.'.format(''))
        time.sleep(1.5)
        modimain()
    if esc == '1':
        fcharmaz()
    elif esc == '2':
        fchpreco()
    elif esc == 't':
        voltmentbl()
    elif esc == 's':
        sairmodif()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU t, s.'.format(''))
    time.sleep(1.5)
    modimain()


def fcharmaz():
    import data.modosaltarm
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazenalt')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        modimain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}PNEUS QUE MODIFICARAM DE '
                     'ARMAZEN.'.format(''))
    time.sleep(1)
    data.modosaltarm.modosarmmain()


def fchpreco():
    import data.modosaltpre
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM precoalt')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        modimain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}PNEUS QUE MODIFICARAM DE '
                     'VALOR.'.format(''))
    time.sleep(1)
    data.modosaltpre.modospremain()


def voltmentbl():
    import data.tabelas
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU TABELAS.'.format(''))
    time.sleep(1)
    data.tabelas.tabmenumain()


def sairmodif():
    sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
    time.sleep(1)
    sys.stderr.write('\x1b[2J\x1b[H')
    sys.exit(10)


def modimain():
    modos()
    fcharmaz()
    fchpreco()
    voltmentbl()
    sairmodif()


if __name__ == '__main__':
    modimain()
