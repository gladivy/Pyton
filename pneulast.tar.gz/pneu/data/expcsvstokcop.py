#!/usr/bin/python
# coding: utf-8
import codecs
import sys
import sqlite3
import time
import webbrowser


def csvstokall():
    with codecs.open('data/csv/stock_total.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID, Marca, Modelo, Medida, Codigo, DO, T, '
                    'Valor, Armazen FROM pneusados')
        fil.write(str('STOCK'))
        fil.write('\n')
        fil.write('')
        fil.write('\n')
        head = [i[0] for i in cur.description]
        idx, mrx, mdx, mex, cdx, dox, ttx, pex, amx = head
        fil.write(str(idx))
        fil.write(',')
        fil.write(str(mrx))
        fil.write(',')
        fil.write(str(mdx))
        fil.write(',')
        fil.write(str(mex))
        fil.write(',')
        fil.write(str(cdx))
        fil.write(',')
        fil.write(str('{0}{1}'.format(dox, ttx)))
        fil.write(',')
        fil.write(str(pex))
        fil.write(',')
        fil.write(str(amx))
        fil.write('\n')
        con.close()
    fil.close()
    csvbodystk()


def csvbodystk():
    with codecs.open('data/csv/stock_total.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT ID, Marca, Modelo, Medida, Codigo, '
                               'DO, T, Valor, Armazen FROM pneusados'):
            ide, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(ide))
            fil.write(',')
            fil.write(str(mar))
            fil.write(',')
            fil.write(str(mod))
            fil.write(',')
            fil.write(str(med))
            fil.write(',')
            fil.write(str(cod))
            fil.write(',')
            fil.write(str('{0}{1}'.format(dox, ttx)))
            fil.write(',')
            fil.write(str(pre))
            fil.write(',')
            fil.write(str(arm))
            fil.write('\n')
        con.close()
    fil.close()
    csvcountstk()


def csvcountstk():
    with codecs.open('data/csv/stock_total.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados')
        fil.write('\n')
        fil.write(str('{0} Entradas'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sairstkcsv()


def sairstkcsv():
    import data.csvcomp
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE STOCKS '
                     'EXPORTADA EM CSV.'.format(''))
    time.sleep(1)
    webbrowser.open('data/csv/stock_total.csv')
    data.csvcomp.compmenu()


def csvstkal():
    csvstokall()
    csvbodystk()
    csvcountstk()
    sairstkcsv()


if __name__ == '__name__':
    csvstkal()
