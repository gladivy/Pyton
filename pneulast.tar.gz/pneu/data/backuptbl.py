#!/usr/bin/env python
# coding: utf-8
import sys
import sqlite3
import time


def baktblhead():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM dados')
    head = [i[0] for i in cur.description]
    ide, dix, nom, det = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    sys.stdout.write(
        '{0:2}|{1:3} {2:>3} | {3:^8} | Mês {4:4} | '
        '{5:20}|\n'.format('', '', ide, nom, dix, det))
    sys.stdout.write('{0:2}|{1:4} {2} {3:4}'
                     '|\n'.format('', '', 42 * '-', ''))
    con.close()
    baktblbody()


def baktblbody():
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT * FROM dados'):
        idx, dix, nomx, det = row
        sys.stdout.write('{0:2}|{1:3} {2:3} | {3:^8} | {4:^8} '
                         '| {5:20}|\n'.format('', '', idx, nomx, dix, det))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    con.close()
    bakcount()


def bakcount():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados')
    sys.stdout.write('\n{0:2}{1:5}'
                     '{2:>5}\n'.format('', 'TOTAL', len(cur.fetchall())))
    con.close()
    sairbacktbl()


def sairbacktbl():
    import data.backup
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA       VOLTAR - v '
                     '  SAIR - s {1:10}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    if not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA v OU s.'.format(''))
        time.sleep(1.5)
        baktablmain()
    if sair == 'v':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU '
                         'ANTERIOR.'.format(''))
        time.sleep(1)
        data.backup.bacupmain()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA t OU s.'.format(''))
    time.sleep(1.5)
    baktablmain()


def baktablmain():
    baktblhead()
    baktblbody()
    bakcount()
    sairbacktbl()


if __name__ == '__main__':
    baktablmain()
