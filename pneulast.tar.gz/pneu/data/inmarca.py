#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def inmark():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        inmarkquest()
    else:
        con.close()
    inmarkquest()


def inmarkquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:10}\033[1m{2}\033[0m{3:18}'
        '||\n'.format('', '', 'ESCREVA A MARCA POR COMPLETO', ''))
    sys.stdout.write(
        '{0:2}||{1:10}{2}{3:27}'
        '||\n'.format('', '', '\033[1mEXEMPLO:\033[0m Brigestone', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    mar = raw_input('\x1b[s{0:2}MARCA > '.format(''))
    while not mar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MARCA OU a.'.format(''))
        time.sleep(1.5)
        inmarkquest()
    if mar == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        inmarksair()
    else:
        with codecs.open('data/temp/inmakchk.csv', 'w', 'utf_8') as fil:
            fil.write(str(mar))
        fil.close()
    inmakreadfil()


def inmakreadfil():
    with codecs.open('data/temp/inmakchk.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            inmakchk(vik)
    fil.close()


def inmakchk(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas WHERE Marca=?', (vik,))
    if not cur.fetchall():
        sys.stdout.write('\x1b[u\x1b[J{0:2}MARCA {1} '
                         'INEXISTENTE.'.format('', vik))
        time.sleep(1)
        sys.stdout.write('\x1b[1J\x1b[H')
        sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
        sys.stdout.write(
            '{0:2}||{1:2}\033[1m{2}\033[0m\033[1;92m{3:>15}\033[0m{4:5}'
            '||\n'.format('', '', 'ESCREVA O MODELO NOVO PARA A '
                                  'MARCA', vik, ''))
        sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                         '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
        sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
        mod = raw_input('\x1b[s{0:2}MODELO > '.format(''))
        while not mod:
            sys.stderr.write(
                '\x1b[u\x1b[J{0:2}ESCREVA O MODELO OU a.'.format(''))
            time.sleep(1.5)
            inmakreadfil()
        if mod == 'a':
            con.close()
            sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
            time.sleep(1)
            inmarksair()
        else:
            con.close()
        inmakend(vik, mod)
    else:
        con.close()
    markendquest(vik)


def markendquest(vik):
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:5}\033[1m{2}\033[0m\033[1;92m{3:>15}\033[0m'
        '{4:3}\033[1mEXISTE COM OS MODELOS\033[0m'
        '{5:4}||\n'.format('', '', 'A MARCA ', vik, '', ''))
    sys.stdout.write('{0:2}{1}\n\n'.format('', 60 * '='))
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT Modelo FROM marcas WHERE Marca=?', (vik,))
    last = cur.fetchall()
    hea = [i[0] for i in cur.description]
    mdx = hea[0]
    sys.stdout.write('{0:6} \033[1m{1}s\033[0m \n'.format('', mdx))
    sys.stdout.write('{0:6}{1}\n'.format('', 25 * '-'))
    for row in last:
        modx = row[0]
        sys.stdout.write('{0:6} {1} \n'.format('', modx))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}||{1:15}\033[1m{2}\033[0m{3:19}'
                     '||\n'.format('', '', 'ESCREVA O MODELO NOVO ', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:37}'
                     '||\n'.format('', '', 'PARA ANULAR -- a ', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    mod = raw_input('\x1b[s{0:2}MODELO > '.format(''))
    while not mod:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O MODELO OU a.'.format(''))
        time.sleep(1.5)
        inmakreadfil()
    if mod == 'a':
        con.close()
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        con.close()
        time.sleep(1)
        inmarksair()
    else:
        con.close()
    inmakend(vik, mod)


def inmakend(vik, mod):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas '
                'WHERE Marca=? AND Modelo=?', (vik, mod,))
    if not cur.fetchall():
        with con:
            cur.execute('INSERT INTO marcas '
                        'VALUES(NULL,?,?)', (vik, mod,))
        sys.stderr.write(
            '\x1b[u\x1b[J{0:2}ID {1} FOI IMPLATADO PARA A MARCA {2} '
            'COM O MODELO {3}.'.format('', cur.lastrowid, vik, mod))
        con.close()
        time.sleep(3)
        inmarksair()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}A MARCA {1} EXISTE COM O '
                     'MODELO {2}.'.format('', vik, mod))
    time.sleep(3)
    inmakreadfil()


def inmarksair():
    import data.menumodelo
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sys.stdout.write('{0:2}| ESCOLHA     INSERIR - i VOLTAR - v '
                     ' SAIR - s    |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA i, v ou s.'.format(''))
        time.sleep(1.5)
        inmarksair()
    if sair == 'i':
        sys.stderr.write('\x1b[u\x1b[J{0:2}INSERIR DE NOVA MARCA.'.format(''))
        time.sleep(1)
        inmark()
    elif sair == 'v':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU '
                         'ANTERIOR.'.format(''))
        time.sleep(1)
        data.menumodelo.modeauxmain()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA i, v ou s.'.format(''))
    time.sleep(1.5)
    inmarksair()


def inmarkmain():
    inmark()
    inmarkquest()
    inmakchk(vik=None)
    inmakreadfil()
    markendquest(vik=None)
    inmakend(vik=None, mod=None)
    inmarksair()


if __name__ == '__main__':
    inmarkmain()
