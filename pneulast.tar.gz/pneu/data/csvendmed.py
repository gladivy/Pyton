#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time
import webbrowser


def csvendmin():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{1:10}\033[1mEXPORTAR VENDA EM FORMATO '
                     'CSV\033[0m{2:13}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA A MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    ven = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not ven:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        csvendmin()
    if ven == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairvendmed()
    else:
        with codecs.open('data/temp/csvendmin.csv', 'w', 'utf_8') as fil:
            fil.write(str(ven))
        fil.close()
    csvendedfil()


def csvendedfil():
    with codecs.open('data/temp/csvendmin.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            csvendstart(vik)
    fil.close()


def csvendstart(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        csvendmin()
    else:
        con.close()
    csvvendmhead(vik)


def csvvendmhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM vendidos '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} \n'.format('', '', ide, med))
    sys.stdout.write('{0:2}{1}\n'.format('', 35 * '-'))
    con.close()
    csvendbody(vik)


def csvendbody(vik):
    with codecs.open('data/temp/csvendbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT ID, Medida FROM vendidos '
                               'WHERE Medida LIKE ? GROUP BY Medida '
                               'ORDER BY Medida', ('%' + vik + '%',)):
            ide, med = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} '
                             '\n'.format('', '', ide, med))
        con.close()
    fil.close()
    csvendquest()


def csvendquest():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ID DA MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    medid = raw_input('\x1b[s{0:2} ID > '.format(''))
    while not medid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1)
        csvendedfil()
    if medid == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairvendmed()
    else:
        csvendchek(medid)


def csvendchek(vik):
    with codecs.open('data/temp/csvendbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                csvchgidmed(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    csvendedfil()


def csvchgidmed(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Medida FROM vendidos WHERE ID=?', (vik,)):
        med = row[0]
        csvstartexp(med)
    con.close()


def csvstartexp(vik):
    with codecs.open('data/csv/vendas_medida.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Oldid, Data_Venda '
                    'FROM vendidos WHERE Medida=?', (vik,))
        fil.write(str('VENDAS POR MEDIDA'))
        fil.write(',')
        fil.write(str(vik))
        fil.write('\n')
        fil.write('')
        fil.write('\n')
        head = [i[0] for i in cur.description]
        olx, dta = head
        fil.write(str(olx))
        fil.write(',')
        fil.write(str(dta))
        fil.write(',')
        con.close()
    fil.close()
    csvendmedhead(vik)


def csvendmedhead(vik):
    with codecs.open('data/csv/vendas_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Marca, Modelo, Medida, Codigo,  DO, T, '
                    'Valor, Armazen FROM vendidos WHERE Medida=? ', (vik,))
        head = [i[0] for i in cur.description]
        mrx, mdx, mex, cdx, dox, ttx, prx, arx = head
        fil.write(str(mrx))
        fil.write(',')
        fil.write(str(mdx))
        fil.write(',')
        fil.write(str(mex))
        fil.write(',')
        fil.write(str(cdx))
        fil.write(',')
        fil.write(str('{0}{1}'.format(dox, ttx)))
        fil.write(',')
        fil.write(str(prx))
        fil.write(',')
        fil.write(str(arx))
        fil.write('\n')
        con.close()
    fil.close()
    bodycsvmedvend(vik)


def bodycsvmedvend(vik):
    with codecs.open('data/csv/vendas_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT Oldid, Data_Venda, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen '
                'FROM vendidos WHERE Medida=? '
                'ORDER BY Medida ASC', (vik,)):
            old, dta, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(old))
            fil.write(',')
            fil.write(str(dta))
            fil.write(',')
            fil.write(str(mar))
            fil.write(',')
            fil.write(str(mod))
            fil.write(',')
            fil.write(str(med))
            fil.write(',')
            fil.write(str(cod))
            fil.write(',')
            fil.write(str('{0}{1}'.format(dox, ttx)))
            fil.write(',')
            fil.write(str(pre))
            fil.write(',')
            fil.write(str(arm))
            fil.write('\n')
        con.close()
    fil.close()
    countcsvendmed(vik)


def countcsvendmed(vik):
    with codecs.open('data/csv/vendas_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM vendidos WHERE Medida=?', (vik,))
        fil.write('\n')
        fil.write(str('{0} VENDAS'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE VENDAS '
                     'EXPORTADA EM CSV.'.format(''))
    time.sleep(1.5)
    webbrowser.open('data/csv/vendas_medida.csv')
    sairvendmed()


def sairvendmed():
    import data.csvmedi
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.csvmedi.prmedida()


def csvendmedmain():
    csvendmin()
    csvendedfil()
    csvendstart(vik=None)
    csvvendmhead(vik=None)
    csvendbody(vik=None)
    csvendquest()
    csvendchek(vik=None)
    csvchgidmed(vik=None)
    csvstartexp(vik=None)
    csvendmedhead(vik=None)
    bodycsvmedvend(vik=None)
    countcsvendmed(vik=None)
    sairvendmed()


if __name__ == '__main__':
    csvendmedmain()
