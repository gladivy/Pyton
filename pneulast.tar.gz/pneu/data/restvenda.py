#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def resttbl():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos')
    ent = cur.fetchall()
    if not ent:
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        sairest()
    else:
        con.close()
    restvndst()


def restvndst():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCREVA A MEDIDA DO PNEU PARA '
                     'RESTAURAR{1:7}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:31}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        restvndst()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairest()
    else:
        with codecs.open('data/temp/restvndst.csv', 'w', 'utf_8') as fil:
            fil.write(str(esc))
        fil.close()
    restvendredfil()


def restvendredfil():
    with codecs.open('data/temp/restvndst.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            restvendpesq(vik)
    fil.close()


def restvendpesq(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA {1} '
                         'INEXISTENTE.'.format('', vik))
        con.close()
        time.sleep(1)
        restvndst()
    else:
        con.close()
    restvndhead(vik)


def restvndhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Oldid, Marca, Modelo, Medida, '
                'Codigo, DO, T, Armazen FROM vendidos '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, old, mar, mod, med, cod, dox, ttx, arm = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n\n'.format('', 'TABELA', ' ', 'VENDAS'))
    sys.stdout.write(
        '{0:2}| \033[92m{1:^5}\033[0m | {2:5} | {3:^15} | {4:^20} '
        '| {5:>7} | {6:6} | {7:2}{8:<2} | {9:^15} '
        '|\n'.format('', ide, old, mar, mod, med, cod, dox, ttx, arm))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 100 * '-'))
    con.close()
    resttbbody(vik)


def resttbbody(vik):
    with codecs.open('data/temp/resttbbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Oldid, Marca, Modelo, Medida, Codigo, DO, T, '
                'Armazen FROM vendidos WHERE Medida LIKE ? '
                'ORDER BY Oldid', ('%' + vik + '%',)):
            ide, old, mar, mod, med, cod, dox, ttx, arm = row
            sys.stdout.write(
                '{0:2}| \033[92m{1:5}\033[0m | {2:5} | {3:15} | {4:20} '
                '| {5:>7} | {6:6} | {7:2}{8:<2} '
                '| {9:>15} |\n'.format('', ide, old, mar, mod, med,
                                       cod, dox, ttx, arm))
            fil.write(str(ide))
            fil.write(',')
        con.close()
    fil.close()
    vendcoutn(vik)


def vendcoutn(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    sys.stdout.write(
        '\n{0:2}{1}{2:>6}\n\n'.format('', 'TOTAL', len(cur.fetchall())))
    con.close()
    revenqes()


def revenqes():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA O ID A \033[92mVERDE\033[0m'
                     ' DO PNEU PARA RESTAURAR{1:3}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:31}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        restvendredfil()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairest()
    else:
        with codecs.open('data/temp/resttbbody.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if esc in ide:
                    fil.close()
                    vendchkin(esc)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', esc))
        fil.close()
    time.sleep(1)
    restvendredfil()


def vendchkin(vik):
    con = sqlite3.connect('data/database/database.db')
    for ide in con.execute('SELECT ID, Oldid FROM vendidos '
                           'WHERE ID LIKE ?', (vik,)):
        ide, oldid = ide
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados '
                    'WHERE ID LIKE ?', (oldid,))
        if not cur.fetchall():
            con.close()
            restendvend(vik)
        else:
            sys.stderr.write(
                '\x1b[u{0:2}O \033[92mID {1}\033[0m EXISTE COM O ID {2} '
                'NA TABELA DE STOCK.'.format('', ide, oldid))
    con.close()
    time.sleep(1.5)
    restvendredfil()


def restendvend(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute(
            'INSERT INTO apagados SELECT NULL, Oldid, Data_Entrada, '
            'NULL, Marca, Modelo, Medida, Codigo, Do, T, Valor, Armazen '
            'FROM vendidos WHERE ID = ?', (vik,))
    tar = cur.lastrowid
    if not tar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A CRIAR O ID {1} NA '
                         'TABELA APAGADOS.'.format('', vik))
        con.close()
        time.sleep(3)
        sairest()
    else:
        with con:
            con.execute(
                'UPDATE apagados SET Dat_apagado = ? '
                'WHERE ID = ?', (time.strftime('%d/%m/%y-VENDA'), tar,))
    for row in con.execute('SELECT Dat_apagado FROM apagados '
                           'WHERE ID = ?', (tar,)):
        dat = row[0]
        if dat == (time.strftime('%d/%m/%y-VENDA')):
            sys.stderr.write(
                '\x1b[u\x1b[J{0:2}ID {1} RESTAURADO EM '
                '{2}'.format('', vik, (time.strftime('%d/%m/%y'))))
            con.close()
            time.sleep(2)
            restintovend(vik)
        else:
            sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO ALTERAR A DATA DO ID {1} '
                             'NA TABELA APAGADOS.'.format('', tar))
    con.close()
    time.sleep(3)
    sairest()


def restintovend(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute(
            'INSERT INTO pneusados SELECT Oldid, Data_Entrada, '
            'Marca, Modelo, Medida, Codigo, DO, T, Valor, Armazen '
            'FROM vendidos WHERE ID = ?', (vik,))
    if not cur.lastrowid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A RECUPERAR O ID {1} PARA '
                         'TABELA PNEUS.'.format('', vik))
        con.close()
        time.sleep(3)
        sairest()
    else:
        with con:
            con.execute('DELETE FROM vendidos WHERE ID = ?', (vik,))
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos WHERE ID = ?', (vik,))
    if not cur.fetchall():
        sys.stderr.write(' PARA TABELA PNEUS.')
        time.sleep(1.5)
        sys.stderr.write('\x1b[u\x1b[J{0:2}APAGADO DA TABELA '
                         'VENDAS.'.format(''))
        con.close()
        time.sleep(1.5)
        revensair()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A APAGAR O ID {1} DA '
                         'TABELA VENDAS.'.format('', vik))
    con.close()
    time.sleep(3)
    sairest()


def revensair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 55 * '='))
    sys.stdout.write('{0:2}| ESCOLHA    RESTAURAR - r   VOLTAR - v '
                     '  SAIR - s{1:4}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 55 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, v OU s.'.format(''))
        time.sleep(1.5)
        revensair()
    if sai == 'r':
        sys.stderr.write('\x1b[u\x1b[J{0:2}RESTAURAR OUTRA VENDA.'.format(''))
        time.sleep(1)
        revenmain()
    elif sai == 'v':
        sairest()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, v OU s.'.format(''))
    time.sleep(1.5)
    revensair()


def sairest():
    import data.restaurar
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.restaurar.restmain()


def revenmain():
    resttbl()
    restvndst()
    restvendredfil()
    restvendpesq(vik=None)
    restvndhead(vik=None)
    resttbbody(vik=None)
    vendcoutn(vik=None)
    revenqes()
    vendchkin(vik=None)
    restendvend(vik=None)
    restintovend(vik=None)
    revensair()
    sairest()


if __name__ == '__main__':
    revenmain()
