#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def modarmstr():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}| PARA MODIFICAR PNEU DE ARMAZEN '
                     'ESCREVA A MEDIDA{1:4}|\n'.format('', ''))
    sys.stdout.write('{0:2}| EXEMPLO: 2055516 OU 205  '
                     '{1:26}|\n'.format('', ''))
    sys.stdout.write('{0:2}| PARA ANULAR - a{1:36}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        modarmstr()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairmodarma()
    else:
        with codecs.open('data/temp/modarmstr.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    readmodarmstr()


def readmodarmstr():
    with codecs.open('data/temp/modarmstr.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            modarquest(vik)
    fil.close()


def modarquest(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        modarmstr()
    else:
        con.close()
    modararmhead(vik)


def modararmhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca, Modelo, Medida, '
                'Codigo, DO, T, Armazen '
                'FROM pneusados '
                'WHERE Medida LIKE ? '
                'ORDER BY Modelo, ID ASC', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, mar, mod, med, cod, dox, ttx, arm = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'STOCK'))
    sys.stdout.write(
        '\n{0:2}| {1:5} | {2:15} | {3:20} | {4:7} | {5:6} | {6:2}{7:<2} '
        '| {8:^15} |\n'.format('', ide, mar, mod, med, cod, dox, ttx, arm))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 92 * '-'))
    con.close()
    modarbody(vik)


def modarbody(vik):
    with codecs.open('data/temp/modarbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Marca, Modelo, Medida, '
                'Codigo, DO, T, Armazen  '
                'FROM pneusados '
                'WHERE Medida LIKE ? '
                'ORDER BY Modelo, ID ASC', ('%' + vik + '%',)):
            ide, mar, mod, med, cod, dox, ttx, arm = row
            sys.stdout.write(
                '{0:2}| {1:5} | {2:15} | {3:20} | {4:7} | {5:>6} | {6:2}'
                '{7:<2} | {8:>15} |\n'.format('', ide, mar, mod, med, cod,
                                              dox, ttx, arm))
            fil.write(str(ide))
            fil.write(',')
        con.close()
    fil.close()
    modarcount(vik)


def modarcount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}| FORAM ENCONTRADOS {1:5} RESULTADOS'
                     '.{2:16}|\n'.format('', len(cur.fetchall()), ''))
    con.close()
    modar()


def modar():
    sys.stdout.write('{0:2}| PARA MODIFICAR PNEU DE ARMAZEN ESCREVA '
                     'O ID{1:8}|\n'.format('', ''))
    sys.stdout.write('{0:2}| PARA ANULAR - a{1:36}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    mod = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not mod:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        readmodarmstr()
    if mod == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairmodarma()
    else:
        with codecs.open('data/temp/modarbody.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if mod in ide:
                    fil.close()
                    movetocharm(mod)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', mod))
        fil.close()
    time.sleep(1)
    readmodarmstr()


def movetocharm(mod):
    import data.chanarm
    with codecs.open('data/temp/modar.csv', 'w', 'utf_8') as fil:
        fil.write(str(mod))
    fil.close()
    data.chanarm.chanmain()


def sairmodarma():
    import data.modificar
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.modificar.modficarmain()


def armmain():
    modarmstr()
    readmodarmstr()
    modarquest(vik=None)
    modararmhead(vik=None)
    modarbody(vik=None)
    modarcount(vik=None)
    modar()
    movetocharm(mod=None)
    sairmodarma()


if __name__ == '__main__':
    armmain()
