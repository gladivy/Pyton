#!/usr/bin/python
# coding: utf-8
import sys
import time


def export():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write(
        '{0:2}|{1:6}{2}{3:6}'
        '|\n'.format('', '', '\033[1mESCOLHA PARA EXPORTAR AS '
                             'TABELAS.\033[0m   (FORMATOS: CVS E HTML)', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:31}'
                     '|\n'.format('', '', '1 - TABELA PARA CVS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:30}'
                     '|\n'.format('', '', '2 - TABELA PARA HTML', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:48}'
                     '|\n'.format('', '', 'TABELAS - t SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU t, s.'.format(''))
        time.sleep(1.5)
        exportmain()
    if esc == '1':
        tbltocsv()
    elif esc == '2':
        tbltohtml()
    elif esc == 's':
        menexpsair()
    elif esc == 't':
        voltblmenu()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU t, s.'.format(''))
    time.sleep(1.5)
    exportmain()


def tbltocsv():
    import data.menuexpcsv
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU CSV.'.format(''))
    time.sleep(1)
    data.menuexpcsv.csvmain()


def tbltohtml():
    import data.menuexphtml
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU HTML.'.format(''))
    time.sleep(1)
    data.menuexphtml.htmlmain()


def menexpsair():
    sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
    time.sleep(1)
    sys.stderr.write('\x1b[2J\x1b[H')
    sys.exit(10)


def voltblmenu():
    import data.tabelas
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU TABELAS.'.format(''))
    time.sleep(1)
    data.tabelas.tabmenumain()


def exportmain():
    export()
    tbltocsv()
    tbltohtml()
    menexpsair()
    voltblmenu()


if __name__ == '__main__':
    exportmain()
