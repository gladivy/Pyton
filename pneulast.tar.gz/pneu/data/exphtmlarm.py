#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time
import webbrowser


def htmlax():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 55 * '='))
    sys.stdout.write('{0:2}|{1:1}\033[1mEXPORTAR STOCK POR ORDEM DE ARMAZEN '
                     'EM FORMATO HTML\033[0m{2:1}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 55 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ARMAZEN QUE PRETENDE '
                     'EXPORTAR\033[0m{1:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:36}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 55 * '='))
    arm = raw_input('\x1b[s{0:2}ARMAZEN > '.format(''))
    while not arm:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A '
                         'ARMAZEN OU a.'.format(''))
        time.sleep(1.5)
        htmlax()
    if arm == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        htmlarmsair()
    else:
        with codecs.open('data/temp/htmlarm.csv', 'w', 'utf_8') as fil:
            fil.write(str(arm))
        fil.close()
    armreadfil()


def armreadfil():
    with codecs.open('data/temp/htmlarm.csv', 'r', 'utf_8') as fil:
        for line in csv.reader(fil):
            arm = line[0]
            armlook(arm)
    fil.close()


def armlook(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Armazen LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}ARMAZEN INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        htmlax()
    else:
        con.close()
    armtbllok(vik)


def armtbllok(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Armazen FROM pneusados '
                'WHERE Armazen LIKE ?', ('%' + vik + '%',))
    sys.stdout.write('\x1b[1J\x1b[H')
    head = [i[0] for i in cur.description]
    ide, arm = head
    sys.stdout.write('{0:2}{1:6}{2:5} | {3:15}\n'.format('', '', ide, arm))
    sys.stdout.write('{0:2}{1:6}{2}\n'.format('', '', 35 * '-'))
    con.close()
    armtblbody(vik)


def armtblbody(vik):
    with codecs.open('data/temp/armtblbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Armazen FROM pneusados '
                'WHERE Armazen LIKE ? GROUP BY Armazen', ('%' + vik + '%',)):
            ide, arm = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:2}{1:6}{2:^5} '
                             '| {3:>15}\n'.format('', '', ide, arm))
        con.close()
    fil.close()
    armidchoi()


def armidchoi():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 55 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ID DO ARMAZEN QUE PRETENDE '
                     'EXPORTAR\033[0m{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:36}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 55 * '='))
    ide = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        armreadfil()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        htmlarmsair()
    else:
        armidfilcheck(ide)


def armidfilcheck(vik):
    with codecs.open('data/temp/armtblbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            idel = lin
            if vik in idel:
                fil.close()
                armname(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO'.format('', vik))
    fil.close()
    time.sleep(1)
    armreadfil()


def armname(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Armazen FROM pneusados '
                           'WHERE ID=? ', (vik,)):
        arm = row[0]
        htmlarmhead(arm)
    con.close()


def htmlarmhead(vik):
    with codecs.open('data/html/stock_armazen.html', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID, Marca, Modelo, Medida, Codigo, '
                    'DO, T, Valor, Armazen FROM pneusados '
                    'WHERE Armazen=?', (vik,))
        head = [i[0] for i in cur.description]
        ide, mar, mod, med, cod, dox, ttx, pre, arm = head
        fil.write(str(
            '<!DOCTYPE html>\n'
            '<html lang="pt-PT">\n'
            '<head>\n'
            '  <link rel="stylesheet" '
            'type="text/css" '
            'href="tabela.CSS">\n'
            '  <meta charset="UTF-8">\n'
            '  <title> Tabela Stock</title>\n'
            '</head>\n'
            '<body>\n'
            '<h1>Tabela Stock por Armazen {0}</h1>\n'
            '<table style="width:90%">\n'
            '  <tr>\n'
            '    <th>{1}</th>\n'
            '    <th>{2}</th>\n'
            '    <th>{3}</th>\n'
            '    <th>{4}</th>\n'
            '    <th>{5}</th>\n'
            '    <th>{6}{7}</th>\n'
            '    <th>{8}</th>\n'
            '    <th>{9}</th>\n'
            '  </tr>\n'.format(vik, ide, mar, mod, med, cod,
                               dox, ttx, pre, arm)))
        con.close()
    fil.close()
    htmlarmbody(vik)


def htmlarmbody(vik):
    with codecs.open('data/html/stock_armazen.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen FROM pneusados '
                'WHERE Armazen=? ORDER BY Armazen', (vik,)):
            ide, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(
                '  <tr>\n'
                '    <td>{0}</td>\n'
                '    <td>{1}</td>\n'
                '    <td>{2}</td>\n'
                '    <td>{3}</td>\n'
                '    <td>{4}</td>\n'
                '    <td>{5}{6}</td>\n'
                '    <td>{7}</td>\n'
                '    <td>{8}</td>\n'
                '  </tr>\n'.format(ide, mar, mod, med, cod, dox,
                                   ttx, pre, arm)))
        con.close()
    fil.close()
    htmlarmcount(vik)


def htmlarmcount(vik):
    with codecs.open('data/html/stock_armazen.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados WHERE Armazen=?', (vik,))
        fil.write(str(
            '</table>\n'
            '  <p>NOTA:</p>\n'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
            '{0} - Entradas\n'
            '  <p></p>\n'
            '</body>\n'
            '</html>\n'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sys.stderr.write('\x1b[u{0:2}TABELA DE PESQUIZA EXPORTADA '
                     'EM HTML.'.format(''))
    time.sleep(1)
    webbrowser.open('data/html/stock_armazen.html')
    htmlarmsair()


def htmlarmsair():
    import data.htmlmedi
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.htmlmedi.htmlmedmain()


def htmlarmmain():
    htmlax()
    armreadfil()
    armlook(vik=None)
    armtbllok(vik=None)
    armtblbody(vik=None)
    armidchoi()
    armidfilcheck(vik=None)
    armname(vik=None)
    htmlarmhead(vik=None)
    htmlarmbody(vik=None)
    htmlarmcount(vik=None)
    htmlarmsair()


if __name__ == '__main__':
    htmlarmmain()
