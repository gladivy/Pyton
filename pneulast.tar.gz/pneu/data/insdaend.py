#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def dotmes():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:6}'
        '||\n'.format('', '', 'ESCREVA OS PRIMEIROS DOIS NUMEROS DA '
                              'DATA DO DOT', ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:15}'
        '||\n'.format('', '', '\033[1mEXEMPLO:\033[0m  11 (semana do '
                              'ano de fabrico)', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    dot = raw_input('\x1b[s{0:2}SEMANA DO DOT > '.format(''))
    while not dot:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA OS PRIMEIROS DOIS '
                         'NUMEROS DO DOT OU a.'.format(''))
        time.sleep(2)
        dotmes()
    if dot == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        arminsair()
    else:
        with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
            fil.write(str(dot))
            fil.write(',')
        fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
    time.sleep(1)
    dotano()


def dotano():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:8}'
        '||\n'.format('', '', 'ESCREVA OS DOIS ULTIMOS NUMEROS DA '
                              'DATA DO DOT', ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:25}'
        '||\n'.format('', '', '\033[1mEXEMPLO:\033[0m  16 '
                              '(ano de fabrico)', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    dot = raw_input('\x1b[s{0:2}ANO DO DOT > '.format(''))
    while not dot:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA OS DOIS ULTIMOS '
                         'NUMEROS DO DOT OU a.'.format(''))
        time.sleep(2)
        dotano()
    if dot == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        arminsair()
    else:
        with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
            fil.write(str(dot))
            fil.write(',')
        fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
    time.sleep(1)
    valor()


def valor():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:8}'
        '||\n'.format('', '', 'ESCREVA O VALOR DO PNEU SEM VIRGULAS '
                              'NEM EUROS', ''))
    sys.stdout.write('{0:2}||{1:2}{2}{3:42}'
                     '||\n'.format('', '', '\033[1mEXEMPLO:\033[0m  25', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    val = raw_input('\x1b[s{0:2}VALOR > '.format(''))
    while not val:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O VALOR OU a.'.format(''))
        time.sleep(1.5)
        valor()
    if val == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        arminsair()
    else:
        with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
            fil.write(str(val))
            fil.write(',')
        fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
    time.sleep(1)
    armazenin()


def armazenin():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM armazens')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE ARMAZENS '
                         'VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        inarmnovo()
    else:
        con.close()
    inarmtbl()


def inarmtbl():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM armazens')
    head = [i[0] for i in cur.description]
    idx, armx, descx = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:6} \033[1m{1:^4}\033[0m '
                     '| \033[1m{2:^15}\033[0m '
                     '| \033[1m{3:30}\033[0m\n'.format('', idx, armx, descx))
    sys.stdout.write('{0:6} {1}\n'.format('', 35 * '-'))
    with codecs.open('data/temp/inarmtbl.csv', 'w', 'utf_8') as fil:
        for row in cur.fetchall():
            ide, arm, desc = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:6} {1:^4} | {2:^15} '
                             '| {3:30}\n'.format('', ide, arm, desc))
    fil.close()
    con.close()
    inarmquest()


def inarmquest():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:3}\033[1m{2}\033[0m{3:21}'
        '||\n'.format('', '', 'ESCREVA O ID RELATIVO AO ARMAZEN', ''))
    sys.stdout.write(
        '{0:2}||{1:3}{2}{3:18}'
        '||\n'.format('', '', '"\033[1;92mnovo\033[0m" \033[1mPARA '
                              'INSERIR UM NOVO ARMAZEN\033[0m', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID, '
                         'novo OU a.'.format(''))
        time.sleep(2)
        inarmtbl()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO'.format(''))
        time.sleep(1)
        arminsair()
    elif esc == 'novo':
        inarmnovo()
    else:
        with codecs.open('data/temp/inarmtbl.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if esc in ide:
                    fil.close()
                    armslekt(esc)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INEXISTENTE.'.format('', esc))
        fil.close()
    time.sleep(1)
    inarmtbl()


def inarmnovo():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:19}'
        '||\n'.format('', '', 'ESCREVA O NOME PARA UM NOVO ARMAZEN', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    arm = raw_input('\x1b[s{0:2}ARMAZEN > '.format(''))
    while not arm:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA UM NOVO '
                         'NOME OU a.'.format(''))
        time.sleep(1.5)
        inarmnovo()
    if arm == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        arminsair()
    else:
        with codecs.open('data/temp/inarmnovo.csv', 'w', 'utf_8') as fil:
            fil.write(str(arm))
        fil.close()
    inarmnovred()


def inarmnovred():
    with codecs.open('data/temp/inarmnovo.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            arm = lin[0]
            armintbl(arm)
    fil.close()


def armintbl(arm):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazens WHERE Armazen = ?', (arm,))
    if not cur.fetchall():
        sys.stdout.write('\x1b[1J\x1b[H')
        sys.stdout.write('{0:2}{1}\n'.format('', 62 * '='))
        sys.stdout.write(
            '{0:2}||{1:2}{2}\033[1;92m{3:^15}\033[0m{4}'
            '||\n'.format('', '', 'DISCRIMINE O '
                                  'ARMAZEN ', arm, 'EM CURTAS PALAVRAS  '))
        sys.stdout.write('{0:2}||{1:2}{2}{3:41}'
                         '||\n'.format('', '', 'PARA ANULAR - a', ''))
        sys.stdout.write('{0:2}{1}\n'.format('', 62 * '='))
        det = raw_input('\x1b[s{0:2}DETALHES > '.format(''))
        while not det:
            sys.stderr.write('\x1b[u\x1b[J{0:2}DISCRIMINE O '
                             'ARMAZEN OU a.'.format(''))
            time.sleep(1.5)
            inarmnovred()
        if det == 'a':
            sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
            time.sleep(1)
            arminsair()
        else:
            with con:
                cur.execute('INSERT INTO armazens '
                            'VALUES(NULL,?,?)', (arm, det,))
        sys.stderr.write('\x1b[u\x1b[J{0:2}NOVO ID {1} IMPLATADO PARA '
                         'ARMAZEN {2}.'.format('', cur.lastrowid, arm))
        time.sleep(1.5)
        con.close()
        writarm(arm)
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}O ARMAZEN {1} EXISTE.'.format('', arm))
    time.sleep(1)
    inarmnovo()


def armslekt(arm):
    con = sqlite3.connect('data/database/database.db')
    for line in con.execute('SELECT Armazen FROM armazens '
                            'WHERE ID=?', (arm,)):
        arms = line[0]
        writarm(arms)
    con.close()


def writarm(arm):
    import data.popdata
    with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
        fil.write(str(arm))
    fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
    time.sleep(1)
    data.popdata.incsvmain()


def arminsair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| ESCOLHA  NOVO REGISTO - r  MENU - m '
                     ' SAIR - s  |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, m ou s.'.format(''))
        time.sleep(1.5)
        arminsair()
    if sai == 'r':
        regret()
    if sai == 'm':
        vltmenu()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        arminsair()


def regret():
    import data.insdata
    sys.stderr.write('\x1b[u\x1b[J{0:2}A REINICIAR REGISTO.'.format(''))
    time.sleep(1)
    data.insdata.maininser()


def vltmenu():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU.'.format(''))
    time.sleep(1)
    data.menu.mainmenu()


def inendmain():
    dotmes()
    dotano()
    valor()
    armazenin()
    inarmtbl()
    inarmquest()
    inarmnovo()
    inarmnovred()
    armintbl(arm=None)
    armslekt(arm=None)
    writarm(arm=None)
    arminsair()
    regret()
    vltmenu()


if __name__ == '__main__':
    inendmain()
