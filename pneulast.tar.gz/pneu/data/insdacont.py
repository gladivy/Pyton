#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def medidain():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE MEDIDAS '
                         'VAZIA.'.format(''))
        time.sleep(1)
        medinovo()
    else:
        con.close()
    medchoice()


def medchoice():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}||{1:2}\033[1m{2}\033[0m{3:32}'
                     '||\n'.format('', '', 'ESCREVA MEDIDA DO PNEU', ''))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:6}'
        '||\n'.format('', '', 'PARA PESQUIZAR PODE USAR UM DECREMENTO '
                              'DA MEDIDA', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA MEDIDA OU O SEU '
                         'DECREMENTO PARA PESQUISAR.'.format(''))
        time.sleep(2)
        medchoice()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        medinsair()
    else:
        with codecs.open('data/temp/medchoice.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    medcker(med)


def medcker(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        medinovo()
    else:
        con.close()
    medchoicred()


def medchoicred():
    with codecs.open('data/temp/medchoice.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            medintbl(vik)
    fil.close()


def medintbl(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM medidas '
                'WHERE Medida LIKE ? GROUP BY Medida '
                'ORDER BY Medida ASC', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:6} \033[1m{1:^4}\033[0m '
                     '| \033[1m{2:^15}\033[0m \n'.format('', ide, med))
    sys.stdout.write('{0:6} {1}\n'.format('', 20 * '-'))
    with codecs.open('data/temp/medintbl.csv', 'w', 'utf_8') as fil:
        for row in cur.fetchall():
            idx, mex = row
            fil.write(str(idx))
            fil.write(',')
            sys.stdout.write('{0:6} {1:^4} | {2:<15} \n'.format('', idx, mex))
    fil.close()
    con.close()
    medidchoi()


def medidchoi():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:15}'
        '||\n'.format('', '', 'ESCREVA O ID RELATIVO A MEDIDA DO PNEU ', ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:19}'
        '||\n'.format('', '', '"\033[1;92mnovo\033[0m" \033[1mPARA '
                              'INSERIR UMA NOVA MEDIDA\033[0m', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID, novo '
                         'OU a.'.format(''))
        time.sleep(1.5)
        medchoicred()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        medinsair()
    elif esc == 'novo':
        medinovo()
    else:
        with codecs.open('data/temp/medintbl.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if esc in ide:
                    fil.close()
                    writmedchoi(esc)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', esc))
        fil.close()
    time.sleep(1)
    medchoicred()


def writmedchoi(esc):
    with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for line in con.execute('SELECT Medida FROM medidas '
                                'WHERE ID=?', (esc,)):
            med = line[0]
            fil.write(str(med))
            fil.write(',')
        con.close()
    fil.close()
    readforcode()


def medinovo():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:8}'
        '||\n'.format('', '', '\033[1mESCREVA O MEDIDA DO PNEU COMO '
                              'EXEMPLO:\033[0m 2055516', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        medinovo()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        medinsair()
    else:
        with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
            fil.write(str(med))
            fil.write(',')
        fil.close()
    readforcode()


def readforcode():
    with codecs.open('data/temp/insertemp.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            med = lin[3]
            codigoin(med)
    fil.close()


def codigoin(med):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM medidas WHERE Medida=?', (med,))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}CODIGO INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        readnovocod()
    else:
        con.close()
    codtbl(med)


def codtbl(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Codigo FROM medidas '
                'WHERE Medida=?', (vik,))
    head = [i[0] for i in cur.description]
    ide, cod = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:6} \033[1m{1:^4}\033[0m '
                     '| \033[1m{2:^15}\033[0m \n'.format('', ide, cod))
    sys.stdout.write('{0:6} {1}\n'.format('', 20 * '-'))
    with codecs.open('data/temp/codtbl.csv', 'w', 'utf_8') as fil:
        for row in cur.fetchall():
            idx, cox = row
            fil.write(str(idx))
            fil.write(',')
            sys.stdout.write('{0:6} {1:^4} | {2:<15} \n'.format('', idx, cox))
    fil.close()
    con.close()
    codidchoice()


def codidchoice():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:14}'
        '||\n'.format('', '', 'ESCREVA O ID RELATIVO AO CODIGO DO PNEU ', ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:20}'
        '||\n'.format('', '', '"\033[1;92mnovo\033[0m" \033[1mPARA '
                              'INSERIR UM NOVO CODIGO\033[0m', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    ide = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID, '
                         'novo OU a.'.format(''))
        time.sleep(1.5)
        readforcode()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        medinsair()
    elif ide == 'novo':
        readnovocod()
    else:
        with codecs.open('data/temp/codtbl.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                idx = lin
                if ide in idx:
                    fil.close()
                    writcodfid(ide)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', ide))
        fil.close()
    time.sleep(1)
    readforcode()


def writcodfid(ide):
    with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for line in con.execute('SELECT Codigo FROM medidas '
                                'WHERE ID=?', (ide,)):
            cod = line[0]
            fil.write(str(cod))
            fil.write(',')
        con.close()
    fil.close()
    medindatred()


def readnovocod():
    with codecs.open('data/temp/insertemp.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            med = lin[3]
            novocod(med)
    fil.close()


def novocod(med):
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m\033[1;92m'
        '{3:>8}\033[0m{4:15}||\n'.format('', '', 'ESCREVA O CODIGO PARA '
                                                 'A MEDIDA ', med, ''))
    sys.stdout.write(
        '{0:2}||{1:2}{2}{3:36}'
        '||\n'.format('', '', '\033[1mCOMO EXEMPLO:\033[0m 91v ', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    cod = raw_input('\x1b[s{0:2}CODIGO > '.format(''))
    while not cod:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O CODIGO OU a.'.format(''))
        time.sleep(1.5)
        readnovocod()
    if cod == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        medinsair()
    else:
        with codecs.open('data/temp/insertemp.csv', 'a', 'utf_8') as fil:
            fil.write(str(cod))
            fil.write(',')
        fil.close()
    medindatred()


def medindatred():
    with codecs.open('data/temp/insertemp.csv', 'r', 'utf_8') as fil:
        for line in csv.reader(fil, delimiter=','):
            med = line[3]
            cod = line[4]
            insmedcod(med, cod)
    fil.close()


def insmedcod(med, cod):
    import data.insdaend
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT Medida, Codigo FROM medidas '
                'WHERE Medida=? AND Codigo=? ', (med, cod,))
    if not cur.fetchall():
        with con:
            cur.execute('INSERT INTO medidas '
                        'VALUES(NULL,?,?)', (med, cod,))
        sys.stderr.write('\x1b[u\x1b[J{0:2}NOVO ID {1} IMPLATADO PARA A '
                         'MEDIDA {2}.'.format('', cur.lastrowid, med))
        con.close()
        time.sleep(1)
        sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
        time.sleep(1)
        data.insdaend.inendmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}OBRIGADO.'.format(''))
    time.sleep(1)
    data.insdaend.inendmain()


def medinsair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| ESCOLHA  NOVO REGISTO - r  MENU - m '
                     ' SAIR - s  |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, m ou s.'.format(''))
        time.sleep(1.5)
        medinsair()
    if sai == 'r':
        retreg()
    elif sai == 'm':
        volmenu()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, m ou s.'.format(''))
    time.sleep(1.5)
    medinsair()


def retreg():
    import data.insdata
    sys.stderr.write('\x1b[u\x1b[J{0:2}A REINICIAR REGISTO.'.format(''))
    time.sleep(1)
    data.insdata.maininser()


def volmenu():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU.'.format(''))
    time.sleep(1)
    data.menu.mainmenu()


def mainincont():
    medidain()
    medchoice()
    medcker(vik=None)
    medchoicred()
    medintbl(vik=None)
    medidchoi()
    readforcode()
    codigoin(med=None)
    codtbl(vik=None)
    codidchoice()
    writcodfid(ide=None)
    novocod(med=None)
    medindatred()
    insmedcod(med=None, cod=None)
    medinsair()
    retreg()
    volmenu()


if __name__ == '__main__':
    mainincont()
