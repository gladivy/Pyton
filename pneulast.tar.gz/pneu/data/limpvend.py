#!/usr/bin/python
# coding: utf-8
import sys
# import sqlite3
import time


def terlimp():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}VAI APAGAR A TODOS OS VALORES APAGADOS DAS VENDAS '
                     '\033[1mANULAR - a  SIM - s\033[0m\n'.format(''))
    esq = raw_input('\x1b[s{0:2}> '.format(''))
    while not esq:
        sys.stderr.write('\x1b[u{0:2}ESCREVA s ou a'.format(''))
        time.sleep(1)
        lipvendmain()
    if esq == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        limvendsair()
    elif esq == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}Apagado.'.format(''))
        time.sleep(1)
        limvendsair()
    else:
        sys.stderr.write('\x1b[u{0:2}ESCREVA s ou a'.format(''))
    time.sleep(1)
    lipvendmain()


def limvendsair():
    import data.apgrtblapg
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.apgrtblapg.apartblamain()


def lipvendmain():
    terlimp()
    limvendsair()


if __name__ == '__main__':
    lipvendmain()
