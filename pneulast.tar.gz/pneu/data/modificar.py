#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def mod():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:23}\033[1m{2}\033[0m{3:25}'
                     '|\n'.format('', '', 'PARA MODIFICAR ESCOLHA', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:39}'
                     '|\n'.format('', '', '1 - ARMAZEN', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '2 - VALOR', ''))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write(
        '{0:2}|{1:2}{2}{3:2}{4}{5:48}'
        '|\n'.format('', '', 'VOLTAR - v', '', 'SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU u, s.'.format(''))
        time.sleep(1.5)
        modficarmain()
    if esc == '1':
        modarmazen()
    elif esc == '2':
        modvalor()
    elif esc == 'v':
        modvoltar()
    elif esc == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU u, s.'.format(''))
    time.sleep(1.5)
    modficarmain()


def modarmazen():
    import data.modarma
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        modficarmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}MODIFICAR ARMAZEN.'.format(''))
    time.sleep(1)
    data.modarma.armmain()


def modvalor():
    import data.modpreco
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        modficarmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}MODIFICAR VALOR.'.format(''))
    time.sleep(1)
    data.modpreco.precmain()


def modvoltar():
    import data.limparesto
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.limparesto.limrestmain()


def modficarmain():
    mod()
    modarmazen()
    modvalor()
    modvoltar()


if __name__ == '__main__':
    modficarmain()
