#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import os
import sys
import sqlite3
import time


def bakin():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    sys.stdout.write('{0:2}|{2:6}     \033[1;91mCUIDADO VAI FAZER UM '
                     'BACKUP\033[0m {1:13}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}| \033[1mAO FAZER O BACKUP ESCREVA UM NOME '
                     '\033[0m{1:17}|\n'.format('', ''))
    sys.stdout.write('{0:2}| \033[1mCOM 3 LETRAS E O PRESENTE ANO, EXEMPLO:'
                     '\033[0m foo16{1:6}|\n'.format('', ''))
    sys.stdout.write('{0:2}|{2} PARA ANULAR - a{1:36}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    nom = raw_input('\x1b[s{0:2}NOME > '.format(''))
    while not nom:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA UM NOME PARA O '
                         'BACKUP OU a.'.format(''))
        time.sleep(1.5)
        bakin()
    if nom == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairfbak()
    else:
        with codecs.open('data/temp/bakin.csv', 'w', 'utf_8') as fil:
            fil.write(str(nom))
        fil.close()
    readbakin()


def readbakin():
    with codecs.open('data/temp/bakin.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            nom = lin[0]
            bakfile(nom)
    fil.close()


def bakfile(nom):
    dax = time.strftime('%m%d')
    if os.path.exists('data/backup/{0}{1}.sql'.format(nom, dax)):
        sys.stderr.write('\x1b[u{0:2}{1}{2}.sql EXISTE'.format('', nom, dax))
        time.sleep(1.5)
        sys.stderr.write(' :ESCREVA OUTRO NOME PARA O BACKUP.')
        time.sleep(2)
        bakin()
    else:
        sys.stdout.write('\x1b[1J\x1b[H')
        sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
        sys.stdout.write(
            '{0:2}|{1:2}{2}{3:^16}{4}'
            '|\n'.format('', '', 'DECRIMINE O BACKUP', nom, ' COM CURTAS '
                                                            'PALAVRAS  '))
        sys.stdout.write('{0:2}|{1:2}{2}'
                         '{3:41}|\n'.format('', '', 'PARA ANULAR - a', ''))
        sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
        det = raw_input('\x1b[s{0:2} > '.format(''))
        while not det:
            sys.stderr.write('\x1b[u\x1b[J{0:2}DETALHE ou a.'.format(''))
            time.sleep(1.5)
            readbakin()
        if det == 'a':
            sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
            time.sleep(1)
            sairfbak()
        else:
            backindb(dax, nom, det)


def backindb(dax, nom, det):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute(
            'INSERT INTO dados '
            'VALUES(NULL,?,?,?)', (dax, nom, det))
    one = cur.lastrowid
    if not one:
        sys.stderr.write('\x1b[u{0:2}OCORREU UM ERRO, OS DADOS NÃO '
                         'FORAM GRAVADOS.'.format(''))
        con.close()
        time.sleep(3)
        sairfbak()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}BACKUP {1} GUARDADO COM '
                         'ID {2}.'.format('', nom, one))
    con.close()
    time.sleep(1.5)
    filebackup(nom, dax)


def filebackup(nom, dax):
    with codecs.open(
            'data/backup/{0}{1}.sql'.format(nom, dax), 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for lin in con.iterdump():
            fil.write('{0}\n'.format(lin))
        con.close()
    fil.close()
    if not os.path.exists('data/backup/{0}{1}.sql'.format(nom, dax)):
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO AO GUARDAR O '
                         'FICHEIRO {1}{2}.sql'.format('', nom, dax))
        time.sleep(3)
        sairfbak()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}FICHEIRO DE BACKUP '
                         '{1}{2}.sql GUARDADO.'.format('', nom, dax))
    time.sleep(1.5)
    sairfbak()


def sairfbak():
    import data.backup
    sys.stderr.write('\x1b[u\x1b[J{0:2}TERMINADO.'.format(''))
    time.sleep(1)
    data.backup.bacupmain()


def backupmain():
    bakin()
    readbakin()
    bakfile(nom=None)
    backindb(dax=None, nom=None, det=None)
    filebackup(nom=None, dax=None)
    sairfbak()


if __name__ == '__main__':
    backupmain()
