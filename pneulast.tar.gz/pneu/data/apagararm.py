#!/usr/bin/python
# coding: utf-8
import collections
import sys
import sqlite3
import time


def aparmchk():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazens')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        aparmtomenu()
    else:
        con.close()
    aparmtblhead()


def aparmtblhead():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Armazen, Detalhes FROM armazens')
    head = [i[0] for i in cur.description]
    idx, arm, det = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'ARMAZENS'))
    sys.stdout.write('\n{0:4} \033[1m{1:^5}\033[0m | \033[1m{2:^15}\033[0m | '
                     '\033[1m{3:^20}\033[0m \n'.format('', idx, arm, det))
    sys.stdout.write('{0:2}{1}\n'.format('', 43 * '-'))
    con.close()
    aparmtblbody()


def aparmtblbody():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    lom = []
    cur.execute('SELECT ID, Armazen, Detalhes FROM armazens '
                'ORDER BY Armazen ASC')
    qua = cur.fetchall()
    for row in qua:
        idx, arm, det = row
        lom.append(arm)
        sys.stdout.write('{0:4} {1:5} | {2:15} '
                         '| {3:20} \n'.format('', idx, arm, det))
    sys.stdout.write('\n\n{0:2} \033[1m{1:10}   '
                     '{2:20}\033[0m\n'.format('', 'QUANTIDADE', 'ARMAZEN'))
    for ink, kit in collections.Counter(lom).most_common():
        sys.stdout.write('{0:2} {1:>10}   {2:<20}\n'.format('', kit, ink))
    sys.stdout.write('\n{0:2}\033[1m{1:5}\033[0m'
                     '{2:>5}\n'.format('', ' TOTAL', len(qua)))
    con.close()
    armapachk()


def armapachk():
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sys.stdout.write(
        '{0:2}|{1:2}{2}{3:12}'
        '|\n'.format('', '', 'ESCOLHA O ID DO ARMAZEN PARA APAGAR', ''))
    sys.stdout.write('{0:2}|{1:2}{2}'
                     '{3:32}|\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    apg = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not apg:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID ou a.'.format(''))
        time.sleep(1.5)
        aparmtblhead()
    if apg == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        aparmtomenu()
    else:
        armidchk(apg)


def armidchk(apg):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazens '
                'WHERE ID = ?', (apg,))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u{0:2}ID INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        aparmtblhead()
    else:
        con.close()
    apagfinal(apg)


def apagfinal(apg):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('DELETE FROM armazens WHERE ID = ?', (apg,))
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazens WHERE ID = ?', (apg,))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} APAGADO.'.format('', apg))
        con.close()
        time.sleep(1)
        sairaparm()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO APAGAR O ID {1}.'.format('', apg))
    time.sleep(3)
    sairaparm()


def sairaparm():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sys.stdout.write('{0:2}| ESCOLHA      APAGAR - a  VOLTAR - v '
                     ' SAIR - s   |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
        time.sleep(1.5)
        sairaparm()
    if sai == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR APAGAR OUTRO '
                         'ARMAZEN.'.format(''))
        time.sleep(1)
        aparmain()
    elif sai == 'v':
        aparmtomenu()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
    time.sleep(1.5)
    sairaparm()


def aparmtomenu():
    import data.menuarmazen
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menuarmazen.armauxmain()


def aparmain():
    aparmchk()
    aparmtblhead()
    aparmtblbody()
    armapachk()
    armidchk(apg=None)
    apagfinal(apg=None)
    sairaparm()
    aparmtomenu()


if __name__ == '__main__':
    aparmain()
