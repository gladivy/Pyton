#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def prilimp():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}VAI APAGAR A TABELA TODA  '
                     '\033[1mANULAR - a  SIM - s\033[0m\n'.format(''))
    esq = raw_input('\x1b[s{0:2}> '.format(''))
    while not esq:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA s ou a'.format(''))
        time.sleep(1)
        liptdamain()
    if esq == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        limtodsair()
    elif esq == 's':
        liapgto()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA s ou a'.format(''))
    time.sleep(1)
    liptdamain()


def liapgto():
    con = sqlite3.connect('data/database/database.db')
    con.execute('DROP TABLE apagados')
    con.execute('VACUUM')
    con.close()
    remaktblapg()


def remaktblapg():
    con = sqlite3.connect('data/database/database.db')
    con.execute('CREATE TABLE IF NOT EXISTS apagados'
                '(ID INTEGER PRIMARY KEY AUTOINCREMENT, '
                'Oldid INTEGER, '
                'Data_Entrada INTEGER, '
                'Dat_apagado INTEGER, '
                'Marca TEXT, '
                'Modelo TEXT, '
                'Medida INTEGER, '
                'Codigo TEXT, '
                'DO BLOB, '
                'T BLOB, '
                'Valor INTEGER, '
                'Armazen TEXT)')
    con.close()
    apgchkbild()


def apgchkbild():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        limtodsair()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A ELIMINAR A TABELA.'.format(''))
    time.sleep(3)
    limtodsair()


def limtodsair():
    import data.utilidades
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU '
                     'UTILIDADES.'.format(''))
    time.sleep(1)
    data.utilidades.utilmain()


def liptdamain():
    prilimp()
    liapgto()
    remaktblapg()
    apgchkbild()
    limtodsair()


if __name__ == '__main__':
    liptdamain()
