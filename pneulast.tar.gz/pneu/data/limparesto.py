#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def limresmenu():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:24}\033[1m{2}\033[0m{3:28}'
                     '|\n'.format('', '', 'RESTAURO E LIMPEZA', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:23}'
                     '|\n'.format('', '', '1 - APAGAR REGISTO DO STOCK', ''))
    sys.stdout.write(
        '{0:2}|{1:20}{2}{3:20}'
        '|\n'.format('', '', '2 - MODIFICAR VALOR OU ARMAZEN', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:31}'
                     '|\n'.format('', '', '3 - RESTAURAR DADOS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:24}'
                     '|\n'.format('', '', '4 - LIMPAR TABELA APAGADOS', ''))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'UTILIDADES --- u', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'SAIR --------- s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esq = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esq:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3, 4 OU u, s.'.format(''))
        time.sleep(1.5)
        limrestmain()
    if esq == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    elif esq == 'u':
        volutili()
    elif esq == '1':
        apagarutil()
    elif esq == '2':
        modificarutil()
    elif esq == '3':
        restaurarutil()
    elif esq == '4':
        limpresto()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3, 4 OU u, s.'.format(''))
    time.sleep(1.5)
    limrestmain()


def volutili():
    import data.utilidades
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU UTILIDADES.'.format(''))
    time.sleep(1)
    data.utilidades.utilmain()


def apagarutil():
    import data.apagar
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        limrestmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}APAGAR REGISTO DO STOCK.'.format(''))
    time.sleep(1)
    data.apagar.apagmain()


def modificarutil():
    import data.modificar
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU MODIFICAR.'.format(''))
    time.sleep(1)
    data.modificar.modficarmain()


def restaurarutil():
    import data.restaurar
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU RESTAURAR.'.format(''))
    time.sleep(1)
    data.restaurar.restmain()


def limpresto():
    import data.apgrtblapg
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        limrestmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}LIMPAR TABELA APAGADOS.'.format(''))
    time.sleep(1)
    data.apgrtblapg.apartblamain()


def limrestmain():
    limresmenu()
    apagarutil()
    modificarutil()
    restaurarutil()
    limpresto()


if __name__ == '__main__':
    limrestmain()
