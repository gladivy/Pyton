#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def apafrompneuck():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        sairapag()
    else:
        con.close()
    apagstart()


def apagstart():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA A MEDIDA DO PNEU PARA '
                     'APAGAR\033[0m{1:10}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:31}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        apagstart()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairapag()
    else:
        with codecs.open('data/temp/apagstart.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    apagstartredchk()


def apagstartredchk():
    with codecs.open('data/temp/apagstart.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            apagarquest(vik)
    fil.close()


def apagarquest(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        apagstart()
    else:
        con.close()
    apaghead(vik)


def apaghead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca, Modelo, Medida, Codigo, DO, T, Armazen '
                'FROM pneusados WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, mar, mod, med, cod, dox, dot, arm = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'STOCK'))
    sys.stdout.write('\n{0:2}| \033[1m{1:^5}\033[0m '
                     '| \033[1m{2:^15}\033[0m '
                     '| \033[1m{3:^20}\033[0m '
                     '| \033[1m{4:>7}\033[0m '
                     '| \033[1m{5:6}\033[0m '
                     '| \033[1m{6:2}{7:<2}\033[0m '
                     '| \033[1m{8:^15}\033[0m '
                     '|\n'.format('', ide, mar, mod, med, cod, dox, dot, arm))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 92 * '-'))
    con.close()
    apabody(vik)


def apabody(vik):
    with codecs.open('data/temp/apabody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Marca, Modelo, Medida, Codigo, DO, T, Armazen '
                'FROM pneusados WHERE Medida LIKE ? '
                'ORDER BY Modelo, ID ASC', ('%' + vik + '%',)):
            ide, mar, mod, med, cod, dox, dot, arm = row
            sys.stdout.write('{0:2}| {1:5} | {2:15} | {3:20} | {4:7} |'
                             ' {5:^6} | {6:2}{7:<2} | {8:>15} '
                             '|\n'.format('', ide, mar, mod, med, cod,
                                          dox, dot, arm))
            fil.write(str(ide))
            fil.write(',')
        con.close()
    fil.close()
    apacount(vik)


def apacount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| \033[1mFORAM ENCONTRADOS {1:5} RESULTADOS.'
                     '\033[0m{2:12}|\n'.format('', len(cur.fetchall()), ''))
    con.close()
    adga()


def adga():
    sys.stdout.write('{0:2}|{2} \033[1mESCOLHA O ID PARA '
                     'APAGAR{1:23}\033[0m|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2} PARA ANULAR - a{1:32}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    ide = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        apagstartredchk()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANUALDO.'.format(''))
        time.sleep(1)
        sairapag()
    else:
        adgachek(ide)


def adgachek(vik):
    with codecs.open('data/temp/apabody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                aparfim(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    apagstartredchk()


def aparfim(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute('INSERT INTO apagados SELECT NULL, ID, Data_Entrada, '
                    'NULL, Marca, Modelo, Medida, Codigo, Do, T, '
                    'Valor, Armazen FROM pneusados WHERE ID = ?', (vik,))
    tra = cur.lastrowid
    if not tra:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A CRIAR ID {1} NA TABELA '
                         'APAGADOS.'.format('', vik))
        con.close()
        time.sleep(2)
        sys.stdout.write('\x1b[u\x1b[J{0:2}O ID {1} NÂO VAI SER '
                         'APAGADO.'.format('', vik))
        time.sleep(2)
        apasair()
    else:
        with con:
            con.execute(
                'UPDATE apagados SET Dat_apagado = ? '
                'WHERE ID = ?', (time.strftime('%d/%m/%y-STOCK'), tra,))
    for row in con.execute('SELECT Dat_apagado FROM apagados '
                           'WHERE ID = ?', (tra,)):
        dat = row[0]
        if dat == time.strftime('%d/%m/%y-STOCK'):
            sys.stderr.write(
                '\x1b[u\x1b[J{0:2}ID {1} ELIMINADO EM '
                '{2} '.format('', vik, time.strftime('%d/%m/%y')))
            con.close()
            time.sleep(2)
            fimapaid(vik)
        else:
            con.close()
    sys.stderr.write(
        '\x1b[u\x1b[J{0:2}ERRO AO INSERIR DATA DO ID {1} QUANDO '
        'APAGADO.'.format('', tra))
    time.sleep(2)
    sys.stderr.write('\x1b[u\x1b[J{0:2}O ID {1} NÂO VAI SER '
                     'APAGADO.'.format('', vik))
    time.sleep(2)
    apasair()


def fimapaid(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('DELETE FROM pneusados WHERE ID = ?', (vik,))
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados WHERE ID = ?', (vik,))
    if not cur.fetchall():
        sys.stderr.write('DA TABELA STOCK.')
        con.close()
        time.sleep(1.5)
        apasair()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A APAGAR O '
                     'ID {1}.'.format('', vik))
    time.sleep(1.5)
    sys.stderr.write('\x1b[u\x1b[J{0:2}O ID {1} FICOU REGISTADO NA '
                     'TABELA DE STOCK.'.format('', vik))
    time.sleep(2)
    apasair()


def apasair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sys.stdout.write('{0:2}| ESCOLHA        APAGAR - a  VOLTAR - v '
                     ' SAIR - s |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 51 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, u ou s.'.format(''))
        time.sleep(1.5)
        apasair()
    if sai == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR APAGAR OUTRA '
                         'ENTRADA.'.format(''))
        time.sleep(1)
        apagmain()
    elif sai == 'v':
        sairapag()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, u ou s.'.format(''))
    time.sleep(1.5)
    apasair()


def sairapag():
    import data.limparesto
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.limparesto.limrestmain()


def apagmain():
    apafrompneuck()
    apagstart()
    apagstartredchk()
    apagarquest(vik=None)
    apabody(vik=None)
    apacount(vik=None)
    adga()
    adgachek(vik=None)
    aparfim(vik=None)
    fimapaid(vik=None)
    apasair()
    sairapag()


if __name__ == '__main__':
    apagmain()
