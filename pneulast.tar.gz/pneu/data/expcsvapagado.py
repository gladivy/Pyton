#!/usr/bin/python
# coding: utf-8
import codecs
import sys
import sqlite3
import time
import webbrowser


def expallapa():
    with codecs.open('data/csv/apagados_total.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute(
            'SELECT Oldid, Dat_apagado, Marca, Modelo, Medida, Codigo, '
            'DO, T, Valor, Armazen FROM apagados')
        fil.write(str('APAGADOS'))
        fil.write('\n')
        fil.write('')
        fil.write('\n')
        head = [i[0] for i in cur.description]
        olx, dap, mar, mol, med, cod, dox, ttx, val, arm = head
        fil.write(str(olx))
        fil.write(',')
        fil.write(str(dap))
        fil.write(',')
        fil.write(str(mar))
        fil.write(',')
        fil.write(str(mol))
        fil.write(',')
        fil.write(str(med))
        fil.write(',')
        fil.write(str(cod))
        fil.write(',')
        fil.write(str('{0}{1}'.format(dox, ttx)))
        fil.write(',')
        fil.write(str(val))
        fil.write(',')
        fil.write(str(arm))
        fil.write('\n')
        con.close()
    fil.close()
    apabody()


def apabody():
    with codecs.open('data/csv/apagados_total.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT Oldid, Dat_apagado, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen FROM apagados'):
            old, dat, mar, mod, med, cod, dox, ttx, val, arm = row
            fil.write(str(old))
            fil.write(',')
            fil.write(str(dat))
            fil.write(',')
            fil.write(str(mar))
            fil.write(',')
            fil.write(str(mod))
            fil.write(',')
            fil.write(str(med))
            fil.write(',')
            fil.write(str(cod))
            fil.write(',')
            fil.write(str('{0}{1}'.format(dox, ttx)))
            fil.write(',')
            fil.write(str(val))
            fil.write(',')
            fil.write(str(arm))
            fil.write('\n')
        con.close()
    fil.close()
    apacsvcount()


def apacsvcount():
    with codecs.open('data/csv/apagados_total.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM apagados')
        fil.write('\n')
        fil.write(str('{0} Entradas'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    saircsvapag()


def saircsvapag():
    import data.csvcomp
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE APAGADOS '
                     'EXPORTADA EM CSV.'.format(''))
    time.sleep(1)
    webbrowser.open('data/csv/apagados_total.csv')
    data.csvcomp.compmenu()


def csvapaexpmain():
    expallapa()
    apabody()
    apacsvcount()


if __name__ == '__name__':
    csvapaexpmain()
