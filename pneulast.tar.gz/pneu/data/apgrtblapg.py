#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def limpagar():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}||{1:22}\033[1m{2}\033[0m{3:23}'
                     '||\n'.format('', '', 'PARA LIMPAR', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:8}'
        '||\n'.format('', '', 'A TABELA TODA '
                              'DE APAGADOS --------------- toda', ''))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:7}'
        '||\n'.format('', '', 'TODAS AS ENTRADAS APAGADAS '
                              'DO STOCK  ---- stock', ''))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:7}'
        '||\n'.format('', '', 'TODAS AS ENTRADAS APAGADAS '
                              'DAS VENDAS  -- venda', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:37}'
                     '|\n'.format('', '', 'VOLTAR - v SAIR - s', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    esq = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esq:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA toda, stock, '
                         'venda ou a.'.format(''))
        time.sleep(1.5)
        limpagar()
    if esq == 'toda':
        apagtoda()
    elif esq == 'stock':
        listok()
    elif esq == 'venda':
        livend()
    elif esq == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    elif esq == 'v':
        voltoant()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA toda, stock, '
                         'venda ou a.'.format(''))
    time.sleep(1.5)
    limpagar()


def apagtoda():
    import data.limptoda
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        apartblamain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}LIMPAR A TABELA APAGADOS '
                     'TODA.'.format(''))
    time.sleep(1.5)
    data.limptoda.liptdamain()


def listok():
    import data.limpstock
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        apartblamain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}LIMPAR ENTRADAS DO '
                     'STOKE.'.format(''))
    time.sleep(1.5)
    data.limpstock.lipstckmain()


def livend():
    import data.limpvend
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        apartblamain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}LIMPAR ENTRADAS DAS '
                     'VENDAS.'.format(''))
    time.sleep(1.5)
    data.limpvend.lipvendmain()


def voltoant():
    import data.limparesto
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.limparesto.limrestmain()


def apartblamain():
    limpagar()
    apagtoda()
    listok()
    livend()
    voltoant()


if __name__ == '__main__':
    apartblamain()
