#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def htmlmed():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write(
        '{0:2}|{1:21}{2}{3:22}'
        '|\n'.format('', '', '\033[1mEXPORTAR EM HTML POR MEDIDA\033[0m', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '1 - STOKE', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:40}'
                     '|\n'.format('', '', '2 - VENDAS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:38}'
                     '|\n'.format('', '', '3 - APAGADOS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:38}'
                     '|\n'.format('', '', '4 - ARMAZENS', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:49}'
                     '|\n'.format('', '', 'VOLTAR - v SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3, 4 OU v, s.'.format(''))
        time.sleep(1.5)
        htmlmedmain()
    if esc == '1':
        stockmed()
    elif esc == '2':
        vendmed()
    elif esc == '3':
        apagmed()
    elif esc == '4':
        expbyarm()
    elif esc == 'v':
        volante()
    elif esc == 's':
        htmlmedsair()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3, 4 OU v, s.'.format(''))
    time.sleep(1.5)
    htmlmedmain()


def stockmed():
    import data.exphtmlstkmed
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        htmlmedmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA STOCK EM HTML '
                     'POR MEDIDA.'.format(''))
    time.sleep(1)
    data.exphtmlstkmed.medhtmlstkmain()


def vendmed():
    import data.exphtmlvendmed
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        htmlmedmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VENDAS EM HTML '
                     'POR MEDIDA.'.format(''))
    time.sleep(1)
    data.exphtmlvendmed.medhtmlvemain()


def apagmed():
    import data.exphtmlsapgmed
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        htmlmedmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA APAGADOS EM HTML '
                     'POR MEDIDA.'.format(''))
    time.sleep(1)
    data.exphtmlsapgmed.htmlapamedmain()


def expbyarm():
    import data.exphtmlarm
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        htmlmedmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA STOCK EM HTML '
                     'POR ARMAZEN.'.format(''))
    time.sleep(1)
    data.exphtmlarm.htmlarmmain()


def volante():
    import data.menuexphtml
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menuexphtml.htmlmain()


def htmlmedsair():
    sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
    time.sleep(1)
    sys.stderr.write('\x1b[2J\x1b[H')
    sys.exit(10)


def htmlmedmain():
    htmlmed()
    stockmed()
    vendmed()
    apagmed()
    expbyarm()
    volante()
    htmlmedsair()


if __name__ == '__main__':
    htmlmedmain()
