#!/usr/bin/python
# coding: utf-8
import collections
import sys
import sqlite3
import time


def tblmedhead():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida, Codigo FROM medidas')
    head = [i[0] for i in cur.description]
    idx, marx, modlx = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'MEDIDAS E CODIGOS'))
    sys.stdout.write('\n{0:4} \033[1m{1:5}\033[0m | \033[1m{2:15}\033[0m | '
                     '\033[1m{3:20}\033[0m \n'.format('', idx, marx, modlx))
    sys.stdout.write('{0:2}{1}\n'.format('', 45 * '-'))
    con.close()
    tblmedcount()


def tblmedcount():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    lom = []
    cur.execute('SELECT ID, Medida, Codigo FROM medidas '
                'ORDER BY Medida ASC')
    qua = cur.fetchall()
    for row in qua:
        idx, medx, codx = row
        lom.append(medx)
        sys.stdout.write('{0:4} {1:5} | {2:15} | '
                         '{3:20} \n'.format('', idx, medx, codx))
    sys.stdout.write('\n\n{0:2} \033[1m{1:10}   '
                     '{2:20}\033[0m\n'.format('', 'QUANTIDADE', 'MEDIDA'))
    for ink, kit in collections.Counter(lom).most_common():
        sys.stdout.write('{0:2} {1:>10}   {2:<20}\n'.format('', kit, ink))
    sys.stdout.write('{0:2}\033[1m{1:5}\033[0m'
                     '{2:>5}\n\n'.format('', ' TOTAL', len(qua)))
    con.close()
    tblmedsair()


def tblmedsair():
    import data.menumedida
    sys.stdout.write('\n{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA        VOLTAR - v '
                     '  SAIR - s {1:9}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA v OU s.'.format(''))
        time.sleep(1.5)
        tblmedmain()
    if sair == 'v':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU '
                         'ANTERIOR.'.format(''))
        time.sleep(1)
        data.menumedida.mediauximain()
    if sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA v OU s.'.format(''))
    time.sleep(1.5)
    tblmedmain()


def tblmedmain():
    tblmedhead()
    tblmedcount()
    tblmedsair()


if __name__ == '__main__':
    tblmedmain()
