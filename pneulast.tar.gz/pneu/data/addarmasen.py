#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def startadd():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}\033[1m{2}\033[0m{3:19}'
        '||\n'.format('', '', 'ESCREVA O NOME PARA UM NOVO ARMAZEN', ''))
    sys.stdout.write('{0:2}||{1:3}{2}{3:38}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 60 * '='))
    arm = raw_input('\x1b[s{0:2}ARMAZEN > '.format(''))
    while not arm:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA UM NOVO '
                         'NOME OU a.'.format(''))
        time.sleep(1.5)
        startadd()
    if arm == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairaddarm()
    else:
        armchk(arm)


def armchk(arm):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazens '
                'WHERE Armazen = ?', (arm,))
    if not cur.fetchall():
        with codecs.open('data/temp/startaddarm.csv', 'w', 'utf_8') as fil:
            fil.write(str(arm))
        fil.close()
        con.close()
        readstartadd()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ARMAZEN EXISTENTE.'.format(''))
    time.sleep(1)
    startadd()


def readstartadd():
    with codecs.open('data/temp/startaddarm.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            arm = lin[0]
            descrein(arm)
    fil.close()


def descrein(arm):
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 62 * '='))
    sys.stdout.write(
        '{0:2}||{1:2}{2}\033[1;92m{3:^15}\033[0m{4}'
        '||\n'.format('', '', 'DISCRIMINE O '
                              'ARMAZEN ', arm, 'EM CURTAS PALAVRAS  '))
    sys.stdout.write('{0:2}||{1:2}{2}{3:41}'
                     '||\n'.format('', '', 'PARA ANULAR - a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 62 * '='))
    det = raw_input('\x1b[s{0:2}DETALHES > '.format(''))
    while not det:
        sys.stderr.write('\x1b[u\x1b[J{0:2}DISCRIMINE O '
                         'ARMAZEN OU a.'.format(''))
        time.sleep(1.5)
        readstartadd()
    if det == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairaddarm()
    else:
        con = sqlite3.connect('data/database/database.db')
        with con:
            cur = con.cursor()
            cur.execute('INSERT INTO armazens '
                        'VALUES(NULL,?,?)', (arm, det,))
        sys.stderr.write('\x1b[u\x1b[J{0:2}NOVO ID {1} IMPLATADO PARA '
                         'ARMAZEN {2}.'.format('', cur.lastrowid, arm))
        con.close()
    time.sleep(1.5)
    saircharm()


def saircharm():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 52 * '='))
    sys.stdout.write('{0:2}|  ESCOLHA  ACRESCENTAR - a  VOLTAR - v '
                     ' SAIR - s  |\n'.format(''))
    sys.stdout.write('{0:2}{1}\n'.format('', 52 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    if not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
        time.sleep(1.5)
        saircharm()
    if sair == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR ACRESCENTAR OUTRO '
                         'ARMAZEN.'.format(''))
        time.sleep(1)
        mainaddarm()
    elif sair == 'v':
        sairaddarm()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
    time.sleep(1.5)
    saircharm()


def sairaddarm():
    import data.menuarmazen
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menuarmazen.armauxmain()


def mainaddarm():
    startadd()
    armchk(arm=None)
    readstartadd()
    descrein(arm=None)
    saircharm()
    sairaddarm()


if __name__ == '__main__':
    mainaddarm()
