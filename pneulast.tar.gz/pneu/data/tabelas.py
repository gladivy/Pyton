#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def tablemenu():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}\033[1m{2}\033[0m{3:33}'
                     '|\n'.format('', '', 'TABELAS', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '1 - STOCK', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:40}'
                     '|\n'.format('', '', '2 - VENDAS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:38}'
                     '|\n'.format('', '', '3 - APAGADOS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:24}'
                     '|\n'.format('', '', '4 - TABELAS DE MODIFICADOS', ''))
    sys.stdout.write(
        '{0:2}|{1:20}{2}{3:18}'
        '|\n'.format('', '', '5 - EXPORTAR TABELAS CSV OU HTML', ''))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'MENU --------- m', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'UTILIDADES --- u', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'SAIR --------- s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:4}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3, 4 OU m, u, s.'.format(''))
        time.sleep(1)
        tabmenumain()
    if esc == '1':
        fchstock()
    elif esc == '2':
        fchvend()
    elif esc == '3':
        fchapagar()
    elif esc == '4':
        fchmodifi()
    elif esc == '5':
        fchexport()
    elif esc == 'm':
        fchmenu()
    elif esc == 'u':
        fchutilidades()
    elif esc == 's':
        sairmenutbl()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3, 4 OU m, u, s.'.format(''))
    time.sleep(1)
    tabmenumain()


def fchstock():
    import data.tblstock
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        time.sleep(1)
        tabmenumain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE PNEUS.'.format(''))
    time.sleep(1)
    data.tblstock.stotblmain()


def fchvend():
    import data.tblvendas
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        time.sleep(1)
        tabmenumain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE VENDAS.'.format(''))
    time.sleep(1)
    data.tblvendas.vendmain()


def fchapagar():
    import data.tblapagados
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        tabmenumain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE APAGADOS.'.format(''))
    time.sleep(1)
    data.tblapagados.apagdtblmain()


def fchmodifi():
    import data.modmenu
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU MODIFICADOS.'.format(''))
    time.sleep(1)
    data.modmenu.modimain()


def fchexport():
    import data.exportdata
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU EXPORTAR.'.format(''))
    time.sleep(1)
    data.exportdata.exportmain()


def fchmenu():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU.'.format(''))
    time.sleep(1)
    data.menu.menumain()


def fchutilidades():
    import data.utilidades
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU UTILIDADES.'.format(''))
    time.sleep(1)
    data.utilidades.utilmain()


def sairmenutbl():
    sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
    time.sleep(1)
    sys.stderr.write('\x1b[2J\x1b[H')
    sys.exit(10)


def tabmenumain():
    tablemenu()
    fchstock()
    fchvend()
    fchapagar()
    fchmodifi()
    fchexport()
    fchmenu()
    fchutilidades()
    sairmenutbl()


if __name__ == '__main__':
    tabmenumain()
