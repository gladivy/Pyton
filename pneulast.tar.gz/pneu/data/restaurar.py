#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def resto():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:20}\033[1m{2}\033[0m{3:22}'
                     '|\n'.format('', '', 'RESTAURAR VENDAS OU APAGADOS', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '1 - VENDA', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:39}'
                     '|\n'.format('', '', '2 - APAGADO', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:49}'
                     '|\n'.format('', '', 'VOLTAR - v SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU u, s.'.format(''))
        time.sleep(1.5)
        restmain()
    if esc == '1':
        restvenda()
    elif esc == '2':
        restapagado()
    elif esc == 's':
        sys.stdout.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stdout.write('\x1b[2J\x1b[H')
        sys.exit(10)
    elif esc == 'v':
        resttoutils()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2 OU u, s.'.format(''))
    time.sleep(1.5)
    restmain()


def restvenda():
    import data.restvenda
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos')
    ent = cur.fetchall()
    if not ent:
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        restmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}RESTAURAR VENDA.'.format(''))
    time.sleep(1)
    data.restvenda.revenmain()


def restapagado():
    import data.restapagado
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        restmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}RESTAURAR APAGADO.'.format(''))
    data.restapagado.reapamain()


def resttoutils():
    import data.limparesto
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.limparesto.limrestmain()


def restmain():
    resto()
    restvenda()
    restapagado()
    resttoutils()


if __name__ == '__main__':
    restmain()
