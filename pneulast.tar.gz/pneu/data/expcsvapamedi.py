#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time
import webbrowser


def csvmedquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{1:8}\033[1mEXPORTAR APAGADO EM FORMATO '
                     'CSV\033[0m{2:13}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA A MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    med = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        csvmedquest()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saircsvapagmed()
    else:
        with codecs.open('data/temp/csvmedquest.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    csvmedredquesfil()


def csvmedredquesfil():
    with codecs.open('data/temp/csvmedquest.csv', 'r', 'utf_8') as fil:
        for line in csv.reader(fil):
            vik = line[0]
            csvmedtbl(vik)
    fil.close()


def csvmedtbl(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA {1} '
                         'INIXESTENTE.'.format('', vik))
        con.close()
        time.sleep(1)
        csvmedquest()
    else:
        con.close()
    csvapamedhead(vik)


def csvapamedhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM apagados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} \n'.format('', '', ide, med))
    sys.stdout.write('{0:2}{1}\n'.format('', 35 * '-'))
    con.close()
    cvsmedtblbody(vik)


def cvsmedtblbody(vik):
    with codecs.open('data/temp/cvsmedtblbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT ID, Medida FROM apagados '
                               'WHERE Medida LIKE ? GROUP BY Medida '
                               'ORDER BY Medida', ('%' + vik + '%',)):
            ide, med = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:2}{1:6}{2:5} '
                             '| {3:8} \n'.format('', '', ide, med))
        con.close()
    fil.close()
    csvexpmedquest()


def csvexpmedquest():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ID DA MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    medid = raw_input('\x1b[s{0:2} ID > '.format(''))
    while not medid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        csvmedredquesfil()
    if medid == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saircsvapagmed()
    else:
        csvapamedcheck(medid)


def csvapamedcheck(vik):
    with codecs.open('data/temp/cvsmedtblbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                csvexpapa(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    csvmedredquesfil()


def csvexpapa(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Medida FROM apagados WHERE ID=? ', (vik,)):
        med = row[0]
        csvexpapahead(med)
    con.close()


def csvexpapahead(vik):
    with codecs.open('data/csv/apagados_medida.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Oldid, Dat_apagado, Marca, Modelo '
                    'FROM apagados WHERE Medida=?', (vik,))
        fil.write(str('APAGADOS POR MEDIDA'))
        fil.write(',')
        fil.write(str(vik))
        fil.write('\n')
        fil.write('')
        fil.write('\n')
        head = [i[0] for i in cur.description]
        olx, dtx, mar, mod = head
        fil.write(str(olx))
        fil.write(',')
        fil.write(str(dtx))
        fil.write(',')
        fil.write(str(mar))
        fil.write(',')
        fil.write(str(mod))
        fil.write(',')
        con.close()
    fil.close()
    headstrch(vik)


def headstrch(vik):
    with codecs.open('data/csv/apagados_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Medida, Codigo, DO, T, Valor, Armazen '
                    'FROM apagados WHERE Medida=?', (vik,))
        head = [i[0] for i in cur.description]
        med, cod, dox, ttx, val, arm = head
        fil.write(str(med))
        fil.write(',')
        fil.write(str(cod))
        fil.write(',')
        fil.write(str('{0}{1}'.format(dox, ttx)))
        fil.write(',')
        fil.write(str(val))
        fil.write(',')
        fil.write(str(arm))
        fil.write('\n')
        con.close()
    fil.close()
    expapatblend(vik)


def expapatblend(vik):
    with codecs.open('data/csv/apagados_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT Oldid, Dat_apagado, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen '
                'FROM apagados WHERE Medida=? '
                'ORDER BY Medida ASC', (vik,)):
            old, dtx, mar, mod, med, cod, dox, ttx, val, arm = row
            fil.write(str(old))
            fil.write(',')
            fil.write(str(dtx))
            fil.write(',')
            fil.write(str(mar))
            fil.write(',')
            fil.write(str(mod))
            fil.write(',')
            fil.write(str(med))
            fil.write(',')
            fil.write(str(cod))
            fil.write(',')
            fil.write(str('{0}{1}'.format(dox, ttx)))
            fil.write(',')
            fil.write(str(val))
            fil.write(',')
            fil.write(str(arm))
            fil.write('\n')
        con.close()
    fil.close()
    expcountend(vik)


def expcountend(vik):
    with codecs.open('data/csv/apagados_medida.csv', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM apagados WHERE Medida=?', (vik,))
        fil.write('\n')
        fil.write(str('{0} Entradas'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE APAGADOS '
                     'EXPORTADA EM CSV.'.format(''))
    time.sleep(1)
    webbrowser.open('data/csv/apagados_medida.csv')
    saircsvapagmed()


def saircsvapagmed():
    import data.csvmedi
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.csvmedi.medidamenu()


def csvmedmain():
    csvmedquest()
    csvmedredquesfil()
    csvapamedhead(vik=None)
    headstrch(vik=None)
    csvmedtbl(vik=None)
    cvsmedtblbody(vik=None)
    csvexpmedquest()
    csvapamedcheck(vik=None)
    csvexpapa(vik=None)
    expapatblend(vik=None)
    expcountend(vik=None)


if __name__ == '__main__':
    csvmedmain()
