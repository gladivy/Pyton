#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def complet():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write(
        '{0:2}|{1:21}{2}{3:25}'
        '|\n'.format('', '', '\033[1mEXPORTAR EM CSV COMPLETA\033[0m', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '1 - STOKE', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:40}'
                     '|\n'.format('', '', '2 - VENDAS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:38}'
                     '|\n'.format('', '', '3 - APAGADOS', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:49}'
                     '|\n'.format('', '', 'VOLTAR - v SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
        time.sleep(1.5)
        compmenu()
    if esc == '1':
        compstk()
    elif esc == '2':
        compvenda()
    elif esc == '3':
        compapagado()
    elif esc == 'v':
        compvoltar()
    elif esc == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
    time.sleep(1.5)
    compmenu()


def compstk():
    import data.expcsvstokcop
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        compmenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}EXPORTAR TABELA STOKE '
                     'COMPLETA.'.format(''))
    time.sleep(1)
    data.expcsvstokcop.csvstkal()


def compvenda():
    import data.expcsvenda
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        compmenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}EXPORTAR TABELA VENDA '
                     'COMPLETA.'.format(''))
    time.sleep(1)
    data.expcsvenda.csvvendcomp()


def compapagado():
    import data.expcsvapagado
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM apagados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        compmenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}EXPORTAR TABELA APAGADOS '
                     'COMPLETA.'.format(''))
    time.sleep(1)
    data.expcsvapagado.csvapaexpmain()


def compvoltar():
    import data.menuexpcsv
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.menuexpcsv.csvmain()


def compmenu():
    complet()
    compstk()
    compvenda()
    compapagado()
    compvoltar()


if __name__ == '__main__':
    complet()
