#!/usr/bin/python
# coding: utf-8
import collections
import sys
import sqlite3
import time


def stoktblhead():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Data_Entrada, Marca, Modelo, Medida, Codigo, '
                'DO, T, Valor, Armazen FROM pneusados')
    head = [i[0] for i in cur.description]
    ide, dat, nom, mod, med, cod, dom, doa, pre, arm = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[1;92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'STOCK'))
    sys.stdout.write(
        '\n{0:2}| {1:^5} | {2:^10} | {3:^15} | {4:^20} | {5:>7} | {6:6} '
        '| {7:2}{8:<2} | {9:5} | {10:^15} '
        '|\n'.format('', ide, dat, nom, mod, med, cod, dom, doa, pre, arm))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 115 * '-'))
    con.close()
    stoktblbody()


def stoktblbody():
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT ID, Data_Entrada, Marca, Modelo, Medida, '
                           'Codigo, DO, T, Valor, Armazen FROM pneusados'):
        ide, dat, nom, mod, med, cod, dom, doa, pre, arm = row
        sys.stdout.write(
            '{0:2}| {1:5} |  {2:^10}  | {3:15} | {4:20} | {5:7} '
            '| {6:^6} | {7:2}{8:<2} | {9:>5} | {10:>15} '
            '|\n'.format('', ide, dat, nom, mod, med, cod, dom,
                         doa, pre, arm))
    con.close()
    stokcount()


def stokcount():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    arm = []
    cur.execute('SELECT Armazen FROM pneusados')
    qua = cur.fetchall()
    for row in qua:
        arma = row[0]
        arm.append(arma)
    sys.stdout.write(
        '\n{0:2}{1:10} {2:7}\n'.format('', '\033[1mQUANTIDADE\033[0m',
                                       '\033[1mARMAZEN\033[0m'))
    for ink, kit in collections.Counter(arm).most_common():
        sys.stdout.write('{0:2}{1:>10} {2:<7}\n'.format('', kit, ink))
    sys.stdout.write('{0:2}{1:5}{2:>5}\n\n'.format('', 'TOTAL', len(qua)))
    con.close()
    stoksair()


def stoksair():
    import data.tabelas
    sys.stdout.write('\n{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA       TABELAS - t '
                     '  SAIR - s {1:9}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    if not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA t OU s.'.format(''))
        time.sleep(1.5)
        stotblmain()
    if sair == 't':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU '
                         'TABELAS.'.format(''))
        time.sleep(1)
        data.tabelas.tabmenumain()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA t OU s.'.format(''))
    time.sleep(1.5)
    stotblmain()


def stotblmain():
    stoktblhead()
    stoktblbody()
    stokcount()
    stoksair()


if __name__ == '__main__':
    stotblmain()
