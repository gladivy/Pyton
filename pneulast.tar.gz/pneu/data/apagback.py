#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import os
import sys
import sqlite3
import time


def eleback():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}SEM BACKUPS.'.format(''))
        con.close()
        time.sleep(1)
        sairelebak()
    else:
        con.close()
    elebackquest()


def elebackquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    sys.stdout.write('{0:2}|{2:6}   \033[1;91mCUIDADO VAI APAGAR UM '
                     'BACKUP\033[0m {1:14}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}| \033[1mPARA APAGAR ESCREVA A DATA DO '
                     'BACKUP\033[0m{1:15}|\n'.format('', ''))
    sys.stdout.write('{0:2}| EXEMPLO: 1 OU 11{1:35}|\n'.format('', ''))
    sys.stdout.write('{0:2}|{2} PARA ANULAR - a{1:36}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    dat = raw_input('\x1b[s{0:2}DATA > '.format(''))
    while not dat:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A DATA OU a.'.format(''))
        time.sleep(1.5)
        elebackquest()
    if dat == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairelebak()
    else:
        with codecs.open('data/temp/elebackquest.csv', 'w', 'utf_8') as fil:
            fil.write(str(dat))
        fil.close()
    elebackredfil()


def elebackredfil():
    with codecs.open('data/temp/elebackquest.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            backubody(vik)
    fil.close()


def backubody(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados WHERE dia LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}DATA {1} '
                         'INEXISTENTE.'.format('', vik))
        con.close()
        time.sleep(1)
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA OUTRA DATA.'.format(''))
        time.sleep(1)
        elebackquest()
    else:
        con.close()
    apabakhead(vik)


def apabakhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM dados WHERE dia LIKE ?', ('%' + vik + '%',))
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    head = [i[0] for i in cur.description]
    ide, dia, nom, det = head
    sys.stdout.write('{0:2}|\033[1m{1:3} {2:>3}\033[0m '
                     '| \033[1m{3:8}\033[0m '
                     '| \033[1mMês {4:4}\033[0m '
                     '| \033[1m{5:20}\033[0m'
                     '|\n'.format('', '', ide, nom, dia, det))
    sys.stdout.write('{0:2}|{1:3} {2} {3:2}'
                     '|\n'.format('', '', 45 * '-', ''))
    con.close()
    backtabl(vik)


def backtabl(vik):
    with codecs.open('data/temp/backtabl.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT * FROM dados '
                               'WHERE dia LIKE ?', ('%' + vik + '%',)):
            ide, dia, nom, det = row
            sys.stdout.write('{0:2}|{1:3} {2:3} | {3:8} | '
                             '{4:^8} | {5:20}'
                             '|\n'.format('', '', ide, nom, dia, det))
            fil.write(str(ide))
            fil.write(',')
        con.close()
    fil.close()
    backcout(vik)


def backcout(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados WHERE dia LIKE ?', ('%' + vik + '%',))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '-'))
    sys.stdout.write('{0:2}| \033[1mFORAM ENCONTRADOS {1:5} RESULTADOS '
                     'COM O DATA {2:2}\033[0m{3:3}'
                     '|\n'.format('', len(cur.fetchall()), vik, ''))
    con.close()
    eleidbac()


def eleidbac():
    sys.stdout.write('{0:2}|{2} \033[1mESCREVA O ID DO BACKUP PARA '
                     'APAGAR\033[0m{1:17}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2} PARA ANULAR - a{1:36}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    ide = raw_input('\x1b[s{0:2} ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        elebackredfil()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairelebak()
    else:
        eleidbakchk(ide)


def eleidbakchk(vik):
    with codecs.open('data/temp/backtabl.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                elebakend(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    elebackredfil()


def elebakend(vik):
    with codecs.open('data/temp/elebakend.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT Dia, Nome FROM dados '
                               'WHERE ID=?', (vik,)):
            dia, nom = row
            fil.write(str(dia))
            fil.write(',')
            fil.write(str(nom))
        con.close()
    fil.close()
    elebakfrom(vik)


def elebakfrom(vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('DELETE FROM dados WHERE ID=?', (vik,))
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados WHERE ID=?', (vik,))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u{0:2}O BACKUP COM O ID {1} FOI '
                         'ELEMINADO.'.format('', vik))
        con.close()
        time.sleep(1.5)
        backfilred()
    else:
        sys.stderr.write('\x1b[u{0:2}ERRO A ELIMINAR BACKUP COM O '
                         'ID {1}.'.format('', vik))
    con.close()
    time.sleep(2)
    sairelebak()


def backfilred():
    with codecs.open('data/temp/elebakend.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            dia, nom = lin
            delbackfil(dia, nom)
    fil.close()


def delbackfil(dia, nom):
    if os.path.exists('data/backup/{0}{1}.sql'.format(nom, dia)):
        os.remove('data/backup/{0}{1}.sql'.format(nom, dia))
        sys.stderr.write('\x1b[u{0:2}O FICHEIRO DE BACKUP {1}{2}.sql FOI '
                         'ELEMINADO.'.format('', nom, dia))
        time.sleep(1.5)
        elebacsair()
    else:
        sys.stderr.write('\x1b[u{0:2}ERRO FICHEIRO {1}{2}.sql '
                         'INEXISTENTE'.format('', nom, dia))
    time.sleep(2)
    sairelebak()


def elebacsair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 56 * '-'))
    sys.stdout.write('{0:2}| ESCOLHA        APAGAR - a  VOLTAR - v '
                     ' SAIR - s{1:6}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 56 * '-'))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
        time.sleep(1.5)
        elebacsair()
    if sai == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR APAGAR OUTRO '
                         'BACKUP.'.format(''))
        time.sleep(1)
        elemain()
    elif sai == 'v':
        sairelebak()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(14)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v ou s.'.format(''))
    time.sleep(1.5)
    elebacsair()


def sairelebak():
    import data.backup
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.backup.bacupmain()


def elemain():
    eleback()
    elebackquest()
    elebackredfil()
    backubody(vik=None)
    apabakhead(vik=None)
    backtabl(vik=None)
    backcout(vik=None)
    eleidbac()
    eleidbakchk(vik=None)
    elebakend(vik=None)
    elebakfrom(vik=None)
    backfilred()
    delbackfil(dia=None, nom=None)
    elebacsair()
    sairelebak()


if __name__ == '__main__':
    elemain()
