#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import os
import sys
import sqlite3
import time


def resback():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}SEM BACKUPS.'.format(''))
        con.close()
        time.sleep(1)
        sairebeckup()
    else:
        con.close()
    reststart()


def reststart():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    sys.stdout.write('{0:2}|{2:6}   \033[91mCUIDADO VAI RESTAURAR UM '
                     'BACKUP\033[0m {1:11}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}| PARA RESTAURAR ESCREVA O DIA DO BACKUP'
                     '{1:13}|\n'.format('', ''))
    sys.stdout.write('{0:2}| EXEMPLO: 1 OU 11{1:35}|\n'.format('', ''))
    sys.stdout.write('{0:2}|{2} PARA ANULAR - a{1:36}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    dia = raw_input('\x1b[s{0:2}DIA > '.format(''))
    while not dia:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O DIA OU a.'.format(''))
        time.sleep(1.5)
        reststart()
    if dia == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairebeckup()
    else:
        with codecs.open('data/temp/reststart.csv', 'w', 'utf_8') as fil:
            fil.write(str(dia))
        fil.close()
    reststartredfil()


def reststartredfil():
    with codecs.open('data/temp/reststart.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            restbakbody(vik)
    fil.close()


def restbakbody(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM dados '
                'WHERE Dia LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}DATA {1} '
                         'INEXISTENTE.'.format('', vik))
        con.close()
        time.sleep(1)
        reststart()
    else:
        head = [i[0] for i in cur.description]
        ide, dix, nom, det = head
        sys.stdout.write('\x1b[1J\x1b[H')
        sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
        sys.stdout.write(
            '{0:2}|{1:3} {2:>3} | {3:^8} | Mês {4:4} | '
            '{5:20}|\n'.format('', '', ide, nom, dix, det))
    sys.stdout.write('{0:2}|{1:4} {2} {3:4}'
                     '|\n'.format('', '', 42 * '-', ''))
    con.close()
    rstbaktbl(vik)


def rstbaktbl(vik):
    with codecs.open('data/temp/rstbaktbl.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT * FROM dados '
                'WHERE Dia LIKE ?', ('%' + vik + '%',)):
            idx, dix, nomx, det = row
            sys.stdout.write(
                '{0:2}|{1:3} {2:3} | {3:^8} | {4:^8} | '
                '{5:20}| \n'.format('', '', idx, nomx, dix, det))
            fil.write(str(idx))
            fil.write(',')
        con.close()
    fil.close()
    rstbkcount(vik)


def rstbkcount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados '
                'WHERE Dia LIKE ?', ('%' + vik + '%',))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '-'))
    sys.stdout.write(
        '{0:2}| FORAM ENCONTRADOS {1:5} RESULTADOS COM O '
        'DATA {2:5}{3}|\n'.format('', len(cur.fetchall()), vik, ''))
    con.close()
    fimrest()


def fimrest():
    sys.stdout.write('{0:2}|{2} ESCREVA O ID DO BACKUP PARA '
                     'RECUPERAR{1:14}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2} PARA ANULAR - a{1:36}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '-'))
    edi = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not edi:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        reststartredfil()
    if edi == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        sairebeckup()
    else:
        with codecs.open('data/temp/rstbaktbl.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                ide = lin
                if edi in ide:
                    fil.close()
                    restclear(edi)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', edi))
        fil.close()
    time.sleep(1)
    reststartredfil()


def restclear(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Dia, Nome '
                           'FROM dados WHERE ID=?', (vik,)):
        xdd, nom = row
        backfilchk(xdd, nom)
    con.close()


def backfilchk(xdd, nom):
    if not os.path.exists('data/backup/{0}{1}.sql'.format(nom, xdd)):
        sys.stderr.write('\x1b[u\x1b[J{0:2}FICHEIRO {1}{2}.sql DE '
                         'BACKUP ENEXISTENTE.'.format('', nom, xdd))
        time.sleep(3)
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCOLHA OUTRO BACKUP.'.format(''))
        time.sleep(2)
        resback()
    else:
        with codecs.open('data/temp/restclear.csv', 'w', 'utf_8') as fil:
            fil.write(str(xdd))
            fil.write(',')
            fil.write(str(nom))
        fil.close()
    resreadfile()


def resreadfile():
    with codecs.open('data/temp/restclear.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            xdd, nom = lin
            restend(nom, xdd)
    fil.close()


def restend(nom, xdd):
    os.remove('data/database/database.db')
    sys.stderr.write('\x1b[u\x1b[J{0:2}RECUPERAR BACKUP '
                     '{1}{2}.sql.'.format('', nom, xdd))
    time.sleep(1.5)
    con = sqlite3.connect('data/database/database.db')
    with codecs.open(
            'data/backup/{0}{1}.sql'.format(nom, xdd), 'r', 'utf_8') as fil:
        for lin in fil:
            con.executescript(lin)
    con.close()
    fil.close()
    backupcheck()


def backupcheck():
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM dados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A RESTAURAR O '
                         'BACKUP.'.format(''))
        con.close()
        time.sleep(2)
        sairebeckup()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}BACKUP RESTAURADO.'.format(''))
    time.sleep(1)
    rebacsair()


def rebacsair():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 56 * '-'))
    sys.stdout.write('{0:2}| ESCOLHA     RESTAURAR - r   VOLTAR - v '
                     '  SAIR - s {1:3}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 56 * '-'))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, v OU s.'.format(''))
        time.sleep(1.5)
        rebacsair()
    if sai == 'r':
        sys.stderr.write('\x1b[u\x1b[J{0:2}RESTAURAR NOVAMENTE.'.format(''))
        time.sleep(1)
        restbackmain()
    elif sai == 'v':
        sairebeckup()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(14)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA r, v OU s.'.format(''))
    time.sleep(1.5)
    rebacsair()


def sairebeckup():
    import data.backup
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.backup.bacupmain()


def restbackmain():
    resback()
    reststart()
    reststartredfil()
    restbakbody(vik=None)
    rstbaktbl(vik=None)
    rstbkcount(vik=None)
    fimrest()
    restclear(vik=None)
    backfilchk(xdd=None, nom=None)
    resreadfile()
    restend(nom=None, xdd=None)
    backupcheck()
    rebacsair()
    sairebeckup()


if __name__ == '__main__':
    restbackmain()
