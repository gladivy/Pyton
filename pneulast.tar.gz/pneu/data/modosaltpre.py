#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def modoprestar():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| ESCREVA A DATA QUE MODIFICOU DE '
                     'PREÇO{1:10}|\n'.format('', ''))
    sys.stdout.write('{0:2}| EXEMPLO: 01-01-1999 0U 01{1:22}'
                     '|\n'.format('', ''))
    sys.stdout.write('{0:2}| PARA ANULAR - a{1:32}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    dat = raw_input('\x1b[s{0:2}DATA > '.format(''))
    while not dat:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A DATA OU a.'.format(''))
        time.sleep(1.5)
        modoprestar()
    if dat == 'a':
        modospretomenu()
    else:
        with codecs.open('data/temp/modoprestar.csv', 'w', 'utf_8') as fil:
            fil.write(str(dat))
        fil.close()
    modopredfil()


def modopredfil():
    with codecs.open('data/temp/modoprestar.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            tblpre(vik)
    fil.close()


def tblpre(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM precoalt '
                'WHERE Dat_alter LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}DATA INEXISTENTE.\n'.format(''))
        con.close()
        time.sleep(1)
        modoprestar()
    else:
        con.close()
    tblheadr(vik)


def tblheadr(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT Oldid, Dat_alter, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor_Era, Valor_Agora FROM precoalt '
                'WHERE Dat_alter LIKE ? ORDER BY Dat_alter DESC, '
                'Valor_Era ASC', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, dia, nom, mod, med, cod, dom, doa, pre, prx = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'VALORES ALTRADOS'))
    sys.stdout.write(
        '\n{0:2}| {1:^5} | {2:7} | {3:^15} | {4:^20} | {5:7} | {6:6} '
        '| {7:2}{8:<2} | {9:9} | {10:11} '
        '|\n'.format('', ide, dia, nom, mod, med, cod, dom, doa, pre, prx))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 112 * '-'))
    con.close()
    prebody(vik)


def prebody(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute(
            'SELECT Oldid, Dat_alter, Marca, Modelo, Medida, '
            'Codigo, DO, T, Valor_Era, Valor_Agora FROM precoalt '
            'WHERE Dat_alter LIKE ? ORDER BY Dat_alter DESC, '
            'Valor_Era ASC', ('%' + vik + '%',)):
        ide, dia, nom, mod, med, cod, dom, doa, pre, prx = row
        sys.stdout.write(
            '{0:2}| {1:5} |  {2:7} | {3:15} | {4:20} | {5:7} | {6:6} '
            '| {7:2}{8:<2} | {9:>9} | {10:>11} '
            '|\n'.format('', ide, dia, nom, mod, med, cod, dom, doa,
                         pre, prx))
    con.close()
    precount(vik)


def precount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM precoalt '
                'WHERE Dat_alter LIKE ?', ('%' + vik + '%',))
    sys.stdout.write(
        '\n{0:2}{1}{2:>6}\n\n'.format('', 'TOTAL', len(cur.fetchall())))
    con.close()
    modospresair()


def modospresair():
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA   PESQUISA - p  VOLTAR - v  '
                     'SAIR - s {1:1}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA p, v OU s.'.format(''))
        time.sleep(1.5)
        modopredfil()
    if sair == 'v':
        modospretomenu()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stdout.write('\x1b[2J\x1b[H')
        sys.exit(10)
    elif sair == 'p':
        sys.stderr.write('\x1b[u\x1b[J{0:2}PESQUISAR NOVAMENTE.'.format(''))
        time.sleep(1)
        modospremain()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA p, v OU s.'.format(''))
    time.sleep(1.5)
    modopredfil()


def modospretomenu():
    import data.modmenu
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.modmenu.modimain()


def modospremain():
    modoprestar()
    modopredfil()
    tblpre(vik=None)
    tblheadr(vik=None)
    prebody(vik=None)
    precount(vik=None)
    modospresair()
    modospretomenu()


if __name__ == '__main__':
    modospremain()
