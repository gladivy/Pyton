#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def menumain():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:33}\033[1m{2}\033[0m{3:33}'
                     '|\n'.format('', '', 'MENU', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:33}'
                     '|\n'.format('', '', '1 - REGISTAR PNEU', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:31}'
                     '|\n'.format('', '', '2 - PESQUISAR MEDIA', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:41}'
                     '|\n'.format('', '', '3 - VENDA', ''))
    sys.stdout.write('{0:2}|{1:35}{2}{3:35}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'TABELAS ------ t', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'UTILIDADES --- u', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:52}'
                     '|\n'.format('', '', 'SAIR --------- s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:4}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU t, u, s.'.format(''))
        time.sleep(1.5)
        mainmenu()
    if esc == '1':
        inserirdat()
    elif esc == '2':
        pesquizar()
    elif esc == '3':
        vender()
    elif esc == 't':
        tabls()
    elif esc == 'u':
        utilis()
    elif esc == 's':
        sairmenu()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU t, u, s.'.format(''))
    time.sleep(1.5)
    mainmenu()


def inserirdat():
    import data.insdata
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR REGISTO.'.format(''))
    time.sleep(1)
    data.insdata.maininser()


def pesquizar():
    import data.pesqstk
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        mainmenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR PESQUISA.'.format(''))
    time.sleep(1)
    data.pesqstk.pesqmain()


def vender():
    import data.vendas
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        mainmenu()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR VENDA.'.format(''))
    time.sleep(1)
    data.vendas.vendmain()


def tabls():
    import data.tabelas
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU TABELAS.'.format(''))
    time.sleep(1)
    data.tabelas.tabmenumain()


def utilis():
    import data.utilidades
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MENU UTILIDADES.'.format(''))
    time.sleep(1)
    data.utilidades.utilmain()


def sairmenu():
    sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
    time.sleep(1)
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.exit(10)


def mainmenu():
    menumain()
    pesquizar()
    vender()
    tabls()
    utilis()
    sairmenu()


if __name__ == '__main__':
    mainmenu()
