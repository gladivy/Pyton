#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time
import webbrowser


def htmlvemqust():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{1:10}\033[1mEXPORTAR VENDA EM FORMATO '
                     'HTML\033[0m{2:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA A MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A '
                         'MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        htmlvemqust()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        venmedsair()
    else:
        with codecs.open('data/temp/htmlvemqust.csv', 'w', 'utf_8') as fil:
            fil.write(str(esc))
        fil.close()
    htmlvendread()


def htmlvendread():
    with codecs.open('data/temp/htmlvemqust.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            htmlvemchk(vik)
    fil.close()


def htmlvemchk(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM vendidos '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        htmlvemqust()
    else:
        con.close()
    vendexptblhead(vik)


def vendexptblhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM vendidos '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} \n'.format('', '', ide, med))
    sys.stdout.write('{0:2}{1}\n'.format('', 35 * '-'))
    con.close()
    vendexptblbody(vik)


def vendexptblbody(vik):
    with codecs.open('data/temp/vendexptblbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT ID, Medida FROM vendidos '
                               'WHERE Medida LIKE ? GROUP BY Medida '
                               'ORDER BY Medida', ('%' + vik + '%',)):
            ide, med = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} '
                             '\n'.format('', '', ide, med))
        con.close()
    fil.close()
    vendexpidchoi()


def vendexpidchoi():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ID DA MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    medid = raw_input('\x1b[s{0:2} ID > '.format(''))
    while not medid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1)
        htmlvendread()
    if medid == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        venmedsair()
    else:
        vendexpchkid(medid)


def vendexpchkid(vik):
    with codecs.open('data/temp/vendexptblbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                vendexpidout(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    htmlvendread()


def vendexpidout(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Medida FROM vendidos WHERE ID=?', (vik,)):
        med = row[0]
        htmlvemhead(med)
    con.close()


def htmlvemhead(vik):
    with codecs.open('data/html/vendas_medida.html', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT Data_Venda, Marca, Modelo, Medida, '
                    'Codigo, DO, T, Valor, Armazen FROM vendidos '
                    'WHERE Medida = ?', (vik,))
        head = [i[0] for i in cur.description]
        dat, mar, mod, med, cod, dox, ttx, pre, arm = head
        fil.write(str(
            '<!DOCTYPE html>\n'
            '<html lang="pt-PT">\n'
            '<head>\n'
            '  <link rel="stylesheet" type="text/css" '
            'href="tabela.CSS">\n'
            '  <meta charset="UTF-8">\n'
            '  <title> Tabela Vendas</title>\n'
            '</head>\n'
            '<body>\n'
            '<h1>Tabela Vendas por medida {0}</h1>\n'
            '<table style="width:90%">\n'
            '  <tr>\n'
            '    <th>{1}</th>\n'
            '    <th>{2}</th>\n'
            '    <th>{3}</th>\n'
            '    <th>{4}</th>\n'
            '    <th>{5}</th>\n'
            '    <th>{6}{7}</th>\n'
            '    <th>{8}</th>\n'
            '    <th>{9}</th>\n'
            '  </tr>\n'.format(vik, dat, mar, mod, med, cod,
                               dox, ttx, pre, arm)))
        con.close()
    fil.close()
    htmlvembody(vik)


def htmlvembody(vik):
    with codecs.open('data/html/vendas_medida.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT Data_Venda, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen FROM vendidos '
                'WHERE Medida = ? ORDER BY Data_Venda, '
                'Medida ASC', (vik,)):
            dat, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(
                '  <tr>\n'
                '    <td>{0}</td>\n'
                '    <td>{1}</td>\n'
                '    <td>{2}</td>\n'
                '    <td>{3}</td>\n'
                '    <td>{4}</td>\n'
                '    <td>{5}{6}</td>\n'
                '    <td>{7}</td>\n'
                '    <td>{8}</td>\n'
                '  </tr>\n'.format(dat, mar, mod, med, cod,
                                   dox, ttx, pre, arm)))
        con.close()
    fil.close()
    htmlvemcount(vik)


def htmlvemcount(vik):
    with codecs.open('data/html/vendas_medida.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM vendidos '
                    'WHERE Medida = ?', (vik,))
        fil.write(str(
            '</table>\n'
            '  <p>NOTA:</p>\n'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
            '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{0} Entradas\n'
            '</body>\n'
            '</html>\n'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE VENDAS EXPORTADA '
                     'EM HTML.'.format(''))
    time.sleep(1)
    webbrowser.open('data/html/vendas_medida.html')
    venmedsair()


def venmedsair():
    import data.htmlmedi
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.htmlmedi.htmlmedmain()


def medhtmlvemain():
    htmlvemqust()
    htmlvendread()
    htmlvemchk(vik=None)
    vendexptblhead(vik=None)
    vendexptblbody(vik=None)
    vendexpidchoi()
    vendexpchkid(vik=None)
    vendexpidout(vik=None)
    htmlvemhead(vik=None)
    htmlvembody(vik=None)
    htmlvemcount(vik=None)
    venmedsair()


if __name__ == '__main__':
    medhtmlvemain()
