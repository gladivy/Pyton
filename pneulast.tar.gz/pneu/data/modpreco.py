#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def modprest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|  PARA MODIFICAR O VALOR DO PNEU '
                     'ESCREVA A MEDIDA{1:3}|\n'.format('', ''))
    sys.stdout.write('{0:2}|  EXEMPLO: 2055516 OU 205  '
                     '{1:25}|\n'.format('', ''))
    sys.stdout.write('{0:2}|  PARA ANULAR - a{1:35}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        modprest()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        modvaltomenu()
    else:
        with codecs.open('data/temp/modprest.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    readmodpre()


def readmodpre():
    with codecs.open('data/temp/modprest.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            modprequest(vik)
    fil.close()


def modprequest(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        modprest()
    else:
        con.close()
    modprehead(vik)


def modprehead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor '
                'FROM pneusados '
                'WHERE Medida LIKE ? '
                'ORDER BY Modelo, ID ASC', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, mar, mod, med, cod, dox, ttx, pre = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'STOCK'))
    sys.stdout.write(
        '\n{0:2}| {1:^5} | {2:15} | {3:20} | {4:7} | {5:6} |'
        ' {6:2}{7:<2} | {8:5} |\n'.format('', ide, mar, mod, med,
                                          cod, dox, ttx, pre))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 82 * '-'))
    con.close()
    modprebody(vik)


def modprebody(vik):
    with codecs.open('data/temp/modprebody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor  '
                'FROM pneusados '
                'WHERE Medida LIKE ? '
                'ORDER BY Modelo, ID ASC', ('%' + vik + '%',)):
            ide, mar, mod, med, cod, dox, ttx, pre = row
            sys.stdout.write(
                '{0:2}| {1:5} | {2:15} | {3:20} | {4:7} | {5:>6} '
                '| {6:2}{7:<2} | {8:5} '
                '|\n'.format('', ide, mar, mod, med, cod, dox, ttx, pre))
            fil.write(str(ide))
            fil.write(',')
        con.close()
    fil.close()
    modprecount(vik)


def modprecount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}| FORAM ENCONTRADOS {1:5} RESULTADOS'
                     '.{2:16}|\n'.format('', len(cur.fetchall()), ''))
    con.close()
    modp()


def modp():
    sys.stdout.write('{0:2}| PARA MODIFICAR VALOR ESCREVA O ID DO '
                     'PNEU{1:10}|\n'.format('', ''))
    sys.stdout.write('{0:2}| PARA ANULAR - a{1:36}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    ide = raw_input('\x1b[s{0:2}ID > '.format(''))
    while not ide:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        readmodpre()
    if ide == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        modvaltomenu()
    else:
        with codecs.open('data/temp/modprebody.csv', 'r', 'utf_8') as fil:
            for lin in csv.reader(fil, delimiter=','):
                idx = lin
                if ide in idx:
                    fil.close()
                    modpwritf(ide)
                else:
                    sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                     'INCORRECTO.'.format('', ide))
        fil.close()
    time.sleep(1)
    readmodpre()


def modpwritf(ide):
    with codecs.open('data/temp/modp.csv', 'w', 'utf_8') as fil:
        fil.write(str(ide))
    fil.close()
    modpreadf()


def modpreadf():
    with codecs.open('data/temp/modprebody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            ide = lin[0]
            modpreval(ide)
    fil.close()


def modpreval(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute(
            'SELECT ID, Marca, Modelo, Medida, Codigo , Valor '
            'FROM pneusados WHERE ID=?', (vik,)):
        ide, mar, mod, med, cod, pre = row
        sys.stdout.write('\x1b[1J\x1b[H')
        sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
        sys.stdout.write(
            '{0:2}|{1:10}\033[1m{2}\033[0m{3:12}'
            '|\n'.format('', '', 'PARA MODIFICAR O VALOR DO PNEU', ''))
        sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
        sys.stdout.write('{0:2}|{1:2}\033[1m{2}{3:8}{4:<25}\033[0m{5:14}'
                         '|\n'.format('', '', 'ID:', '', ide, ''))
        sys.stdout.write('{0:2}|{1:2}\033[1m{2}{3:5}{4:<25}\033[0m{5:14}'
                         '|\n'.format('', '', 'MARCA:', '', mar, ''))
        sys.stdout.write('{0:2}|{1:2}\033[1m{2}{3:4}{4:<25}\033[0m{5:14}'
                         '|\n'.format('', '', 'MODELO:', '', mod, ''))
        sys.stdout.write('{0:2}|{1:2}\033[1m{2}{3:4}{4:<25}\033[0m{5:14}'
                         '|\n'.format('', '', 'MEDIDA:', '', med, ''))
        sys.stdout.write('{0:2}|{1:2}\033[1m{2}{3:4}{4:<25}\033[0m{5:14}'
                         '|\n'.format('', '', 'CODIGO:', '', cod, ''))
        sys.stdout.write('{0:2}|{1:2}\033[92m{2}{3:5}{4:<25}\033[0m{5:14}'
                         '|\n'.format('', '', 'VALOR:', '', pre, ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write(
        '{0:2}|{1:2}{2}{3:4}'
        '|\n'.format('', '', 'ESCREVA O VALOR DO PNEU SEM VIRGULAS '
                             'NEM EUROS', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:38}'
                     '|\n'.format('', '', 'EXEMPLO:  25', ''))
    sys.stdout.write('{0:2}|{1:2}{2}{3:34}'
                     '|\n'.format('', '', 'PARA ANULAR -- a', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    val = raw_input('\x1b[s{0:2}VALOR > '.format(''))
    while not val:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O VALOR OU a.'.format(''))
        time.sleep(1.5)
        modpreadf()
    if val == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        modvaltomenu()
    else:
        con.close()
    modprefinal(vik, val)


def modprefinal(vik, val):
    con = sqlite3.connect('data/database/database.db')
    with con:
        cur = con.cursor()
        cur.execute('INSERT INTO precoalt SELECT NULL, ID, NULL, '
                    'Marca, Modelo, Medida, Codigo, DO, T, Valor, '
                    'NULL, Armazen FROM pneusados WHERE ID = ?', (vik,))
    tar = cur.lastrowid
    if not tar:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO A CRIAR O ID {1} NA '
                         'TABELA ALTERADOS.'.format('', vik))
        con.close()
        time.sleep(3)
        modars()
    else:
        with con:
            con.execute(
                'UPDATE precoalt SET Dat_alter = ?, Valor_Agora = ? '
                'WHERE ID = ?', (time.strftime('%d-%m-%y'), val, tar,))
    for row in con.execute('SELECT Dat_alter FROM precoalt '
                           'WHERE ID=?', (tar,)):
        dat = row[0]
        if dat == (time.strftime('%d-%m-%y')):
            sys.stderr.write(
                '\x1b[u\x1b[J{0:2}VALOR DO ID {1} ALTERADO EM '
                '{2}'.format('', vik, (time.strftime('%d-%m-%y'))))
            con.close()
            time.sleep(2)
            modpreupdate(val, vik)
        else:
            sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO ALTERAR A DATA DO ID {1} '
                             'NA TABELA ALTERADOS.'.format('', vik))
    con.close()
    time.sleep(3)
    modars()


def modpreupdate(val, vik):
    con = sqlite3.connect('data/database/database.db')
    with con:
        con.execute('UPDATE pneusados SET Valor = ? '
                    'WHERE ID = ?', (val, vik,))
    for row in con.execute('SELECT Valor FROM pneusados '
                           'WHERE ID=?', (vik,)):
        lor = row[0]
        if int(lor) == int(val):
            sys.stderr.write(' PARA {0}.'.format(val))
            con.close()
            time.sleep(1.5)
            modars()
        else:
            con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}ERRO AO ALTERAR O VALOR '
                     'DO ID {1}.'.format('', vik))
    time.sleep(3)
    modars()


def modars():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA    ALTERAR - a  VOLTAR - v '
                     ' SAIR - s{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v OU s.'.format(''))
        time.sleep(1.5)
        modars()
    if sair == 'a':
        modprest()
    elif sair == 'v':
        modvaltomenu()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA a, v OU s.'.format(''))
    time.sleep(1.5)
    modars()


def modvaltomenu():
    import data.modificar
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.modificar.modficarmain()


def precmain():
    modprest()
    readmodpre()
    modprequest(vik=None)
    modprehead(vik=None)
    modprebody(vik=None)
    modprecount(vik=None)
    modp()
    modpwritf(ide=None)
    modpreadf()
    modpreval(vik=None)
    modprefinal(vik=None, val=None)
    modpreupdate(val=None, vik=None)
    modars()
    modvaltomenu()


if __name__ == '__main__':
    precmain()
