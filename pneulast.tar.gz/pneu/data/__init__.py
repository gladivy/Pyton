#!/usr/bin/python
# coding: utf-8
"""
Directory of scripts. In the sub directory Backup is for saving the sql
scripts with data backup. In the csv directory saves all export csv files
from the tables in the database. The database directory is where created
the database. Html directory is save all the export html files from the
tables in the database. Temp directory is writen all the csv temporary
files wish organises the interface and controls the user input.
This is a group of scripts not a program wish uses stdout, stderr and
raw_input because was base in python 2.7, it have cyclic imports and as
been test with prospector --strictness veryhigh.
MENSSAGE pyflakes: F821 / undefined name 'raw_input' IS BECOUSE
RAW_INPUT IS NOT DIFINE IN PYTHON 3
Any bugs please report to plbrrt7@gmail.com
From Paulo Barreto
Many thanks.
"""
