#!/usr/bin/python
# coding: utf-8
import sys
import time


def auxiliar():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:20}\033[1m{2}\033[0m{3:24}'
                     '|\n'.format('', '', 'MENU DE TABELAS AUXILIARES', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:30}'
                     '|\n'.format('', '', '1 - MARCAS E MODELOS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:29}'
                     '|\n'.format('', '', '2 - MEDIDAS E CODIGOS', ''))
    sys.stdout.write('{0:2}|{1:20}{2}{3:38}'
                     '|\n'.format('', '', '3 - ARMAZENS', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:45}'
                     '|\n'.format('', '', 'UTILIDADES - u SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU u, s.'.format(''))
        time.sleep(1)
        auxiliarmain()
    if esc == '1':
        auxtomodelo()
    elif esc == '2':
        auxmedida()
    elif esc == '3':
        auxarmazen()
    elif esc == 'u':
        auxiliarvolt()
    elif esc == 's':
        sys.stdout.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stdout.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU u, s.'.format(''))
    time.sleep(1)
    auxiliarmain()


def auxtomodelo():
    import data.menumodelo
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MARCAS E MODELOS.'.format(''))
    time.sleep(1)
    data.menumodelo.modeauxmain()


def auxmedida():
    import data.menumedida
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR MEDIDAS E CODIGOS.'.format(''))
    time.sleep(1)
    data.menumedida.mediauximain()


def auxarmazen():
    import data.menuarmazen
    sys.stderr.write('\x1b[u\x1b[J{0:2}INICIAR ARMAZENS.'.format(''))
    time.sleep(1)
    data.menuarmazen.armauxmain()


def auxiliarvolt():
    import data.utilidades
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU UTILIDADES.'.format(''))
    time.sleep(1)
    data.utilidades.utilmain()


def auxiliarmain():
    auxiliar()
    auxtomodelo()
    auxmedida()
    auxarmazen()
    auxiliarvolt()


if __name__ == '__main__':
    auxiliarmain()
