#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import sys
import sqlite3
import time


def modostar():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| ESCREVA A DATA QUE MODIFICOU DE '
                     'ARMAZEN{1:8}|\n'.format('', ''))
    sys.stdout.write('{0:2}| EXEMPLO: 01/01/1999 0U 01{1:22}'
                     '|\n'.format('', ''))
    sys.stdout.write('{0:2}| PARA ANULAR - a{1:32}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    dat = raw_input('\x1b[s{0:2}DATA > '.format(''))
    while not dat:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A DATA OU a.'.format(''))
        time.sleep(1.5)
        modostar()
    if dat == 'a':
        modarmtomenu()
    else:
        with codecs.open('data/temp/modostar.csv', 'w', 'utf_8') as fil:
            fil.write(str(dat))
        fil.close()
    modosredfil()


def modosredfil():
    with codecs.open('data/temp/modostar.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            tblarm(vik)
    fil.close()


def tblarm(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazenalt '
                'WHERE Dat_alter LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}DATA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        modostar()
    else:
        con.close()
    tlbarmhead(vik)


def tlbarmhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT Oldid, Dat_alter, Marca, Modelo, Medida, '
                'Codigo, DO, T, Do_Armazen, Para_Armazen '
                'FROM armazenalt '
                'WHERE Dat_alter LIKE ? '
                'ORDER BY Dat_alter DESC, '
                'Do_Armazen ASC', ('%' + vik + '%',))
    sys.stdout.write('\x1b[1J\x1b[H')
    head = [i[0] for i in cur.description]
    ide, dia, nom, mod, med, cod, dom, doa, arm, arx = head
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'ARMAZENS ALTERADOS'))
    sys.stdout.write(
        '\n{0:2}| {1:^5} | {2:7} | {3:^15} | {4:^20} | {5:7} | {6:6} '
        '| {7:2}{8:<2} | {9:^15} | {10:^15} '
        '|\n'.format('', ide, dia, nom, mod, med, cod, dom, doa, arm, arx))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 122 * '-'))
    con.close()
    tblarmbody(vik)


def tblarmbody(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute(
            'SELECT Oldid, Dat_alter, Marca, Modelo, Medida, '
            'Codigo, DO, T, Do_Armazen, Para_Armazen '
            'FROM armazenalt '
            'WHERE Dat_alter LIKE ? '
            'ORDER BY Dat_alter DESC, '
            'Do_Armazen ASC', ('%' + vik + '%',)):
        ide, dia, nom, mod, med, cod, dom, doa, arm, arx = row
        sys.stdout.write(
            '{0:2}| {1:5} |  {2:7} | {3:15} | {4:20} | {5:7} | {6:6} '
            '| {7:2}{8:<2} | {9:>15} | {10:>15} '
            '|\n'.format('', ide, dia, nom, mod, med, cod, dom, doa,
                         arm, arx))
    con.close()
    tblcount(vik)


def tblcount(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM armazenalt '
                'WHERE Dat_alter LIKE ? ', ('%' + vik + '%',))
    sys.stdout.write(
        '\n{0:2}{1}{2:>6}\n\n'.format('', 'Total', len(cur.fetchall())))
    con.close()
    modosarmsair()


def modosarmsair():
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA   PESQUISA - p  VOLTAR - v  '
                     'SAIR - s {1:1}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sair = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sair:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA p, v OU s.'.format(''))
        time.sleep(1.5)
        modosredfil()
    if sair == 'v':
        modarmtomenu()
    elif sair == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    elif sair == 'p':
        sys.stderr.write('\x1b[u\x1b[J{0:2}PESQUISAR NOVAMENTE.'.format(''))
        time.sleep(1)
        modosarmmain()
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA p, v OU s.'.format(''))
    time.sleep(1.5)
    modosredfil()


def modarmtomenu():
    import data.modmenu
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.modmenu.modimain()


def modosarmmain():
    modostar()
    modosredfil()
    tblarm(vik=None)
    tlbarmhead(vik=None)
    tblarmbody(vik=None)
    tblcount(vik=None)
    modosarmsair()
    modarmtomenu()


if __name__ == '__main__':
    modosarmmain()
