#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import collections
import sys
import sqlite3
import time


def pesquar():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}| PARA PESQUISAR ESCREVA A MEDIDA DO '
                     'PNEU{1:8}|\n'.format('', ''))
    sys.stdout.write('{0:2}| EXEMPLO: 2055516 OU 205 {1:23}'
                     '|\n'.format('', ''))
    sys.stdout.write('{0:2}| PARA ANULAR - a{1:32}|\n'.format('', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    med = raw_input('\x1b[s{0:2}MEDIDA > '.format(''))
    while not med:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        pesquar()
    if med == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        saiadapesq()
    else:
        with codecs.open('data/temp/pesquar.csv', 'w', 'utf_8') as fil:
            fil.write(str(med))
        fil.close()
    pesquareadfil()


def pesquareadfil():
    with codecs.open('data/temp/pesquar.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            pesqtbl(vik)
    fil.close()


def pesqtbl(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ? ', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        pesquar()
    else:
        con.close()
    peskhead(vik)


def peskhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Marca, Modelo, Medida, '
                'Codigo, DO, T, Valor, Armazen '
                'FROM pneusados WHERE Medida LIKE ? '
                'ORDER BY Codigo ASC, Medida ASC', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, nom, mod, med, cod, dom, doa, pre, arm = head
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}SQLITE VERSION '
                     '{1}\n'.format('', sqlite3.sqlite_version))
    sys.stdout.write('\n{0:2}{1}{2:1}\033[92m{3}\033[0m'
                     '.\n'.format('', 'TABELA', '', 'STOCK'))
    sys.stdout.write(
        '\n{0:2}| {1:5} | {2:^15} | {3:^20} | {4:>7} | {5:6} '
        '| {6:2}{7:<2} | {8:5} | {9:^15} '
        '|\n'.format('', ide, nom, mod, med, cod, dom, doa, pre, arm))
    sys.stdout.write('{0:2}|{1}|\n'.format('', 100 * '-'))
    con.close()
    pesqtblbo(vik)


def pesqtblbo(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute(
            'SELECT ID, Marca, Modelo, Medida, '
            'Codigo, DO, T, Valor, Armazen '
            'FROM pneusados WHERE Medida LIKE ? '
            'ORDER BY Modelo ASC, Medida ASC', ('%' + vik + '%',)):
        ide, nom, mod, med, cod, dom, doa, pre, arm = row
        sys.stdout.write(
            '{0:2}| {1:5} | {2:15} | {3:20} | {4:7} | {5:^6} '
            '| {6:2}{7:<2} | {8:5} | {9:>15} '
            '|\n'.format('', ide, nom, mod, med, cod, dom, doa, pre, arm))
    con.close()
    pesqct(vik)


def pesqct(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute(
        'SELECT ID FROM pneusados WHERE Medida LIKE ? ', ('%' + vik + '%',))
    sys.stdout.write(
        '\n{0:2}FORAM ENCONTRADOS: {1:>5} '
        'RESULTADOS.\n'.format('', len(cur.fetchall())))
    con.close()
    pesqcount(vik)


def pesqcount(vik):
    lom = []
    hoc = []
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute(
            'SELECT Modelo, Codigo '
            'FROM pneusados WHERE Medida LIKE ? ', ('%' + vik + '%',)):
        mod, cod = row
        lom.append(str(mod))
        hoc.append(str(cod))
    con.close()
    num = []
    let = []
    for mdx, kit in collections.Counter(zip(lom, hoc)).most_common():
        if kit >= 2:
            num.append(kit)
            let.append(' '.join(mdx))
    for nox, lox in zip(num, let):
        sys.stdout.write('\n{0:2}{1} {2}'.format('', nox, lox))
    pesqsair()


def pesqsair():
    sys.stdout.write('\n\n{0:2}{1}\n'.format('', 50 * '='))
    sys.stdout.write('{0:2}|{2:2}ESCOLHA    PESQUISA - p  MENU - m '
                     ' SAIR - s{1:3}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 50 * '='))
    sai = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not sai:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA p, m OU s.'.format(''))
        time.sleep(1.5)
        pesquareadfil()
    if sai == 'p':
        sys.stderr.write('\x1b[u\x1b[J{0:2}PESQUISAR NOVAMENTE.'.format(''))
        time.sleep(1)
        pesquar()
    elif sai == 'm':
        saiadapesq()
    elif sai == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    else:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA p, m OU s.'.format(''))
    time.sleep(1.5)
    pesquareadfil()


def saiadapesq():
    import data.menu
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU.'.format(''))
    time.sleep(1)
    data.menu.mainmenu()


def pesqmain():
    pesquar()
    pesquareadfil()
    pesqtbl(vik=None)
    peskhead(vik=None)
    pesqtblbo(vik=None)
    pesqct(vik=None)
    pesqcount(vik=None)
    pesqsair()
    saiadapesq()


if __name__ == '__main__':
    pesqmain()
