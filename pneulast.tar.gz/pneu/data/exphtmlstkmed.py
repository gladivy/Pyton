#!/usr/bin/python
# coding: utf-8
import csv
import codecs
import collections
import sys
import sqlite3
import time
import webbrowser


def htmlstkmquest():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{1:10}\033[1mEXPORTAR STOCK EM FORMATO '
                     'HTML\033[0m{2:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA A MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:12}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA A '
                         'MEDIDA OU a.'.format(''))
        time.sleep(1.5)
        htmlstkmquest()
    if esc == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        stkmedsair()
    else:
        with codecs.open('data/temp/htmlstkmquest.csv', 'w', 'utf_8') as fil:
            fil.write(str(esc))
        fil.close()
    htmlstkfilread()


def htmlstkfilread():
    with codecs.open('data/temp/htmlstkmquest.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil):
            vik = lin[0]
            htmlstkmchk(vik)
    fil.close()


def htmlstkmchk(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM pneusados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}MEDIDA INEXISTENTE.'.format(''))
        con.close()
        time.sleep(1)
        htmlstkmquest()
    else:
        con.close()
    htmlstktblhead(vik)


def htmlstktblhead(vik):
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID, Medida FROM pneusados '
                'WHERE Medida LIKE ?', ('%' + vik + '%',))
    head = [i[0] for i in cur.description]
    ide, med = head
    sys.stdout.write('\x1b[1J\x1b[H\n')
    sys.stdout.write('{0:2}{1:6}{2:5} | {3:8} \n'.format('', '', ide, med))
    sys.stdout.write('{0:2}{1}\n'.format('', 35 * '-'))
    con.close()
    htmlstktblbody(vik)


def htmlstktblbody(vik):
    with codecs.open('data/temp/htmlstktblbody.csv', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute('SELECT ID, Medida FROM pneusados '
                               'WHERE Medida LIKE ? GROUP BY Medida '
                               'ORDER BY Medida', ('%' + vik + '%',)):
            ide, med = row
            fil.write(str(ide))
            fil.write(',')
            sys.stdout.write('{0:2}{1:6}{2:5} '
                             '| {3:8} \n'.format('', '', ide, med))
        con.close()
    fil.close()
    htmluseridcho()


def htmluseridcho():
    sys.stdout.write('\n{0:2}{1}\n'.format('', 54 * '='))
    sys.stdout.write('{0:2}|{2:2}\033[1mESCREVA O ID DA MEDIDA QUE PRETENDE '
                     'EXPORTAR\033[0m{1:6}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}|{2:2}PARA ANULAR - a{1:35}|\n'.format('', '', ''))
    sys.stdout.write('{0:2}{1}\n'.format('', 54 * '='))
    medid = raw_input('\x1b[s{0:2} ID > '.format(''))
    while not medid:
        sys.stderr.write('\x1b[u\x1b[J{0:2}ESCREVA O ID OU a.'.format(''))
        time.sleep(1.5)
        htmlstkfilread()
    if medid == 'a':
        sys.stderr.write('\x1b[u\x1b[J{0:2}ANULADO.'.format(''))
        time.sleep(1)
        stkmedsair()
    else:
        idforhtml(medid)


def idforhtml(vik):
    with codecs.open('data/temp/htmlstktblbody.csv', 'r', 'utf_8') as fil:
        for lin in csv.reader(fil, delimiter=','):
            ide = lin
            if vik in ide:
                fil.close()
                htmlidtoexp(vik)
            else:
                sys.stderr.write('\x1b[u\x1b[J{0:2}ID {1} '
                                 'INCORRETO.'.format('', vik))
    fil.close()
    time.sleep(1)
    htmlstkfilread()


def htmlidtoexp(vik):
    con = sqlite3.connect('data/database/database.db')
    for row in con.execute('SELECT Medida '
                           'FROM pneusados WHERE ID=? ', (vik,)):
        med = row[0]
        htmlstkmhead(med)
    con.close()


def htmlstkmhead(vik):
    with codecs.open('data/html/stock_medida.html', 'w', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID, Marca, Modelo, Medida, Codigo, DO, T, '
                    'Valor, Armazen FROM pneusados '
                    'WHERE Medida = ?', (vik,))
        head = [i[0] for i in cur.description]
        ide, mar, mod, med, cod, dox, ttx, pre, arm = head
        fil.write(str(
            '<!DOCTYPE html>\n'
            '<html lang="pt-PT">\n'
            '<head>\n'
            '  <link rel="stylesheet" type="text/css" '
            'href="tabela.CSS">\n'
            '  <meta charset="UTF-8">\n'
            '  <title> Tabela Stock</title>\n'
            '</head>\n'
            '<body>\n'
            '<h1>Tabela Stock por medida {0}</h1>\n'
            '<table style="width:90%">\n'
            '  <tr>\n'
            '    <th>{1}</th>\n'
            '    <th>{2}</th>\n'
            '    <th>{3}</th>\n'
            '    <th>{4}</th>\n'
            '    <th>{5}</th>\n'
            '    <th>{6}{7}</th>\n'
            '    <th>{8}</th>\n'
            '    <th>{9}</th>\n'
            '  </tr>\n'.format(vik, ide, mar, mod, med, cod, dox,
                               ttx, pre, arm)))
        con.close()
    fil.close()
    htmlstkmbody(vik)


def htmlstkmbody(vik):
    with codecs.open('data/html/stock_medida.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        for row in con.execute(
                'SELECT ID, Marca, Modelo, Medida, Codigo, DO, T, Valor, '
                'Armazen FROM pneusados WHERE Medida = ? '
                'ORDER BY Marca, Medida ASC', (vik,)):
            ide, mar, mod, med, cod, dox, ttx, pre, arm = row
            fil.write(str(
                '  <tr>\n'
                '    <td>{0}</td>\n'
                '    <td>{1}</td>\n'
                '    <td>{2}</td>\n'
                '    <td>{3}</td>\n'
                '    <td>{4}</td>\n'
                '    <td>{5}{6}</td>\n'
                '    <td>{7}</td>\n'
                '    <td>{8}</td>\n'
                '  </tr>\n'.format(ide, mar, mod, med, cod, dox,
                                   ttx, pre, arm)))
        con.close()
    fil.close()
    htmlstkmcount(vik)


def htmlstkmcount(vik):
    with codecs.open('data/html/stock_medida.html', 'a', 'utf_8') as fil:
        con = sqlite3.connect('data/database/database.db')
        cur = con.cursor()
        cur.execute('SELECT ID FROM pneusados '
                    'WHERE Medida = ? ', (vik,))
        fil.write(str('</table>\n'
                      '  <p>NOTA:</p>\n'
                      '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                      '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                      '&nbsp;{0} - Entradas\n'
                      '  <p></p>\n'.format(len(cur.fetchall()))))
        con.close()
    fil.close()
    stkmlastcount(vik)


def stkmlastcount(vik):
    lox = []
    hox = []
    con = sqlite3.connect('data/database/database.db')
    for rows in con.execute(
            'SELECT Modelo, Codigo FROM pneusados '
            'WHERE Medida = ?', (vik,)):
        mod, cod = rows
        lox.append(str(mod))
        hox.append(str(cod))
    num = []
    let = []
    for mdx, k in collections.Counter(zip(lox, hox)).most_common():
        if k >= 2:
            num.append(k)
            let.append(' '.join(mdx))
    with codecs.open('data/html/stock_medida.html', 'a', 'utf_8') as fil:
        for nox, dox in zip(num, let):
            fil.write(str('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                          '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                          '&nbsp;{0} - {1}<br>\n'
                          '</body>\n'
                          '</html>\n'.format(nox, dox)))
    fil.close()
    con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA DE STOCK EXPORTADA '
                     'EM HTML.'.format(''))
    time.sleep(1)
    webbrowser.open('data/html/stock_medida.html')
    stkmedsair()


def stkmedsair():
    import data.htmlmedi
    sys.stderr.write('\x1b[u\x1b[J{0:2}A VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.htmlmedi.htmlmedmain()


def medhtmlstkmain():
    htmlstkmquest()
    htmlstkfilread()
    htmlstktblhead(vik=None)
    htmlstktblbody(vik=None)
    htmluseridcho()
    idforhtml(vik=None)
    htmlidtoexp(vik=None)
    htmlstkmchk(vik=None)
    htmlstkmhead(vik=None)
    htmlstkmbody(vik=None)
    htmlstkmcount(vik=None)
    stkmlastcount(vik=None)
    stkmedsair()


if __name__ == '__main__':
    medhtmlstkmain()
