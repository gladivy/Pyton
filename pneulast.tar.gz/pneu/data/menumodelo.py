#!/usr/bin/python
# coding: utf-8
import sys
import sqlite3
import time


def menmodelo():
    sys.stdout.write('\x1b[1J\x1b[H')
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:20}\033[1m{2}\033[0m{3:26}'
                     '|\n'.format('', '', 'MENU DE MARCAS E MODELOS', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write(
        '{0:2}|{1:20}{2}{3:20}'
        '|\n'.format('', '', '1 - TABELA DE MARCAS E MODELOS', ''))
    sys.stdout.write(
        '{0:2}|{1:20}{2}{3:22}'
        '|\n'.format('', '', '2 - INSERIR MARCAS E MODELOS', ''))
    sys.stdout.write(
        '{0:2}|{1:20}{2}{3:24}'
        '|\n'.format('', '', '3 - APAGAR MARCAS E MODELO', ''))
    sys.stdout.write('{0:2}|{1:30}{2}{3:40}|\n'.format('', '', '', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    sys.stdout.write('{0:2}|{1:2}{2}{3:49}'
                     '|\n'.format('', '', 'VOLTAR - v SAIR - s', ''))
    sys.stdout.write('{0:2}X{1}X\n'.format('', 70 * '='))
    esc = raw_input('\x1b[s{0:2}ESCOLHA > '.format(''))
    while not esc:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
        time.sleep(1.5)
        modeauxmain()
    if esc == '1':
        auxtblmarcas()
    elif esc == '2':
        auxinmarmod()
    elif esc == '3':
        apagarmarcauxi()
    elif esc == 's':
        sys.stderr.write('\x1b[u\x1b[J{0:2}A SAIR OBRIGADO.'.format(''))
        time.sleep(1)
        sys.stderr.write('\x1b[2J\x1b[H')
        sys.exit(10)
    elif esc == 'v':
        modeauxvolt()
    else:
        sys.stderr.write('\x1b[u{0:2}POR FAVOR UTILIZE '
                         '1, 2, 3 OU v, s.'.format(''))
    time.sleep(1.5)
    modeauxmain()


def auxtblmarcas():
    import data.tblmarca
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        modeauxmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}TABELA MARCAS E CODIGOS.'.format(''))
    con.close()
    time.sleep(1)
    data.tblmarca.tblmodmain()


def auxinmarmod():
    import data.inmarca
    sys.stderr.write('\x1b[u\x1b[J{0:2}INSERIR MARCAS E CODIGOS.'.format(''))
    time.sleep(1)
    data.inmarca.inmarkmain()


def apagarmarcauxi():
    import data.agarmarca
    con = sqlite3.connect('data/database/database.db')
    cur = con.cursor()
    cur.execute('SELECT ID FROM marcas')
    if not cur.fetchall():
        sys.stderr.write('\x1b[u{0:2}TABELA VAZIA.'.format(''))
        con.close()
        time.sleep(1)
        modeauxmain()
    else:
        con.close()
    sys.stderr.write('\x1b[u\x1b[J{0:2}APAGAR MARCAS E CODIGOS.'.format(''))
    time.sleep(1)
    data.agarmarca.modellmain()


def modeauxvolt():
    import data.tablauxiliares
    sys.stderr.write('\x1b[u\x1b[J{0:2}VOLTAR AO MENU ANTERIOR.'.format(''))
    time.sleep(1)
    data.tablauxiliares.auxiliarmain()


def modeauxmain():
    menmodelo()
    auxtblmarcas()
    auxinmarmod()
    apagarmarcauxi()
    modeauxvolt()


if __name__ == '__main__':
    modeauxmain()
